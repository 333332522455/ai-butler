// qq/qq.mjs — QQ 官方机器人腿的客户端外壳（token + REST + WebSocket 拼成一个 client）
// 形状与 ilink/serve.mjs 里的 createIlink 对齐：有 send({text}) / typing({}) / onMessage(cb)，
// 这样上层的 serve 可以照搬回程契约（桥 POST /send -> 这条腿发给 QQ）。
//
// 被动回复（推荐）：带上最近一条 C2C_MESSAGE_CREATE 的 msg_id + 递增的 msg_seq。
// 官方两处文档冲突：单聊消息页写 msg_id「5 分钟内有效」，消息收发概述写「60 分钟、每条可回 4 次」。
// 代码按「越新越安全」处理：只保留最新 msg_id，回复次数用满/失败就退回主动消息。

import fs from 'node:fs';
import { createTokenManager, DEFAULT_BASE } from './qq-token.mjs';
import {
  createApi, ERR_MSG_ID_EXPIRED, ERR_MSG_ID_LIMIT,
  FILE_TYPE_IMAGE, FILE_TYPE_VIDEO, FILE_TYPE_AUDIO, FILE_TYPE_FILE, MSG_TYPE_RICH_MEDIA,
} from './qq-api.mjs';
import { createGatewaySocket } from './qq-ws.mjs';
import { parseAttachments } from './qq-media.mjs';

export const C2C_MESSAGE_CREATE = 'C2C_MESSAGE_CREATE';
export const GROUP_AT_MESSAGE_CREATE = 'GROUP_AT_MESSAGE_CREATE';
// 用户在机器人「资料卡」上开关「主动消息」推送时，平台推给机器人的两个事件（同一 intent 1<<25）
export const C2C_MSG_RECEIVE = 'C2C_MSG_RECEIVE';
export const C2C_MSG_REJECT = 'C2C_MSG_REJECT';
export const INTENT_GUILDS = 1 << 0;
export const INTENT_GUILD_MEMBERS = 1 << 1;
export const INTENT_GROUP_AND_C2C = 1 << 25; // 单聊/群聊事件（含 C2C_MESSAGE_CREATE、GROUP_AT_MESSAGE_CREATE）
export const INTENT_PUBLIC_GUILD_MESSAGES = 1 << 30;
export const DEFAULT_INTENTS = INTENT_GROUP_AND_C2C;

function msg(e) { return (e && e.message) || String(e); }

// 扩展名 -> file_type（官方只认 1 图片 / 2 视频 / 3 语音 / 4 文件）
const EXT_FILE_TYPE = {
  '.jpg': FILE_TYPE_IMAGE, '.jpeg': FILE_TYPE_IMAGE, '.png': FILE_TYPE_IMAGE, '.gif': FILE_TYPE_IMAGE,
  '.webp': FILE_TYPE_IMAGE, '.bmp': FILE_TYPE_IMAGE, '.heic': FILE_TYPE_IMAGE,
  '.mp4': FILE_TYPE_VIDEO, '.mov': FILE_TYPE_VIDEO, '.m4v': FILE_TYPE_VIDEO, '.webm': FILE_TYPE_VIDEO,
  '.mp3': FILE_TYPE_AUDIO, '.wav': FILE_TYPE_AUDIO, '.silk': FILE_TYPE_AUDIO, '.amr': FILE_TYPE_AUDIO,
  '.flac': FILE_TYPE_AUDIO, '.m4a': FILE_TYPE_AUDIO, '.ogg': FILE_TYPE_AUDIO,
};

// 把扩展名 / MIME / 中文类型名 / 数字都归一成 file_type；认不出就返回 fallback
export function fileTypeOf(value, fallback) {
  const fb = fallback === undefined ? FILE_TYPE_FILE : fallback;
  if (value === undefined || value === null || value === '') return fb;
  if (typeof value === 'number' && value >= 1 && value <= 4) return value;
  const s = String(value).toLowerCase().trim();
  if (/^[1-4]$/.test(s)) return Number(s);
  if (s === 'image' || s === 'img' || s === 'picture' || s === '图片' || s === '图像' || s === '照片') return FILE_TYPE_IMAGE;
  if (s === 'video' || s === '视频') return FILE_TYPE_VIDEO;
  if (s === 'audio' || s === 'voice' || s === 'record' || s === '语音' || s === '音频') return FILE_TYPE_AUDIO;
  if (s === 'file' || s === '文件') return FILE_TYPE_FILE;
  if (s.startsWith('image/')) return FILE_TYPE_IMAGE;
  if (s.startsWith('video/')) return FILE_TYPE_VIDEO;
  if (s.startsWith('audio/')) return FILE_TYPE_AUDIO;
  const bare = s.split('?')[0];
  const dot = bare.lastIndexOf('.');
  const ext = dot >= 0 ? bare.slice(dot) : '';
  if (EXT_FILE_TYPE[ext] !== undefined) return EXT_FILE_TYPE[ext];
  return fb;
}

// 出站媒体的三种写法：字符串（本地路径或 http(s) 链接）｜{path|url|data, fileType, contentType}
export function normalizeMedia(raw) {
  if (raw === undefined || raw === null) return null;
  if (typeof raw === 'string') {
    const s = raw.trim();
    if (!s) return null;
    if (/^https?:\/\//i.test(s)) return { url: s, path: null, data: null, fileType: null, fileName: null, contentType: null };
    return { url: null, path: s, data: null, fileType: null, fileName: s, contentType: null };
  }
  if (typeof raw !== 'object') return null;
  const filePath = raw.path || raw.file || raw.filePath || null;
  const url = raw.url || null;
  let data = raw.data || raw.file_data || raw.base64 || raw.fileData || null;
  let contentType = raw.contentType || raw.content_type || raw.mime || null;
  // data URL（data:image/png;base64,xxxx）里的 MIME 也算个类型提示，顺带剥掉前缀
  if (typeof data === 'string') {
    const m = /^data:([^;,]+)[^,]*,(.*)$/is.exec(data);
    if (m) { if (!contentType) contentType = m[1]; data = m[2]; }
  }
  const typeHint = raw.fileType !== undefined ? raw.fileType
    : (raw.file_type !== undefined ? raw.file_type : (raw.type !== undefined ? raw.type : undefined));
  if (!filePath && !url && !data) return null;
  return {
    url: url ? String(url) : null,
    path: filePath ? String(filePath) : null,
    data: data ? String(data) : null,
    fileType: fileTypeOf(typeHint, null) || fileTypeOf(contentType, null),
    fileName: raw.fileName || raw.filename || raw.name || (filePath ? String(filePath) : null),
    contentType: contentType ? String(contentType) : null,
  };
}

// 组上传请求体：官方要求 srv_send_msg=false（只要 file_info，不直接发消息）
export function buildUploadRequest(media, opts) {
  const o = opts || {};
  const m = normalizeMedia(media);
  if (!m) throw new Error('media 为空（需要 path / url / data）');
  const fileType = fileTypeOf(o.fileType, null) || m.fileType || fileTypeOf(m.contentType, null) || fileTypeOf(m.fileName, null) || fileTypeOf(m.path, null) || fileTypeOf(m.url, null) || FILE_TYPE_FILE;
  const req = { file_type: fileType, srv_send_msg: o.srvSendMsg === true };
  if (m.url) { req.url = m.url; return req; }
  if (m.data) { req.file_data = m.data; return req; }
  req.file_data = fs.readFileSync(m.path).toString('base64');
  return req;
}

function fileInfoOf(out) {
  if (!out || typeof out !== 'object') return null;
  const v = out.file_info !== undefined && out.file_info !== null ? out.file_info
    : (out.fileInfo !== undefined && out.fileInfo !== null ? out.fileInfo : null);
  return v === null || v === '' ? null : String(v);
}

// 长文分段：优先在空行 / 换行 / 句末标点处断开，每段不超过 limit 字，最多 maxParts 段；
// 超出的部分丢掉，并在最后一段补「…（还有 N 字没发完）」。返回 { parts, truncated, dropped }。
export function splitText(text, limit, maxParts) {
  const s = text === undefined || text === null ? '' : String(text);
  const cap = Number(limit) > 0 ? Math.floor(Number(limit)) : 1500;
  const max = Number(maxParts) > 0 ? Math.floor(Number(maxParts)) : 4;
  if (s.length <= cap) return { parts: [s], truncated: false, dropped: 0 };
  const parts = [];
  let rest = s;
  while (rest.length > cap && parts.length < max) {
    const cut = breakIndex(rest.slice(0, cap));
    const piece = rest.slice(0, cut).replace(/\s+$/, '');
    if (piece) parts.push(piece);
    rest = rest.slice(cut).replace(/^\s+/, '');
  }
  let dropped = 0;
  if (rest.length > 0) {
    if (parts.length < max) parts.push(rest);
    else dropped = rest.length;
  }
  if (dropped > 0) parts[parts.length - 1] = parts[parts.length - 1] + '…（还有 ' + dropped + ' 字没发完）';
  if (parts.length === 0) parts.push('');
  return { parts: parts, truncated: dropped > 0, dropped: dropped };
}

// 在窗口里找断点：按优先级（段落 > 换行 > 句末标点 > 逗号）取最后一个出现的位置，
// 但位置不能早于窗口一半，太靠前就宁可硬切在窗口末尾。
function breakIndex(window) {
  const seps = ['\n\n', '\n', '。', '！', '？', '；', '……', '. ', '! ', '? ', '; ', '，', ', '];
  const floor = Math.floor(window.length / 2);
  for (const sep of seps) {
    const idx = window.lastIndexOf(sep);
    if (idx >= floor) return idx + sep.length;
  }
  return window.length;
}

export function createQq(config = {}) {
  const cfg = config || {};
  const logger = typeof cfg.logger === 'function' ? cfg.logger : () => {};
  const now = typeof cfg.now === 'function' ? cfg.now : () => Date.now();
  const fetchImpl = cfg.fetchImpl || globalThis.fetch;
  const seenLimit = cfg.seenLimit === undefined ? 500 : Number(cfg.seenLimit);
  const maxPassiveReplies = cfg.maxPassiveReplies === undefined ? 4 : Number(cfg.maxPassiveReplies);
  const fallbackToActive = cfg.fallbackToActive !== false;
  const maxContentChars = cfg.maxContentChars === undefined ? 1500 : Number(cfg.maxContentChars);
  // 长文分段开关：默认开。splitLongText 关掉 = 老行为（超长直接截断补「…（已截断）」）。
  const splitLongText = cfg.splitLongText !== false;
  // 每段多少字：默认 min(maxContentChars, 1200)；显式配的也不能超过 maxContentChars。
  const partChars = Math.min(cfg.partChars === undefined ? 1200 : Number(cfg.partChars), maxContentChars);
  // 最多几段：默认 min(maxPassiveReplies, 4)，避免一段长文把被动回复额度用光。
  const maxParts = cfg.maxParts === undefined ? Math.min(Math.max(maxPassiveReplies, 1), 4) : Number(cfg.maxParts);
  // 发送重试：只对「重发一次就可能成功」的错误（网络层异常、HTTP 5xx/429）重试；
  // 被动回复过期/次数用尽交给下面的回退逻辑，参数错、鉴权错这类重发没用，原样抛出。
  const sendRetries = cfg.sendRetries === undefined ? 2 : Math.max(0, Number(cfg.sendRetries));
  const retryDelayMs = cfg.retryDelayMs === undefined ? 500 : Math.max(0, Number(cfg.retryDelayMs));
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const stats = {
    received: 0, groupReceived: 0, duplicates: 0, handlerErrors: 0,
    sendOk: 0, sendFailed: 0, passiveReplies: 0, activeReplies: 0, groupReplies: 0, expiredRetries: 0,
    typingOk: 0, typingFailed: 0, ready: 0, reconnects: 0, errors: 0, mediaMessages: 0, mediaFiles: 0,
    mediaUploads: 0, mediaUploadFailed: 0, mediaSent: 0, mediaFailed: 0,
    partsSent: 0, splitTruncated: 0, retryAttempts: 0, retryOk: 0,
  };
  const handlers = new Set();
  const seen = new Map();
  let lastOpenid = cfg.openid === undefined ? null : String(cfg.openid);
  let lastGroupOpenid = cfg.groupOpenid === undefined || !cfg.groupOpenid ? null : String(cfg.groupOpenid);
  let lastMemberOpenid = null;
  let lastChannel = null;   // 'c2c' | 'group'：最后一次收到的消息来自哪种会话
  let lastTargetId = null;  // 最后一次收到的消息所在的会话 id（单聊=user_openid，群聊=group_openid）
  let lastMsgId = null;
  let passiveSeq = 0;
  let passiveUsed = 0;
  let lastMessage = null;
  let recent = [];
  let lastError = null;
  // 用户的「主动消息」开关状态：unknown（还没收到过开关事件）/ on（开启）/ off（关闭）
  // 依据：官方事件 C2C_MSG_RECEIVE（开启）/ C2C_MSG_REJECT（关闭）；
  // 另外「不带 msg_id 的主动发送成功」也能反推 on（见 noteActivePushOk）。
  let activePush = 'unknown';
  let activePushAt = null;
  let activePushEvents = 0;

  const tokenManager = cfg.tokenManager || createTokenManager({
    appId: cfg.appId,
    clientSecret: cfg.clientSecret,
    baseUrl: cfg.baseUrl,
    fetchImpl: fetchImpl,
    logger: logger,
    timeoutMs: cfg.timeoutMs,
    marginMs: cfg.tokenMarginMs,
    now: cfg.now,
  });

  const api = cfg.api || createApi({
    baseUrl: cfg.baseUrl || DEFAULT_BASE,
    fetchImpl: fetchImpl,
    timeoutMs: cfg.timeoutMs,
    getToken: () => tokenManager.getToken(),
  });

  function remember(id) {
    if (id === null) return false;
    if (seen.has(id)) return true;
    seen.set(id, now());
    if (seen.size > seenLimit) {
      const oldest = seen.keys().next();
      if (!oldest.done) seen.delete(oldest.value);
    }
    return false;
  }

  // 不带 msg_id 的主动消息发成功了 => 说明用户的「主动消息」开关是开着的（文档：关掉后主动消息一律失败）。
  function noteActivePushOk() {
    if (activePush === 'on') return;
    activePush = 'on';
    activePushAt = new Date(now()).toISOString();
    logger({ kind: 'active-push-inferred-on' });
  }

  async function handleEvent(t, d) {
    // 用户开关「主动消息」推送（机器人资料卡上的那个开关）
    if (t === C2C_MSG_RECEIVE || t === C2C_MSG_REJECT) {
      const on = t === C2C_MSG_RECEIVE;
      activePush = on ? 'on' : 'off';
      activePushAt = new Date(now()).toISOString();
      activePushEvents += 1;
      const who = d && d.openid !== undefined && d.openid !== null ? String(d.openid) : null;
      logger({ kind: on ? 'active-push-on' : 'active-push-off', openid: who });
      return { type: t, openid: who, activePush: activePush };
    }
    if (t !== C2C_MESSAGE_CREATE && t !== GROUP_AT_MESSAGE_CREATE) return null;
    const isGroup = t === GROUP_AT_MESSAGE_CREATE;
    const id = d && d.id !== undefined && d.id !== null ? String(d.id) : null;
    if (remember(id)) {
      stats.duplicates += 1;
      logger({ kind: 'duplicate-message', id: id });
      return null;
    }
    const author = d && d.author ? d.author : null;
    // 单聊：目标会话 = 发消息人的 user_openid；群聊：目标会话 = group_openid，发言人 = member_openid
    const openid = isGroup
      ? (d && d.group_openid ? String(d.group_openid) : null)
      : (author && author.user_openid ? String(author.user_openid) : null);
    const memberOpenid = author && author.member_openid ? String(author.member_openid) : null;
    const text = d && typeof d.content === 'string' ? d.content : '';
    const attachments = parseAttachments(d && d.attachments);
    if (openid !== null) {
      lastTargetId = openid;
      if (isGroup) lastGroupOpenid = openid; else lastOpenid = openid;
    }
    if (memberOpenid !== null) lastMemberOpenid = memberOpenid;
    lastChannel = isGroup ? 'group' : 'c2c';
    if (id !== null) lastMsgId = id;
    passiveSeq = 0;      // 新的 msg_id 一进来，被动回复计数清零
    passiveUsed = 0;
    stats.received += 1;
    if (isGroup) stats.groupReceived += 1;
    if (attachments.length > 0) { stats.mediaMessages += 1; stats.mediaFiles += attachments.length; }
    const at = new Date(now()).toISOString();
    lastMessage = {
      id: id,
      openid: openid,
      memberOpenid: memberOpenid,
      channel: lastChannel,
      chars: text.length,
      at: at,
      messageType: d && d.message_type !== undefined ? d.message_type : null,
      media: attachments.length,
    };
    recent = [{ id: id, openid: openid, channel: lastChannel, chars: text.length, at: at, media: attachments.length }].concat(recent).slice(0, 20);
    logger({ kind: 'incoming', id: id, openid: openid, channel: lastChannel, chars: text.length, media: attachments.length });
    const message = {
      text: text,
      from: isGroup ? (memberOpenid || openid) : openid,
      openid: openid,
      groupOpenid: isGroup ? openid : null,
      memberOpenid: memberOpenid,
      channel: lastChannel,
      messageId: id,
      attachments: attachments,
      raw: d,
    };
    for (const h of handlers) {
      try {
        const out = h(message);
        if (out && typeof out.then === 'function') await out;
      } catch (e) {
        stats.handlerErrors += 1;
        lastError = 'handler: ' + msg(e);
        logger({ kind: 'handler-error', error: lastError });
      }
    }
    return message;
  }

  const gateway = cfg.gateway || createGatewaySocket({
    WebSocketImpl: cfg.WebSocketImpl,
    url: cfg.gatewayUrl,
    getGatewayUrl: () => api.getGateway(),
    getToken: () => tokenManager.getToken(),
    intents: cfg.intents === undefined ? DEFAULT_INTENTS : cfg.intents,
    shard: cfg.shard,
    properties: cfg.properties,
    heartbeatSlack: cfg.heartbeatSlack,
    heartbeatOverrideMs: cfg.heartbeatOverrideMs,
    resumeTtlMs: cfg.resumeTtlMs,
    autoReconnect: cfg.autoReconnect,
    baseBackoffMs: cfg.baseBackoffMs,
    maxBackoffMs: cfg.maxBackoffMs,
    logger: logger,
    now: cfg.now,
    onEvent: (t, d) => handleEvent(t, d),
    onState: (kind, detail) => {
      if (kind === 'ready' || kind === 'resumed') stats.ready += 1;
      if (kind === 'reconnect-scheduled') stats.reconnects += 1;
      if (kind === 'error') stats.errors += 1;
      if (kind === 'open-failed' || kind === 'auth-failed') lastError = detail && detail.error ? String(detail.error) : kind;
      if (typeof cfg.onState === 'function') {
        try { cfg.onState(kind, detail); } catch (e) { /* 上层回调失败不影响主流程 */ }
      }
    },
  });

  function pickOpenid(explicit, msgId) {
    if (explicit) return String(explicit);
    if (msgId !== null && msgId !== undefined && lastOpenid && lastChannel !== 'group') return lastOpenid;
    return cfg.openid || lastOpenid;
  }

  // 这条回复发给谁：显式指定的优先，其次看最近一条消息来自哪种会话（单聊 / 群聊）
  function resolveTarget(m, msgId) {
    const opts = m || {};
    const explicitGroup = opts.groupOpenid ? String(opts.groupOpenid) : null;
    const explicitChannel = opts.channel === 'group' || opts.channel === 'c2c' ? opts.channel : null;
    let channel = explicitChannel || (explicitGroup ? 'group' : null) || (opts.openid ? 'c2c' : null) || lastChannel;
    if (!channel) channel = 'c2c';
    if (channel === 'group') return { channel: channel, id: explicitGroup || lastGroupOpenid };
    return { channel: channel, id: pickOpenid(opts.openid, msgId) };
  }

  function clampText(text) {
    if (text.length <= maxContentChars) return text;
    return text.slice(0, maxContentChars) + '…（已截断）';
  }

  // 这条回复从哪个接口发出去（单聊 / 群聊）
  function deliver(target, payload) {
    return target.channel === 'group'
      ? (typeof api.sendGroup === 'function' ? api.sendGroup(target.id, payload) : Promise.reject(new Error('api 未实现 sendGroup')))
      : api.sendC2C(target.id, payload);
  }

  // 这个错重发一次有没有可能成功？只认「传输层失败」和「服务端打嗝」：
  //   * fetch / 取 token 失败：既没 status 也没 errCode（qq-api 抛的是裸 Error）
  //   * HTTP 5xx / 429
  // 被动回复过期（40034005）、次数用尽（40034124）不算：原地重发同一个 msg_id 也没用。
  function retriableSendError(e) {
    if (!e) return false;
    const status = typeof e.status === 'number' ? e.status : null;
    const code = typeof e.errCode === 'number' ? e.errCode : null;
    if (code === ERR_MSG_ID_EXPIRED || code === ERR_MSG_ID_LIMIT) return false;
    if (status === null && code === null) return true;
    if (status !== null && (status >= 500 || status === 429)) return true;
    if (code !== null && status === null && code >= 500) return true;
    return false;
  }

  // 一次投递（含重试）：2026-10-13 15:45 丢过一条 198 字的消息，当时网络打嗝直接抛出去，
  // 桥那边只记了一条 send-failed。这里改成自动重发，最多 sendRetries 次。
  // 注意：被动回复的 msg_id + msg_seq 组合只能发一次，所以每次重试都换一个新 msg_seq。
  async function deliverWithRetry(target, payload, partInfo) {
    const part = partInfo ? partInfo.index : 1;
    const parts = partInfo ? partInfo.total : 1;
    let attempt = 0;
    for (;;) {
      try {
        const out = await deliver(target, payload);
        if (attempt > 0) {
          stats.retryOk += 1;
          logger({ kind: 'send-retry-ok', attempt: attempt, of: sendRetries, channel: target.channel, part: part, parts: parts });
        }
        return out;
      } catch (e) {
        if (attempt >= sendRetries || !retriableSendError(e)) throw e;
        attempt += 1;
        stats.retryAttempts += 1;
        logger({
          kind: 'send-retry', attempt: attempt, of: sendRetries, channel: target.channel,
          status: typeof e.status === 'number' ? e.status : null,
          errCode: typeof e.errCode === 'number' ? e.errCode : null,
          error: msg(e), part: part, parts: parts,
        });
        // 被动回复：换新 msg_seq 才允许用同一个 msg_id 再发一次
        if (payload.msg_seq !== undefined) {
          passiveSeq += 1;
          payload.msg_seq = passiveSeq;
        }
        await delay(retryDelayMs * attempt);
      }
    }
  }

  // 富媒体：先 POST /v2/{users|groups}/{id}/files 拿 file_info（srv_send_msg=false），
  // 再用 msg_type=7 + media.file_info 发出去（被动回复照旧带 msg_id/msg_seq）。
  async function uploadMedia(target, media) {
    const req = buildUploadRequest(media);
    const isGroup = target.channel === 'group';
    const fn = isGroup ? api.uploadGroup : api.uploadC2C;
    if (typeof fn !== 'function') throw new Error(isGroup ? 'api 未实现 uploadGroup' : 'api 未实现 uploadC2C');
    const info = fileInfoOf(await fn(target.id, req));
    if (info === null) throw new Error('上传成功但响应里没有 file_info');
    return info;
  }

  // 单条消息的完整发送流程（目标解析、被动/主动、过期回退）——长文分段时每段各走一遍
  async function sendOnce(text, m, hasMedia, partInfo) {
    // 目标：显式指定的优先，其次看最近一条消息来自哪种会话（单聊 / 群聊）。
    // 只有走主动消息（没有 msg_id）时才用 cfg.openid 这个固定目标。
    const target = resolveTarget(m, m.msgId || lastMsgId);
    // 被动回复的 msg_id 和会话绑定：只有回复的正是「最近那条消息所在的会话」时才带 msg_id，
    // 显式改发给别人（另一个用户/群）时必须走主动消息，否则平台会以 40034005 拒掉。
    const explicitMsgId = m.msgId || null;
    const msgId = explicitMsgId !== null
      ? explicitMsgId
      : (target.id && lastTargetId && String(target.id) === String(lastTargetId) ? lastMsgId : null);
    if (!target.id) throw new Error(target.channel === 'group' ? 'no-group-openid: 还没有群聊消息' : 'no-openid: 还没有人给机器人发过消息');
    const passiveWanted = m.passive !== false && cfg.passive !== false && msgId !== null && passiveUsed < maxPassiveReplies;
    let payload = null;
    if (hasMedia) {
      let fileInfo = null;
      try {
        fileInfo = await uploadMedia(target, m.media);
        stats.mediaUploads += 1;
      } catch (e) {
        stats.mediaUploadFailed += 1;
        lastError = 'media-upload: ' + msg(e);
        logger({ kind: 'media-upload-failed', channel: target.channel, error: msg(e) });
        throw e;
      }
      payload = { msg_type: MSG_TYPE_RICH_MEDIA, media: { file_info: fileInfo } };
      if (text) payload.content = text;
    } else {
      payload = { content: text, msg_type: m.msgType === undefined ? 0 : Number(m.msgType) };
    }
    if (passiveWanted) {
      passiveSeq += 1;
      payload.msg_id = msgId;
      // 相同 msg_id + msg_seq 重复发送会失败，所以每次都递增
      payload.msg_seq = passiveSeq;
    }
    try {
      const out = await deliverWithRetry(target, payload, partInfo);
      stats.sendOk += 1;
      if (target.channel === 'group') stats.groupReplies += 1;
      if (hasMedia) stats.mediaSent += 1;
      if (passiveWanted) { stats.passiveReplies += 1; passiveUsed += 1; } else { stats.activeReplies += 1; if (target.channel === 'c2c') noteActivePushOk(); }
      logger({ kind: 'send', chars: text.length, passive: passiveWanted, channel: target.channel, media: hasMedia, part: partInfo.index, parts: partInfo.total });
      return out;
    } catch (e) {
      stats.sendFailed += 1;
      if (hasMedia) stats.mediaFailed += 1;
      lastError = 'send: ' + msg(e);
      const expired = e && (e.errCode === ERR_MSG_ID_EXPIRED || e.errCode === ERR_MSG_ID_LIMIT);
      // 被动回复窗口过了/次数用尽：退回主动消息再试一次（受平台主动消息配额限制）
      if (passiveWanted && expired && fallbackToActive) {
        stats.expiredRetries += 1;
        passiveUsed = maxPassiveReplies;
        // 退回主动消息：把 msg_id/msg_seq 摘掉，其余载荷（文字或 media.file_info）原样再发
        const activePayload = Object.assign({}, payload);
        delete activePayload.msg_id;
        delete activePayload.msg_seq;
        const out2 = await deliverWithRetry(target, activePayload, partInfo);
        stats.sendOk += 1;
        if (target.channel === 'group') stats.groupReplies += 1;
        if (hasMedia) stats.mediaSent += 1;
        stats.activeReplies += 1;
        if (target.channel === 'c2c') noteActivePushOk();
        logger({ kind: 'send-active-fallback', chars: text.length, channel: target.channel, media: hasMedia, errCode: e.errCode === undefined ? null : e.errCode, part: partInfo.index, parts: partInfo.total });
        return out2;
      }
      throw e;
    }
  }

  // 对外接口：长文先分段再逐段发（分段只影响纯文字；带图时图只挂在第一段上，不会重复上传）
  async function send(message) {
    const m = message || {};
    const hasMedia = m.media !== undefined && m.media !== null;
    const hasText = m.text !== undefined && m.text !== null;
    if (!hasMedia && !hasText) throw new Error('text 为空');
    let parts = [''];
    let rawChars = 0;
    if (hasText) {
      const raw = String(m.text);
      rawChars = raw.length;
      // 带图时允许空文字（只发图）；不带图时保持老规矩：空/全空白直接报错
      if (!raw.trim() && !hasMedia) throw new Error('text 为空');
      if (splitLongText) {
        const r = splitText(raw, partChars, maxParts);
        parts = r.parts;
        if (r.truncated) {
          stats.splitTruncated += 1;
          logger({ kind: 'split-truncated', chars: rawChars, parts: r.parts.length, dropped: r.dropped });
        }
      } else {
        parts = [clampText(raw)];
      }
    }
    const multi = parts.length > 1;
    if (multi) logger({ kind: 'split', chars: rawChars, parts: parts.length, partChars: partChars });
    let out = null;
    for (let i = 0; i < parts.length; i += 1) {
      // 图只跟第一段一起发，剩下的纯文字段不再重复上传同一张图
      out = await sendOnce(parts[i], m, hasMedia && i === 0, { index: i + 1, total: parts.length });
      if (multi) stats.partsSent += 1;
    }
    return out;
  }

  // 输入中状态：msg_type 6 + input_notify，同样要带 msg_id/msg_seq（每个组合只能发一次）
  async function typing() {
    if (lastMsgId === null) throw new Error('no-msg-id');
    const target = resolveTarget({}, lastMsgId);
    if (!target.id) throw new Error(target.channel === 'group' ? 'no-group-openid' : 'no-openid');
    const seq = maxPassiveReplies + 10 + (passiveSeq += 1);
    // 字段名必须是 input_type（写成 type 会被平台拒掉：40011021 请求参数 input_notify.input_type 无效）
    const payload = { msg_type: 6, input_notify: { input_type: 1 }, msg_id: lastMsgId, msg_seq: seq };
    try {
      const out = await deliver(target, payload);
      stats.typingOk += 1;
      return out;
    } catch (e) {
      stats.typingFailed += 1;
      lastError = 'typing: ' + msg(e);
      throw e;
    }
  }

  function onMessage(handler) {
    handlers.add(handler);
    return () => handlers.delete(handler);
  }

  async function start() {
    const st = await gateway.start();
    return st;
  }

  function stop() {
    return gateway.stop();
  }

  function state() {
    const g = gateway.state();
    return {
      ready: g.identified === true,
      connected: g.connected,
      sessionId: g.sessionId,
      seq: g.seq,
      intents: g.intents,
      lastOpenid: lastOpenid,
      lastGroupOpenid: lastGroupOpenid,
      lastMemberOpenid: lastMemberOpenid,
      lastChannel: lastChannel,
      lastMsgId: lastMsgId,
      activePush: activePush,
      activePushAt: activePushAt,
      activePushEvents: activePushEvents,
      activePushLabel: activePush === 'on' ? '可用' : (activePush === 'off' ? '已关闭' : '未知（还没收到过开关事件）'),
      lastMessage: lastMessage,
      recent: recent,
      lastError: lastError === null ? g.lastError : lastError,
      gateway: g,
      stats: stats,
      token: tokenManager.peek(),
    };
  }

  return {
    start: start,
    stop: stop,
    send: send,
    typing: typing,
    onMessage: onMessage,
    state: state,
    stats: stats,
    api: api,
    gateway: gateway,
    tokenManager: tokenManager,
    handleEvent: handleEvent,   // 测试/自检用
    seenSize: () => seen.size,
  };
}

export default createQq;
