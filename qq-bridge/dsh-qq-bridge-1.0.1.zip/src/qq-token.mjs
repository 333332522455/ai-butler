// qq/qq-token.mjs — QQ 官方机器人 AccessToken 管理（自动刷新，无人工扫码）
// 文档依据：POST https://api.bot.qq.com/app/getAppAccessToken  body {appId, clientSecret}
//           -> {access_token, expires_in}（expires_in 在 7200 秒内）
// 关键点：access_token 会过期，程序必须提前刷新；这正是不用像 iLink 那样每 24h 人工扫码的原因。

export const DEFAULT_BASE = 'https://api.bot.qq.com';
export const DEFAULT_MARGIN_MS = 5 * 60 * 1000; // 提前 5 分钟刷新

function msg(e) { return (e && e.message) || String(e); }

export function createTokenManager(config = {}) {
  const cfg = config || {};
  const appId = String(cfg.appId === undefined ? '' : cfg.appId);
  const clientSecret = String(cfg.clientSecret === undefined ? '' : cfg.clientSecret);
  const baseUrl = cfg.baseUrl || DEFAULT_BASE;
  const fetchImpl = cfg.fetchImpl || globalThis.fetch;
  const now = typeof cfg.now === 'function' ? cfg.now : () => Date.now();
  const marginMs = cfg.marginMs === undefined ? DEFAULT_MARGIN_MS : Number(cfg.marginMs);
  const timeoutMs = cfg.timeoutMs === undefined ? 10000 : Number(cfg.timeoutMs);
  const logger = typeof cfg.logger === 'function' ? cfg.logger : () => {};
  const stats = { fetches: 0, failures: 0, lastError: null };
  let token = null;
  let expiresAt = 0;
  let inflight = null;

  function hasFreshToken() {
    return token !== null && now() < expiresAt - marginMs;
  }

  async function fetchToken() {
    if (!appId || !clientSecret) throw new Error('missing-appId-or-clientSecret');
    stats.fetches += 1;
    const init = {
      method: 'POST',
      headers: { 'content-type': 'application/json; charset=utf-8' },
      body: JSON.stringify({ appId: appId, clientSecret: clientSecret }),
    };
    if (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) init.signal = AbortSignal.timeout(timeoutMs);
    let res = null;
    try {
      res = await fetchImpl(baseUrl + '/app/getAppAccessToken', init);
    } catch (e) {
      stats.failures += 1;
      stats.lastError = 'token-fetch: ' + msg(e);
      throw new Error(stats.lastError);
    }
    let body = null;
    try { body = await res.json(); } catch (e) { body = null; }
    if (!res.ok) {
      stats.failures += 1;
      stats.lastError = 'token-http ' + res.status + ' ' + JSON.stringify(body);
      throw new Error(stats.lastError);
    }
    if (!body || !body.access_token) {
      stats.failures += 1;
      stats.lastError = 'token-bad-body ' + JSON.stringify(body);
      throw new Error(stats.lastError);
    }
    token = String(body.access_token);
    const ttlMs = Number(body.expires_in) > 0 ? Number(body.expires_in) * 1000 : 7200 * 1000;
    expiresAt = now() + ttlMs;
    stats.lastError = null;
    logger({ kind: 'token-refreshed', ttlMs: ttlMs, at: new Date(now()).toISOString() });
    return token;
  }

  // 并发调用只发一次刷新请求；到期前 marginMs 就刷新。
  async function getToken(options) {
    const force = options && options.force === true;
    if (!force && hasFreshToken()) return token;
    if (inflight !== null) return inflight;
    inflight = fetchToken().finally(() => { inflight = null; });
    return inflight;
  }

  return {
    stats: stats,
    getToken: getToken,
    invalidate: () => { token = null; expiresAt = 0; },
    peek: () => ({ hasToken: token !== null, expiresAt: expiresAt, fresh: hasFreshToken() }),
  };
}

export default createTokenManager;
