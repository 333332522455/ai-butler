// qq/qq-ws.mjs — QQ 官方机器人 WebSocket 网关客户端（自己实现，不引第三方库）
// 协议（官方文档 dev-prepare/event-emit/websocket + payload）：
//   GET /gateway -> {url: wss://api.bot.qq.com/websocket/}
//   连上收 op10 Hello {heartbeat_interval:45000} -> 发 op2 Identify {token:'QQBot {AccessToken}', intents, shard, properties}
//   -> 收 op0 READY {session_id, user}；心跳 op1 {d:<最新 s>} -> op11 ACK
//   断线重连发 op6 Resume {token, session_id, seq} -> RESUMED（自动补发遗漏事件）
//   op7 Reconnect / op9 Invalid Session
// 权限注意：除 GUILDS(1<<0) / PUBLIC_GUILD_MESSAGES(1<<30) / GUILD_MEMBERS(1<<1) 外，
//   其他 intents 都要先在开放平台申请；传了无权限的 intents，网关会直接报错并断开连接。
//   所以 intents 一律可配，默认只订单聊/群聊事件位，别硬塞一堆。

export const OP = {
  DISPATCH: 0,
  HEARTBEAT: 1,
  IDENTIFY: 2,
  RESUME: 6,
  RECONNECT: 7,
  INVALID_SESSION: 9,
  HELLO: 10,
  HEARTBEAT_ACK: 11,
};

function msg(e) { return (e && e.message) || String(e); }

export function createGatewaySocket(config = {}) {
  const cfg = config || {};
  const WebSocketImpl = cfg.WebSocketImpl || globalThis.WebSocket;
  if (typeof WebSocketImpl !== 'function') throw new Error('no-WebSocket-implementation');
  const getToken = cfg.getToken || (async () => { throw new Error('no-getToken'); });
  const getGatewayUrl = cfg.getGatewayUrl || null;
  const logger = typeof cfg.logger === 'function' ? cfg.logger : () => {};
  const onEvent = typeof cfg.onEvent === 'function' ? cfg.onEvent : () => {};
  const onState = typeof cfg.onState === 'function' ? cfg.onState : () => {};
  const intents = cfg.intents === undefined ? (1 << 25) : Number(cfg.intents);
  const shard = Array.isArray(cfg.shard) ? cfg.shard.map((n) => Number(n)) : [0, 1];
  const properties = cfg.properties || { $os: 'windows', $browser: 'dsh-qq-leg', $device: 'dsh-qq-leg' };
  const slack = cfg.heartbeatSlack === undefined ? 0.9 : Number(cfg.heartbeatSlack);
  const heartbeatOverrideMs = cfg.heartbeatOverrideMs === undefined ? null : Number(cfg.heartbeatOverrideMs);
  const resumeTtlMs = cfg.resumeTtlMs === undefined ? 5 * 60 * 1000 : Number(cfg.resumeTtlMs);
  const maxBackoffMs = cfg.maxBackoffMs === undefined ? 30000 : Number(cfg.maxBackoffMs);
  const baseBackoffMs = cfg.baseBackoffMs === undefined ? 1000 : Number(cfg.baseBackoffMs);
  const autoReconnect = cfg.autoReconnect !== false;
  const setTimer = typeof cfg.setTimeoutImpl === 'function' ? cfg.setTimeoutImpl : setTimeout;
  const clearTimer = typeof cfg.clearTimeoutImpl === 'function' ? cfg.clearTimeoutImpl : clearTimeout;
  const setRepeater = typeof cfg.setIntervalImpl === 'function' ? cfg.setIntervalImpl : setInterval;
  const clearRepeater = typeof cfg.clearIntervalImpl === 'function' ? cfg.clearIntervalImpl : clearInterval;
  const now = typeof cfg.now === 'function' ? cfg.now : () => Date.now();

  const stats = { connects: 0, identifies: 0, resumes: 0, heartbeats: 0, acks: 0, dispatches: 0, closes: 0, errors: 0, reconnects: 0 };
  let ws = null;
  let heartbeatTimer = null;
  let reconnectTimer = null;
  let stopping = false;
  let attempt = 0;
  let sessionId = null;
  let seq = null;
  let connected = false;
  let identified = false;
  let helloIntervalMs = 45000;
  let lastError = null;
  let lastClose = null;
  let readyAt = null;
  let sessionStartedAt = 0;
  let missedAcks = 0;

  function emit(kind, detail) {
    try { onState(kind, detail || {}); } catch (e) { /* 状态回调失败不影响主流程 */ }
    logger(Object.assign({ kind: 'ws-' + kind }, detail || {}));
  }

  function send(payload) {
    if (ws === null) { lastError = 'ws-not-open'; return false; }
    try {
      ws.send(JSON.stringify(payload));
      return true;
    } catch (e) {
      lastError = 'ws-send: ' + msg(e);
      return false;
    }
  }

  function stopHeartbeat() {
    if (heartbeatTimer !== null) { clearRepeater(heartbeatTimer); heartbeatTimer = null; }
  }

  function startHeartbeat() {
    stopHeartbeat();
    const interval = heartbeatOverrideMs !== null ? heartbeatOverrideMs : Math.max(1000, Math.floor(helloIntervalMs * slack));
    const maxMissedAcks = cfg.maxMissedAcks === undefined ? 3 : Number(cfg.maxMissedAcks);
    missedAcks = 0;
    heartbeatTimer = setRepeater(() => {
      // 心跳发了没人 ACK，说明这条 TCP 已经假活（拔网线、NAT 超时、代理挂了都可能
      // 不报 close）。累到上限就主动关掉走重连，否则进程会一直「看着像好的」。
      if (missedAcks >= maxMissedAcks) {
        emit('heartbeat-stall', { missedAcks: missedAcks });
        closeSocket(4003, 'heartbeat-timeout');
        if (autoReconnect && !stopping) scheduleReconnect();
        return;
      }
      stats.heartbeats += 1;
      missedAcks += 1;
      // 第一次连接时 s 为 null（官方文档：传 null）
      send({ op: OP.HEARTBEAT, d: seq });
    }, interval);
    emit('heartbeat-started', { intervalMs: interval });
  }

  async function authenticate() {
    let token = null;
    try {
      token = await getToken();
    } catch (e) {
      // 关键坑（2026-10-20 实锤）：以前这里只打日志就 return —— 连接是好的，
      // 但永远停在「open 了却没 Identify」的假活状态：心跳没起、不会 close、
      // 也就永远不会重连，只能人工重启进程。断网时最后一次日志正是
      // 'get-token: token-fetch: fetch failed'，之后 journal 里零 ws 事件。
      // 所以拿不到 token 必须主动关掉这条连接，让 onclose 走退避重连。
      lastError = 'get-token: ' + msg(e);
      emit('auth-failed', { error: lastError });
      closeSocket(4002, 'auth-failed');
      if (autoReconnect && !stopping) scheduleReconnect();
      return;
    }
    const value = 'QQBot ' + token;
    // 会话还新鲜才 Resume，否则 Identify 开新会话。
    const canResume = sessionId !== null && seq !== null && (now() - sessionStartedAt) < resumeTtlMs;
    if (canResume) {
      stats.resumes += 1;
      send({ op: OP.RESUME, d: { token: value, session_id: sessionId, seq: seq } });
      emit('resume-sent', { seq: seq });
    } else {
      stats.identifies += 1;
      send({ op: OP.IDENTIFY, d: { token: value, intents: intents, shard: shard, properties: properties } });
      emit('identify-sent', { intents: intents, shard: shard });
    }
    startHeartbeat();
  }

  function handle(pkt) {
    if (pkt === null || typeof pkt !== 'object') return;
    const op = Number(pkt.op);
    const d = pkt.d;
    if (op === OP.HELLO) {
      const iv = d && Number(d.heartbeat_interval) > 0 ? Number(d.heartbeat_interval) : 45000;
      helloIntervalMs = iv;
      emit('hello', { heartbeatInterval: iv });
      authenticate().catch((e) => { lastError = 'auth: ' + msg(e); });
      return;
    }
    if (op === OP.DISPATCH) {
      if (typeof pkt.s === 'number') seq = pkt.s;
      stats.dispatches += 1;
      const t = pkt.t === undefined || pkt.t === null ? null : String(pkt.t);
      if (t === 'READY') {
        sessionId = d && d.session_id ? String(d.session_id) : sessionId;
        identified = true;
        sessionStartedAt = now();
        readyAt = new Date(now()).toISOString();
        attempt = 0;
        emit('ready', { sessionId: sessionId, user: d && d.user ? d.user : null });
      } else if (t === 'RESUMED') {
        identified = true;
        sessionStartedAt = now();
        readyAt = new Date(now()).toISOString();
        attempt = 0;
        emit('resumed', { sessionId: sessionId });
      }
      try {
        const out = onEvent(t, d, pkt);
        if (out && typeof out.then === 'function') out.catch((e) => { lastError = 'onEvent: ' + msg(e); });
      } catch (e) {
        lastError = 'onEvent: ' + msg(e);
      }
      return;
    }
    if (op === OP.HEARTBEAT_ACK) { stats.acks += 1; missedAcks = 0; return; }
    if (op === OP.RECONNECT) { emit('reconnect-requested', {}); closeSocket(4000, 'op7-reconnect'); return; }
    if (op === OP.INVALID_SESSION) {
      // 会话失效：丢掉 session/seq，下次连按 Identify 重新开始
      sessionId = null;
      seq = null;
      emit('invalid-session', {});
      closeSocket(4001, 'op9-invalid-session');
      return;
    }
    emit('unknown-op', { op: op });
  }

  function handleRaw(raw) {
    let text = raw;
    if (raw && typeof raw === 'object' && raw.data !== undefined) text = raw.data;
    if (typeof text !== 'string') {
      try { text = String(text); } catch (e) { return; }
    }
    let pkt = null;
    try { pkt = JSON.parse(text); } catch (e) { lastError = 'bad-json: ' + msg(e); return; }
    handle(pkt);
  }

  function closeSocket(code, reason) {
    if (ws === null) return;
    try { ws.close(code, reason); } catch (e) { /* 关不掉也就算了，onclose 会兜底 */ }
  }

  async function open() {
    if (stopping) return state();
    let url = cfg.url || null;
    if (!url && getGatewayUrl !== null) {
      const info = await getGatewayUrl();
      url = info && info.url ? String(info.url) : null;
    }
    if (!url) throw new Error('no-gateway-url');
    stats.connects += 1;
    const sock = new WebSocketImpl(url);
    ws = sock;
    sock.onopen = () => {
      connected = true;
      identified = false;
      // 注意：不在这里把 attempt 清零。以前清了，导致「连上就断/鉴权失败」这种
      // 场景永远按 1s 重试，退避形同虚设。清零只放在收到 READY / RESUMED 时。
      emit('open', { url: url });
    };
    sock.onmessage = (ev) => handleRaw(ev);
    sock.onclose = (ev) => {
      connected = false;
      identified = false;
      stopHeartbeat();
      stats.closes += 1;
      lastClose = ev ? { code: ev.code === undefined ? null : ev.code, reason: ev.reason === undefined ? null : ev.reason } : null;
      emit('close', lastClose || {});
      if (autoReconnect && !stopping) scheduleReconnect();
    };
    sock.onerror = (ev) => {
      stats.errors += 1;
      lastError = 'ws-error';
      emit('error', { event: ev == null ? null : 'error' });
    };
    return state();
  }

  function scheduleReconnect() {
    if (stopping || !autoReconnect || reconnectTimer !== null) return;
    attempt += 1;
    const delay = Math.min(maxBackoffMs, baseBackoffMs * Math.pow(2, Math.min(attempt - 1, 5)));
    stats.reconnects += 1;
    emit('reconnect-scheduled', { attempt: attempt, delayMs: delay });
    reconnectTimer = setTimer(() => {
      reconnectTimer = null;
      open().catch((e) => {
        lastError = 'open: ' + msg(e);
        emit('open-failed', { error: lastError });
        if (autoReconnect && !stopping) scheduleReconnect();
      });
    }, delay);
  }

  function state() {
    return {
      connected: connected,
      identified: identified,
      sessionId: sessionId,
      seq: seq,
      intents: intents,
      shard: shard,
      readyAt: readyAt,
      lastError: lastError,
      lastClose: lastClose,
      stats: stats,
    };
  }

  async function start() {
    stopping = false;
    attempt = 0;
    await open();
    return state();
  }

  function stop() {
    stopping = true;
    stopHeartbeat();
    if (reconnectTimer !== null) { clearTimer(reconnectTimer); reconnectTimer = null; }
    closeSocket(1000, 'stop');
    connected = false;
    identified = false;
    ws = null;
    return state();
  }

  return {
    start: start,
    stop: stop,
    state: state,
    stats: stats,
    OP: OP,
    heartbeatOnce: () => { stats.heartbeats += 1; return send({ op: OP.HEARTBEAT, d: seq }); },
    inject: (pkt) => handle(pkt),      // 测试/自检用：直接把网关报文喂进来
    injectRaw: (raw) => handleRaw(raw),
    get socket() { return ws; },
  };
}

export default createGatewaySocket;
