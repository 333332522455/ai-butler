// qq/live-qq.mjs — QQ 官方机器人腿的真机入口
// 和 ilink 的 live-real.mjs 不同：QQ 官方用 AppID + ClientSecret 换 access_token，
// 没有二维码、没有 24 小时重扫，一次配好就能常驻。
//
// 用法：
//   $env:ELECTRON_RUN_AS_NODE='1'; & "D:\新建文件夹 (2)\DSH Desktop\DSH Desktop.exe" qq\live-qq.mjs
//   ... --state=D:\sleep\dsh-wechat-bridge\.state\qq.json --check   只看配置，不连网
//
// 凭据来源优先级：命令行 > 环境变量 > 状态文件。状态文件默认 .state\qq.json：
//   { "appId": "102000123", "clientSecret": "xxxx", "intents": 33554432, "openid": "" }
// openid 可以留空：收到第一条消息后会自动记住发消息的人，之后回复就找他。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServe, DEFAULT_PORT, DEFAULT_INBOX_URL, DEFAULT_PREFIX } from './serve.mjs';
import { DEFAULT_INTENTS } from './qq.mjs';
import { createMediaStore } from './qq-media.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
// 可分享版：默认配置放在「当前工作目录/.state/qq.json」，不再写死作者机器上的路径。
// 换目录跑就用 --state 或 QQ_STATE 指定。
export const DEFAULT_STATE_FILE = path.join(process.cwd(), '.state', 'qq.json');

function msg(e) { return (e && e.message) || String(e); }

export function maskSecret(s) {
  const v = s === undefined || s === null ? '' : String(s);
  if (!v) return '(空)';
  if (v.length <= 6) return v.slice(0, 1) + '***';
  return v.slice(0, 3) + '***' + v.slice(-2) + '（' + v.length + ' 位）';
}

export function loadState(file) {
  const p = file || DEFAULT_STATE_FILE;
  let raw = null;
  try { raw = fs.readFileSync(p, 'utf8'); }
  catch (e) {
    const err = new Error('读不到状态文件 ' + p + '：' + msg(e));
    err.code = 'state-missing';
    err.stateFile = p;
    throw err;
  }
  // Windows 上的常见坑：PowerShell 5.1 的 Set-Content -Encoding UTF8、记事本存 UTF-8 都会带上 BOM，
  // 而 JSON.parse 不认 BOM，会把一份好配置判成坏 JSON。先剥掉再说。
  if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
  let obj = null;
  try { obj = JSON.parse(raw); } catch (e) {
    const err = new Error('状态文件不是合法 JSON（' + p + '）：' + msg(e));
    err.code = 'state-bad-json';
    throw err;
  }
  if (!obj || typeof obj !== 'object') {
    const err = new Error('状态文件内容不是对象（' + p + '）');
    err.code = 'state-bad-shape';
    throw err;
  }
  obj.__file = p;
  return obj;
}

function pick(flag, envName, state, key) {
  if (flag !== undefined && flag !== null && flag !== '' && flag !== true) return String(flag);
  const env = globalThis.process && globalThis.process.env ? globalThis.process.env[envName] : undefined;
  if (env !== undefined && env !== null && env !== '') return String(env);
  if (state && state[key] !== undefined && state[key] !== null && state[key] !== '') return String(state[key]);
  return null;
}

// 把「命令行 + 环境变量 + 状态文件」合成 createServe 的配置。纯函数，便于离线自检。
export function resolveConfig(options) {
  const o = options || {};
  const args = o.args || {};
  const state = o.state || null;
  const appId = pick(args['app-id'], 'QQ_APP_ID', state, 'appId');
  const clientSecret = pick(args.secret, 'QQ_CLIENT_SECRET', state, 'clientSecret');
  const port = args.port !== undefined ? Number(args.port) : (state && state.port ? Number(state.port) : DEFAULT_PORT);
  const intents = args.intents !== undefined ? Number(args.intents) : (state && state.intents ? Number(state.intents) : DEFAULT_INTENTS);
  const openid = pick(args.openid, 'QQ_OPENID', state, 'openid');
  const inboxUrl = pick(args.inbox, 'QQ_INBOX', state, 'inboxUrl') || DEFAULT_INBOX_URL;
  const prefix = args.prefix !== undefined && args.prefix !== true ? String(args.prefix) : (state && state.prefix ? String(state.prefix) : DEFAULT_PREFIX);
  const journalFile = pick(args.journal, 'QQ_JOURNAL', state, 'journalFile');
  const gatewayUrl = pick(args.gateway, 'QQ_GATEWAY', state, 'gatewayUrl');
  const stateFile = pick(args.state, 'QQ_STATE', state, '__file') || DEFAULT_STATE_FILE;
  // 附件落盘目录：默认放在状态文件旁边的 media\ 下，跟着 .state 一起走
  const mediaDir = pick(args.media, 'QQ_MEDIA', state, 'mediaDir') || path.join(path.dirname(stateFile), 'media');
  const missing = [];
  if (!appId) missing.push('appId');
  if (!clientSecret) missing.push('clientSecret');
  return {
    appId: appId, clientSecret: clientSecret, port: port, intents: intents, openid: openid,
    inboxUrl: inboxUrl, prefix: prefix, journalFile: journalFile, gatewayUrl: gatewayUrl,
    stateFile: stateFile, mediaDir: mediaDir, missing: missing,
  };
}

// 两种写法都认：--port=1234（等号）和 --port 1234（空格）。
// 空格形式只在下一个参数不是 -- 开头时才吞它，否则当前开关当作 true。
export function parseArgs(argv) {
  const out = {};
  const list = (argv || []).map((x) => String(x));
  for (let i = 0; i < list.length; i++) {
    const a = list[i];
    if (!a.startsWith('--')) continue;
    const eq = a.indexOf('=');
    if (eq !== -1) {
      out[a.slice(2, eq)] = a.slice(eq + 1);
      continue;
    }
    const key = a.slice(2);
    const next = list[i + 1];
    if (next !== undefined && next !== '' && !next.startsWith('-')) {
      out[key] = next;
      i++;
    } else {
      out[key] = true;
    }
  }
  return out;
}

export function describe(cfg) {
  return [
    '  appId        : ' + (cfg.appId || '(缺)'),
    '  clientSecret : ' + maskSecret(cfg.clientSecret),
    '  端口         : ' + cfg.port,
    '  intents      : ' + cfg.intents + (cfg.intents === DEFAULT_INTENTS ? '（GROUP_AND_C2C_EVENT，单聊消息）' : ''),
    '  inbox        : ' + cfg.inboxUrl,
    '  前缀         : ' + JSON.stringify(cfg.prefix),
    '  状态文件     : ' + cfg.stateFile,
    '  附件目录     : ' + (cfg.mediaDir || '(不存)'),
    '  journal      : ' + (cfg.journalFile || '(不写)'),
    '  固定 openid  : ' + (cfg.openid || '(空，收到消息后自动记住)'),
  ].join('\n');
}

async function main(argv) {
  const args = parseArgs(argv || process.argv.slice(2));
  const stateFile = args.state !== undefined && args.state !== true ? String(args.state) : DEFAULT_STATE_FILE;
  let state = null;
  try { state = loadState(stateFile); }
  catch (e) {
    // 第一次用还没建状态文件：静默降级，交给下面 cfg.missing 给友好提示。
    // 其它错误（坏 JSON / 形状不对）必须硬失败，别把配置问题吞了。
    if (e.code !== 'state-missing') throw e;
    state = null;
  }
  const cfg = resolveConfig({ args: args, state: state });
  console.log('[live-qq] 配置：');
  console.log(describe(cfg));
  if (cfg.missing.length > 0) {
    console.error('[live-qq] 缺少 ' + cfg.missing.join(' / ') + '，没法连 QQ。');
    console.error('[live-qq] 去 https://q.qq.com/ 建好机器人后，把 AppID 和 AppSecret 写进 ' + cfg.stateFile + '：');
    console.error('           { "appId": "102xxxxxx", "clientSecret": "你的密钥" }');
    process.exitCode = 2;
    return;
  }
  if (args.check === true || args.check === 'true') {
    console.log('[live-qq] --check：配置齐全，没连网。要真跑就去掉 --check。');
    return;
  }

  const mediaStore = createMediaStore({
    dir: cfg.mediaDir,
    logger: (entry) => console.log('[live-qq] ' + JSON.stringify(entry)),
  });
  const serve = createServe({
    appId: cfg.appId,
    clientSecret: cfg.clientSecret,
    port: cfg.port,
    inboxUrl: cfg.inboxUrl,
    prefix: cfg.prefix,
    intents: cfg.intents,
    openid: cfg.openid,
    gatewayUrl: cfg.gatewayUrl || undefined,
    journalFile: cfg.journalFile,
    mediaStore: mediaStore,
    logger: (line) => console.log('[live-qq] ' + (typeof line === 'string' ? line : JSON.stringify(line))),
  });
  const addr = await serve.start();
  const base = 'http://127.0.0.1:' + String(addr ? addr.port : cfg.port);
  console.log('[live-qq] 已监听 ' + base);
  console.log('[live-qq] 看状态：' + base + '/status');
  console.log('[live-qq] 自测（假装收到一条消息），PowerShell 里跑：');
  console.log("          Invoke-RestMethod -Method Post -Uri " + base + "/inject -ContentType 'application/json' -Body '{\"id\":\"t1\",\"text\":\"你好\",\"openid\":\"你的openid\"}'");
  console.log('[live-qq] 收到的图片/语音/文件会存到：' + cfg.mediaDir);
  console.log('[live-qq] 然后往 QQ 里给机器人发条消息试试；第一次收到消息后会自动记住你的 openid。');

  const shutdown = async (sig) => {
    console.log('[live-qq] 收到 ' + sig + '，收摊……');
    try { await serve.stop(); } catch (e) { console.error('[live-qq] stop 失败：' + msg(e)); }
    process.exit(0);
  };
  process.on('SIGINT', () => { shutdown('SIGINT'); });
  process.on('SIGTERM', () => { shutdown('SIGTERM'); });
}

export { main };

const isMain = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url));
if (isMain) {
  main().catch((e) => {
    console.error('[live-qq] 起不来：' + msg(e));
    if (e && e.stateFile) console.error('[live-qq] 状态文件路径：' + e.stateFile);
    process.exitCode = 1;
  });
}

export default main;
