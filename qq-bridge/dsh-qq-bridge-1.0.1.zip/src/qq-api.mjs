// qq/qq-api.mjs — QQ 官方 REST 调用（统一地址 https://api.bot.qq.com）
// 鉴权头：Authorization: QQBot {ACCESS_TOKEN}
// 官方要求：判断成败看 err_code，不要看 message（message 随时会调整）。

import { DEFAULT_BASE } from './qq-token.mjs';

export const ERR_MSG_ID_EXPIRED = 40034005; // 文档示例：回复消息msg_id已过期
export const ERR_MSG_ID_LIMIT = 40034124;   // 同一 msg_id 被动回复次数用尽（官方文档：每条消息可回 4 次）

// 富媒体上传的 file_type（POST /v2/users/{openid}/files、/v2/groups/{group_openid}/files）
export const FILE_TYPE_IMAGE = 1;
export const FILE_TYPE_VIDEO = 2;
export const FILE_TYPE_AUDIO = 3;
export const FILE_TYPE_FILE = 4;
export const MSG_TYPE_TEXT = 0;
export const MSG_TYPE_INPUT_NOTIFY = 6;
export const MSG_TYPE_RICH_MEDIA = 7; // 带 media.file_info 的富媒体消息

function msg(e) { return (e && e.message) || String(e); }

export function createApi(config = {}) {
  const cfg = config || {};
  const baseUrl = cfg.baseUrl || DEFAULT_BASE;
  const fetchImpl = cfg.fetchImpl || globalThis.fetch;
  const getToken = cfg.getToken || (async () => { throw new Error('no-getToken'); });
  const timeoutMs = cfg.timeoutMs === undefined ? 10000 : Number(cfg.timeoutMs);
  const stats = { calls: 0, ok: 0, failed: 0, lastErrCode: null, lastError: null };

  async function call(method, pathname, body) {
    stats.calls += 1;
    let token = null;
    try {
      token = await getToken();
    } catch (e) {
      stats.failed += 1;
      stats.lastError = 'get-token: ' + msg(e);
      throw new Error(stats.lastError);
    }
    const init = {
      method: method,
      headers: {
        authorization: 'QQBot ' + token,
        'content-type': 'application/json; charset=utf-8',
      },
    };
    if (body !== undefined) init.body = JSON.stringify(body);
    if (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) init.signal = AbortSignal.timeout(timeoutMs);
    let res = null;
    try {
      res = await fetchImpl(baseUrl + pathname, init);
    } catch (e) {
      stats.failed += 1;
      stats.lastError = method + ' ' + pathname + ' fetch: ' + msg(e);
      throw new Error(stats.lastError);
    }
    let payload = null;
    try { payload = await res.json(); } catch (e) { payload = null; }
    const errCode = payload && typeof payload.err_code === 'number' ? payload.err_code : null;
    const bad = !res.ok || (errCode !== null && errCode !== 0);
    if (bad) {
      stats.failed += 1;
      stats.lastErrCode = errCode;
      stats.lastError = method + ' ' + pathname + ' http=' + res.status + ' err_code=' + String(errCode) + ' message=' + String(payload && payload.message ? payload.message : '');
      const err = new Error('qq-api ' + stats.lastError);
      err.status = res.status;
      err.errCode = errCode;
      err.body = payload;
      throw err;
    }
    stats.ok += 1;
    return payload;
  }

  return {
    stats: stats,
    call: call,
    getGateway: () => call('GET', '/gateway'),
    sendC2C: (userOpenid, payload) => call('POST', '/v2/users/' + encodeURIComponent(String(userOpenid)) + '/messages', payload),
    // 群聊：POST /v2/groups/{group_openid}/messages（与单聊同形状，msg_id 取 GROUP_AT_MESSAGE_CREATE 的 d.id）
    sendGroup: (groupOpenid, payload) => call('POST', '/v2/groups/' + encodeURIComponent(String(groupOpenid)) + '/messages', payload),
    // 富媒体上传：{file_type, url|file_data, srv_send_msg:false} -> {file_uuid, file_info, ttl}
    // srv_send_msg 必须为 false，上传才只回 file_info 不直接发消息；随后用 msg_type=7 带 media.file_info 发。
    uploadC2C: (userOpenid, payload) => call('POST', '/v2/users/' + encodeURIComponent(String(userOpenid)) + '/files', payload),
    uploadGroup: (groupOpenid, payload) => call('POST', '/v2/groups/' + encodeURIComponent(String(groupOpenid)) + '/files', payload),
  };
}

export default createApi;
