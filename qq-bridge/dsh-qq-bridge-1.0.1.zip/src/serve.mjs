// qq/serve.mjs — QQ 官方机器人腿的常驻 HTTP 服务（与 ilink/serve.mjs 同一套形状）
// 两个方向：
//   入站：QQ 单聊消息 -> POST 到桥的 inbox（http://127.0.0.1:43120/wechat-bridge/inbox）
//   回程：桥把这一轮的文字 POST 到本服务的 /send -> 这条腿发回 QQ（被动回复，带 msg_id）
// 路由：POST /send（{text} 或 {typing:true} 或 {media} 发图）、GET /status、GET /、POST /inject（离线自检用）

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createQq } from './qq.mjs';
import { parseAttachments, describeSaved } from './qq-media.mjs';

export const DEFAULT_HOST = '127.0.0.1';
export const DEFAULT_PORT = 43124;
export const DEFAULT_INBOX_URL = 'http://127.0.0.1:43120/wechat-bridge/inbox';
export const DEFAULT_PREFIX = '[QQ] ';
// 手机审批（@local/dsh-phone-approval）在 DSH 的 webServer 上注册的这两条路由。
// 插件没装 / 没起来时，下面的探测直接失败，本文件的行为一字不变。
export const DEFAULT_APPROVAL_PENDING_URL = 'http://127.0.0.1:43120/approval-remote/pending';
export const DEFAULT_APPROVAL_DECIDE_URL = 'http://127.0.0.1:43120/approval-remote/decide';
/** 「像审批决定」的短回复。只有确实有待批时才拦；否则单独一个「1」照样是聊天。 */
export const APPROVAL_REPLY_RE = /^(?:1|2|同意|允许|批准|拒绝|不同意|不允许|不行|可以|好|行|ok|yes|no|y|n|allow|deny|reject)(?:[\s\-_:]+\d+)?$/i;
/**
 * 「一看就是在回审批卡」的回复：数字序号，或同意/允许/批准/拒绝那一小撮词。
 * 比 APPROVAL_REPLY_RE 窄 —— 「好」「行」「可以」「ok」平时也是聊天，
 * 拿它们去报「没有待批的卡」只会吵人；序号和「同意」则几乎不可能是别的事。
 */
export const APPROVAL_LIKELY_RE = /^(?:[12]|同意|允许|批准|拒绝|不同意|不允许)(?:[\s\-_:]+\d+)?$/i;

/** 没有待批卡时回给手机的一句解释 —— 纯粹为了让人知道那条回复去哪了。 */
export function buildStaleNotice(rawText) {
  const t = preview(String(rawText === undefined || rawText === null ? '' : rawText).trim(), 20);
  return '⚠️ 收到「' + t + '」，但此刻没有任何待审批的卡 —— 多半是那张卡已经过期、被电脑先答掉，或插件刚重启过。'
    + '这条已经当普通消息转给电脑，不是被吞了。';
}

const noop = () => {};

function msg(e) { return (e && e.message) || String(e); }

function readBody(req, maxBytes) {
  return new Promise((resolve) => {
    const chunks = [];
    let size = 0;
    let done = false;
    req.on('data', (c) => {
      if (done) return;
      size += c.length;
      if (size > maxBytes) { done = true; resolve(null); return; }
      chunks.push(c);
    });
    req.on('end', () => { if (!done) resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', () => { if (!done) { done = true; resolve(null); } });
  });
}

function preview(text, n) {
  const s = String(text === undefined || text === null ? '' : text);
  return s.length <= n ? s : s.slice(0, n) + '…';
}

export function createServe(config = {}) {
  const cfg = config || {};
  const host = cfg.host || DEFAULT_HOST;
  const port = cfg.port === undefined ? DEFAULT_PORT : Number(cfg.port);
  const inboxUrl = cfg.inboxUrl || DEFAULT_INBOX_URL;
  const prefix = cfg.prefix === undefined ? DEFAULT_PREFIX : String(cfg.prefix);
  const maxBodyBytes = cfg.maxBodyBytes === undefined ? 65536 : Number(cfg.maxBodyBytes);
  const fetchImpl = cfg.fetchImpl || globalThis.fetch;
  const logger = typeof cfg.logger === 'function' ? cfg.logger : noop;
  const journalFile = cfg.journalFile || null;
  const forwardTimeoutMs = cfg.forwardTimeoutMs === undefined ? 8000 : Number(cfg.forwardTimeoutMs);
  // 手机审批两条路由；显式传 null 或空串可关掉这段拦截。
  const approvalPendingUrl = cfg.approvalPendingUrl === undefined ? DEFAULT_APPROVAL_PENDING_URL : (cfg.approvalPendingUrl === null ? '' : String(cfg.approvalPendingUrl));
  const approvalDecideUrl = cfg.approvalDecideUrl === undefined ? DEFAULT_APPROVAL_DECIDE_URL : (cfg.approvalDecideUrl === null ? '' : String(cfg.approvalDecideUrl));
  const approvalTimeoutMs = cfg.approvalTimeoutMs === undefined ? 4000 : Number(cfg.approvalTimeoutMs);
  // 插件活着但没有待批的卡时，是否回一句「不用回了」。传 false 可关掉。
  const approvalStaleNotice = cfg.approvalStaleNotice !== false;
  const allowInject = cfg.allowInject !== false;
  const client = cfg.client || createQq({
    appId: cfg.appId,
    clientSecret: cfg.clientSecret,
    baseUrl: cfg.baseUrl,
    gatewayUrl: cfg.gatewayUrl,
    intents: cfg.intents,
    WebSocketImpl: cfg.WebSocketImpl,
    fetchImpl: cfg.qqFetchImpl || cfg.fetchImpl,
    // qq.mjs 里的 logger 事件（send / send-retry / send-retry-ok / send-active-fallback /
    // media-upload-failed / split-truncated …）原来默认被丢掉，这里接到 journal 上，
    // 故障可回捞（kind 前缀 qq-）。journal/note 都是函数声明，运行时调用没问题。
    logger: qqLogger,
    openid: cfg.openid,
  });

  const mediaStore = cfg.mediaStore || null;
  const stats = { sendOk: 0, sendFailed: 0, typingOk: 0, typingFailed: 0, forwards: 0, forwardFailed: 0, received: 0, duplicates: 0, injects: 0, mediaSaved: 0, mediaFailed: 0, mediaSent: 0, approvalReplies: 0, approvalStale: 0 };
  let server = null;
  let lastError = null;
  let lastForward = null;
  let startedAt = null;
  let startRetryTimer = null;
  let startRetryAttempt = 0;

  function journal(entry) {
    if (!journalFile) return;
    try {
      const dir = path.dirname(journalFile);
      if (dir && dir !== '.') fs.mkdirSync(dir, { recursive: true });
      fs.appendFileSync(journalFile, JSON.stringify(Object.assign({ at: new Date().toISOString() }, entry)) + '\n', 'utf8');
    } catch (e) {
      lastError = 'journal: ' + msg(e);
    }
  }

  // qq 腿的事件 -> journal（kind 前缀 qq-）+ 原 logger；写日志失败只记 lastError，不影响主流程
  function qqLogger(event) {
    const e = event && typeof event === 'object' ? event : { note: String(event) };
    const kind = 'qq-' + (e.kind === undefined ? 'event' : String(e.kind));
    journal(Object.assign({}, e, { kind: kind }));
    note(e);
  }

  function note() {
    if (logger === noop) return;
    const parts = Array.prototype.slice.call(arguments);
    try { logger(parts.map((p) => (typeof p === 'string' ? p : JSON.stringify(p))).join(' ')); } catch (e) { /* 日志失败不影响主流程 */ }
  }

  function json(res, status, payload) {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(payload));
  }

  /** 手机审批：有待批且这条就是决定时，替插件把决定送进去。任何异常都返回 null（退回普通聊天）。 */
  async function tryRemoteApproval(rawText, hasAttachments) {
    if (approvalPendingUrl === '' || approvalDecideUrl === '') return null;
    if (hasAttachments === true) return null;
    const t = String(rawText === undefined || rawText === null ? '' : rawText).trim();
    if (t === '' || t.length > 24) return null;
    if (!APPROVAL_REPLY_RE.test(t)) return null;
    const timeout = typeof AbortSignal !== 'undefined' && AbortSignal.timeout ? AbortSignal.timeout(approvalTimeoutMs) : undefined;
    let pending = null;
    try {
      const res = await fetchImpl(approvalPendingUrl, { method: 'GET', signal: timeout });
      if (!res.ok) return null;
      pending = await res.json();
    } catch (e) {
      return null; // 插件没装或没起来：当作没有待批
    }
    if (!pending || pending.ok !== true) return null;
    // 插件活着、但一张待批都没有：这条「1/2」多半是对着一张已经死掉的卡回的。
    // 不能一声不吭 —— 调用方会把它当普通聊天转进会话，人看到的就是「回复无效」。
    if (!(Number(pending.count) > 0)) return { ok: false, stale: true, count: Number(pending.count) || 0 };
    try {
      const res = await fetchImpl(approvalDecideUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json; charset=utf-8' },
        body: JSON.stringify({ text: t }),
        signal: timeout,
      });
      let out = null;
      try { out = await res.json(); } catch (e) { out = null; }
      if (out === null || out.ok !== true) return null; // 没认出来 / 序号不对：退回普通聊天
      return { ok: true, id: out.id === undefined ? null : out.id, toolName: out.toolName === undefined ? null : out.toolName, outcome: out.outcome === undefined ? null : out.outcome, ambiguous: out.ambiguous === true };
    } catch (e) {
      return null;
    }
  }

  // ---------- 入站：QQ -> 桥 ----------
  async function forwardIncoming(message) {
    const rawText = message && message.text !== undefined && message.text !== null ? String(message.text) : '';
    // 附件（QQ 的图片/语音/文件）先落盘，再把「本地路径」拼进纯文本 —— 桥的 inbox 只吃 text，
    // 所以这是把图片送进 DSH 会话（我那边可以 read_image 直接看）的唯一通道。
    // 再解析一次：qq.mjs 送来的已经是对象，但 /inject 或别的入口可能直接塞原始字符串数组，
    // parseAttachments 对两种形状都幂等，这样「谁送来的」都不影响落盘。
    const attachments = parseAttachments(message && message.attachments);
    // 手机审批：确实有待批、且这条消息就是一个决定时，转给审批插件，不投进会话。
    // 没有待批 / 插件没装 / 认不出来 —— 一律返回 null 走下面的老路，行为一字不变。
    const approval = await tryRemoteApproval(rawText, attachments.length > 0);
    if (approval !== null && approval.stale === true) {
      // 没有待批的卡：回一句解释（免得人以为回复被吞），再照旧走下面的老路 —— 绝不吞消息。
      stats.approvalStale += 1;
      journal({ kind: 'approval-stale', reply: preview(rawText, 20), count: approval.count });
      const t = String(rawText === undefined || rawText === null ? '' : rawText).trim();
      if (approvalStaleNotice && APPROVAL_LIKELY_RE.test(t)) {
        Promise.resolve()
          .then(() => client.send({ text: buildStaleNotice(t) }))
          .catch((e) => { journal({ kind: 'approval-stale-notice-failed', note: msg(e) }); });
      }
    } else if (approval !== null) {
      stats.approvalReplies += 1;
      lastForward = { at: new Date().toISOString(), ok: true, status: 200, approval: true, outcome: approval.outcome, toolName: approval.toolName, chars: rawText.length };
      journal(Object.assign({ kind: 'approval-decide', reply: preview(rawText, 20) }, lastForward));
      return { ok: true, approval: true, outcome: approval.outcome, toolName: approval.toolName, id: approval.id };
    }
    let media = [];
    if (attachments.length > 0 && mediaStore) {
      media = await mediaStore.saveAll(attachments, { maxItems: cfg.mediaMaxItems });
      for (const r of media) { if (r && r.ok) stats.mediaSaved += 1; else stats.mediaFailed += 1; }
    }
    const mediaLines = describeSaved(media);
    const text = mediaLines.length
      ? (rawText ? rawText + '\n\n' + mediaLines.join('\n') : mediaLines.join('\n'))
      : rawText;
    const body = JSON.stringify({
      text: prefix + text,
      from: message && message.from ? String(message.from) : null,
      messageId: message && message.messageId ? String(message.messageId) : null,
      channel: 'qq',
      scene: message && message.channel ? String(message.channel) : null,
      attachments: media.map((r) => ({
        ok: !!(r && r.ok),
        path: r && r.path ? r.path : null,
        contentType: r && r.contentType ? r.contentType : null,
        bytes: r && r.bytes ? r.bytes : null,
        kind: r && r.kind ? r.kind : null,
      })),
    });
    const init = {
      method: 'POST',
      headers: { 'content-type': 'application/json; charset=utf-8' },
      body: body,
    };
    if (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) init.signal = AbortSignal.timeout(forwardTimeoutMs);
    try {
      const res = await fetchImpl(inboxUrl, init);
      let out = null;
      try { out = await res.json(); } catch (e) { out = null; }
      if (res.ok) stats.forwards += 1; else stats.forwardFailed += 1;
      lastForward = { at: new Date().toISOString(), ok: res.ok, status: res.status, chars: text.length, media: mediaLines.length, requestId: out && out.requestId ? out.requestId : null };
      journal(Object.assign({ kind: 'forward', preview: preview(text, 60) }, lastForward));
      return { ok: res.ok, status: res.status, requestId: out && out.requestId ? out.requestId : null };
    } catch (e) {
      stats.forwardFailed += 1;
      lastError = 'forward: ' + msg(e);
      lastForward = { at: new Date().toISOString(), ok: false, status: 0, chars: text.length, error: msg(e) };
      journal({ kind: 'forward-failed', note: msg(e) });
      return { ok: false, status: 0, error: msg(e) };
    }
  }

  client.onMessage((message) => {
    stats.received += 1;
    journal({ kind: 'incoming', messageId: message && message.messageId ? message.messageId : null, chars: message && message.text ? message.text.length : 0, media: message && Array.isArray(message.attachments) ? message.attachments.length : 0, mediaDir: mediaStore ? mediaStore.dir : null });
    return forwardIncoming(message);
  });

  // ---------- /send：桥的回程 leg 打到这里 ----------
  async function handleSend(req, res) {
    const raw = await readBody(req, maxBodyBytes);
    if (raw === null) return json(res, 413, { ok: false, reason: 'body too large' });
    let body = {};
    if (raw) {
      try { body = JSON.parse(raw); } catch (e) { body = { text: raw }; }
    }
    if (!body || typeof body !== 'object') body = { text: String(body) };

    if (body.typing === true) {
      try {
        await client.typing({});
        stats.typingOk += 1;
        journal({ kind: 'typing', requestId: body.requestId === undefined ? null : body.requestId });
        return json(res, 200, { ok: true, typing: true });
      } catch (e) {
        stats.typingFailed += 1;
        lastError = 'typing: ' + msg(e);
        journal({ kind: 'typing-failed', note: msg(e), errCode: e && typeof e.errCode === 'number' ? e.errCode : null });
        return json(res, 502, { ok: false, reason: msg(e) });
      }
    }

    const text = body.text === undefined || body.text === null ? '' : String(body.text);
    // media：本地文件路径、http(s) 链接，或 {path|url|data, fileType, contentType}。
    // 空串 / 空对象一律当没给，好让老的 {text} 请求一字不改地走原路。
    const hasMedia = body.media !== undefined && body.media !== null && body.media !== ''
      && !(typeof body.media === 'object' && !Array.isArray(body.media) && Object.keys(body.media).length === 0);
    if (!hasMedia && !text.trim()) return json(res, 400, { ok: false, reason: 'text 为空' });
    // 向后兼容：没有 media 时传给 client 的形状和以前完全一样，只有 { text }
    const sendBody = { text: text };
    if (hasMedia) sendBody.media = body.media;
    try {
      const out = await client.send(sendBody);
      stats.sendOk += 1;
      if (hasMedia) stats.mediaSent += 1;
      journal({ kind: 'send', requestId: body.requestId === undefined ? null : body.requestId, chars: text.length, media: hasMedia ? 1 : 0 });
      return json(res, 200, { ok: true, sent: true, chars: text.length, media: hasMedia, raw: out === undefined ? null : out });
    } catch (e) {
      stats.sendFailed += 1;
      lastError = 'send: ' + msg(e);
      // 失败时把正文一并落盘：丢消息后可以直接从 qq-journal.jsonl 里把这条捞出来重发
      journal({
        kind: 'send-failed', note: msg(e),
        errCode: e && typeof e.errCode === 'number' ? e.errCode : null,
        httpStatus: e && typeof e.status === 'number' ? e.status : null,
        chars: text.length, media: hasMedia ? 1 : 0,
        text: text.length > 2000 ? text.slice(0, 2000) + '…（已截断）' : text,
      });
      return json(res, 502, { ok: false, reason: msg(e) });
    }
  }

  async function handleInject(req, res) {
    if (!allowInject) return json(res, 403, { ok: false, reason: 'inject disabled' });
    const raw = await readBody(req, maxBodyBytes);
    let body = {};
    try { body = raw ? JSON.parse(raw) : {}; } catch (e) { body = {}; }
    const id = body.id || ('inject-' + Date.now());
    const openid = body.userOpenid || body.openid || 'INJECT_OPENID';
    const text = body.text === undefined ? '' : String(body.text);
    stats.injects += 1;
    const packet = { id: id, content: text, author: { user_openid: openid }, message_type: 0 };
    const before = stats.forwards + stats.forwardFailed;
    const message = await client.handleEvent('C2C_MESSAGE_CREATE', packet);
    for (let i = 0; i < 40 && stats.forwards + stats.forwardFailed === before; i += 1) {
      await new Promise((r) => setTimeout(r, 25));
    }
    return json(res, 200, { ok: true, injected: message !== null, messageId: id });
  }

  function handleStatus(req, res) {
    const cs = client.state ? client.state() : null;
    json(res, 200, {
      ok: true,
      channel: 'qq',
      version: 'v1-qq-leg',
      startedAt: startedAt,
      host: host,
      port: server && server.address() ? server.address().port : port,
      inboxUrl: inboxUrl,
      prefix: prefix,
      approvalPendingUrl: approvalPendingUrl,
      approvalDecideUrl: approvalDecideUrl,
      ready: cs === null ? null : cs.ready,
      connected: cs === null ? null : cs.connected,
      lastOpenid: cs === null ? null : cs.lastOpenid,
      lastMessage: cs === null ? null : cs.lastMessage,
    activePush: cs === null ? null : cs.activePush,
    activePushLabel: cs === null ? null : cs.activePushLabel,
    activePushAt: cs === null ? null : cs.activePushAt,
      recent: cs === null ? null : cs.recent,
      stats: stats,
      clientStats: cs === null ? null : cs.stats,
      gatewayStats: cs === null || !cs.gateway ? null : cs.gateway.stats,
      token: cs === null ? null : cs.token,
      lastForward: lastForward,
      lastError: lastError,
      lastClientError: cs === null ? null : cs.lastError,
    });
  }

  function handleRoot(req, res) {
    const cs = client.state ? client.state() : null;
    const lines = [
      '<!doctype html><meta charset="utf-8"><title>DSH QQ 腿</title>',
      '<body style="font-family:system-ui;padding:24px;line-height:1.7">',
      '<h1>DSH QQ 官方机器人腿</h1>',
      '<p>状态：<b>' + (cs && cs.ready ? '已连接' : '未连接') + '</b>　端口 ' + String(server && server.address() ? server.address().port : port) + '</p>',
      '<p>入站转发到：<code>' + inboxUrl + '</code>　前缀 <code>' + prefix + '</code></p>',
      '<p>最近消息：' + (cs && cs.lastMessage ? (cs.lastMessage.at + '　' + String(cs.lastMessage.chars) + ' 字') : '（还没有）') + '</p>',
      '<p>主动消息：<b>' + (cs && cs.activePushLabel ? cs.activePushLabel : '未知（还没收到过开关事件）') + '</b>　（QQ 里机器人资料卡上的那个开关）</p>',
      '<p>接口：<code>GET /status</code>　<code>POST /send</code></p>',
      '</body>',
    ];
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end(lines.join('\n'));
  }

  async function handler(req, res) {
    const pathname = String(req.url || '/').split('?')[0];
    if (req.method === 'GET' && pathname === '/status') return handleStatus(req, res);
    if (req.method === 'GET' && (pathname === '/' || pathname === '/index.html')) return handleRoot(req, res);
    if (pathname === '/send') {
      if (req.method !== 'POST') return json(res, 405, { ok: false, reason: 'method-not-allowed' });
      return handleSend(req, res);
    }
    if (pathname === '/inject') {
      if (req.method !== 'POST') return json(res, 405, { ok: false, reason: 'method-not-allowed' });
      return handleInject(req, res);
    }
    return json(res, 404, { ok: false, reason: 'not-found', routes: ['GET /status', 'GET /', 'POST /send', 'POST /inject'] });
  }

  // 首次 client.start() 失败（拿不到网关地址 / 取 token 超时）原先会让 serve.start() 整体 reject：
  // live-qq 打完「起不来」退出，但 http server 已经 listen，进程靠它活着 —— 端口通、/send 能发、
  // 网关却永远不连（也没人再试），入站消息就此永久为零。所以这里把失败降级成后台重试。
  function scheduleStartRetry(reason) {
    if (startRetryTimer !== null) return;
    startRetryAttempt += 1;
    const delay = Math.min(60000, 2000 * Math.pow(2, Math.min(startRetryAttempt - 1, 5)));
    note('[qq-serve] 网关连接重试第 ' + String(startRetryAttempt) + ' 次，' + String(delay) + 'ms 后：' + String(reason));
    startRetryTimer = setTimeout(() => {
      startRetryTimer = null;
      Promise.resolve()
        .then(() => client.start())
        .then(() => {
          startRetryAttempt = 0;
          lastError = null;
          journal({ kind: 'qq-start-retry-ok' });
          note('[qq-serve] 网关已连上（后台重试成功）');
        })
        .catch((e) => {
          lastError = 'start-retry: ' + msg(e);
          journal({ kind: 'qq-start-retry-failed', error: lastError });
          scheduleStartRetry(lastError);
        });
    }, delay);
  }

  async function start(options) {
    const opts = options || {};
    if (server !== null) return server.address();
    server = http.createServer((req, res) => {
      Promise.resolve(handler(req, res)).catch((e) => {
        lastError = 'handler: ' + msg(e);
        try { json(res, 500, { ok: false, reason: msg(e) }); } catch (e2) { /* 响应也可能已经发出去 */ }
      });
    });
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, host, () => resolve());
    });
    startedAt = new Date().toISOString();
    if (opts.connect !== false) {
      try {
        await client.start();
      } catch (e) {
        lastError = 'client-start: ' + msg(e);
        journal({ kind: 'qq-start-failed', error: lastError });
        note('[qq-serve] 首次连网关失败，转为后台重试：' + lastError);
        scheduleStartRetry(lastError);
      }
    }
    note('[qq-serve] listening on http://' + host + ':' + String(port));
    return server.address();
  }

  async function stop() {
    if (startRetryTimer !== null) { clearTimeout(startRetryTimer); startRetryTimer = null; }
    try { client.stop(); } catch (e) { lastError = 'client-stop: ' + msg(e); }
    if (server !== null) {
      await new Promise((resolve) => server.close(() => resolve()));
      server = null;
    }
    return { ok: true };
  }

  return {
    start: start,
    stop: stop,
    client: client,
    stats: stats,
    forwardIncoming: forwardIncoming,
    tryRemoteApproval: tryRemoteApproval,
    journal: journal,
    get server() { return server; },
    state: () => ({ host: host, port: port, inboxUrl: inboxUrl, prefix: prefix, approvalPendingUrl: approvalPendingUrl, approvalDecideUrl: approvalDecideUrl, lastError: lastError, lastForward: lastForward }),
  };
}

function parseArgs(argv) {
  const out = {};
  for (const raw of argv || []) {
    const a = String(raw);
    if (!a.startsWith('--')) continue;
    const eq = a.indexOf('=');
    const key = eq === -1 ? a.slice(2) : a.slice(2, eq);
    const value = eq === -1 ? true : a.slice(eq + 1);
    out[key] = value;
  }
  return out;
}

export function configFromArgs(argv) {
  const a = parseArgs(argv);
  const cfg = {};
  if (a.port !== undefined) cfg.port = Number(a.port);
  if (a.host !== undefined) cfg.host = String(a.host);
  if (a.inbox !== undefined) cfg.inboxUrl = String(a.inbox);
  if (a.prefix !== undefined) cfg.prefix = String(a.prefix);
  if (a.journal !== undefined) cfg.journalFile = String(a.journal);
  if (a['app-id'] !== undefined) cfg.appId = String(a['app-id']);
  if (a.secret !== undefined) cfg.clientSecret = String(a.secret);
  if (a.gateway !== undefined) cfg.gatewayUrl = String(a.gateway);
  if (a.intents !== undefined) cfg.intents = Number(a.intents);
  if (a.state !== undefined) cfg.stateFile = String(a.state);
  if (a['approval-pending'] !== undefined) cfg.approvalPendingUrl = String(a['approval-pending']);
  if (a['approval-decide'] !== undefined) cfg.approvalDecideUrl = String(a['approval-decide']);
  return cfg;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url));
if (isMain) {
  const serve = createServe(configFromArgs(process.argv.slice(2)));
  serve.start().then((addr) => {
    console.log('[qq-serve] ready on http://' + (addr ? addr.address : '127.0.0.1') + ':' + (addr ? addr.port : DEFAULT_PORT));
  }).catch((e) => {
    console.error('[qq-serve] start failed: ' + msg(e));
    process.exitCode = 1;
  });
}

export default createServe;
