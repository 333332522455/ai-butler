// qq/qq-media.mjs — QQ 消息里的附件（图片 / 语音 / 文件）：解析 + 下载落盘
// 官方 C2C_MESSAGE_CREATE / GROUP_AT_MESSAGE_CREATE 的 d.attachments 是「字符串数组」，
// 每个元素本身是一段 JSON 文本（{content_type, filename, size, width, height, url[, voice_wav_url]}）。
// 本模块只做两件事：把那段 JSON 解析成规整对象；把 url 拉下来存到本地目录。
// 落盘路径会被 serve.mjs 拼进转发给桥的纯文本里，所以 DSH 那边能直接 read 到文件。
// 注意：附件 URL 是腾讯 CDN 短链（multimedia.nt.qq.com.cn），有时效，必须收到就下。

import fs from 'node:fs';
import path from 'node:path';

export const DEFAULT_MAX_BYTES = 20 * 1024 * 1024; // 单个附件上限 20MB
export const DEFAULT_MAX_ITEMS = 5;                // 一条消息最多下几个
export const DEFAULT_TIMEOUT_MS = 20000;

const EXT_BY_TYPE = {
  'image/jpeg': '.jpg', 'image/jpg': '.jpg', 'image/png': '.png', 'image/gif': '.gif',
  'image/webp': '.webp', 'image/bmp': '.bmp', 'image/heic': '.heic',
  'audio/wav': '.wav', 'audio/x-wav': '.wav', 'audio/mpeg': '.mp3', 'audio/mp3': '.mp3',
  'audio/silk': '.silk', 'audio/amr': '.amr', 'video/mp4': '.mp4',
  'application/pdf': '.pdf', 'text/plain': '.txt', 'application/zip': '.zip',
};

export function kindOf(contentType) {
  const ct = String(contentType === undefined || contentType === null ? '' : contentType).toLowerCase();
  if (ct.startsWith('image/')) return 'image';
  if (ct.startsWith('audio/')) return 'voice';
  if (ct.startsWith('video/')) return 'video';
  if (ct) return 'file';
  return 'unknown';
}

function num(v) { const n = Number(v); return Number.isFinite(n) && n > 0 ? n : null; }

// 单个附件：字符串则先 JSON.parse；坏数据返回 null 而不是抛
export function parseAttachment(raw) {
  let o = raw;
  if (typeof raw === 'string') {
    const s = raw.trim();
    if (!s) return null;
    try { o = JSON.parse(s); } catch (e) { return null; }
  }
  if (!o || typeof o !== 'object') return null;
  const contentType = o.content_type || o.contentType || null;
  const url = o.url || o.voice_wav_url || null;
  if (!url && !contentType) return null;
  return {
    contentType: contentType ? String(contentType) : null,
    filename: o.filename ? String(o.filename) : null,
    url: url ? String(url) : null,
    size: num(o.size),
    width: num(o.width),
    height: num(o.height),
    kind: kindOf(contentType),
  };
}

export function parseAttachments(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const item of raw) { const a = parseAttachment(item); if (a) out.push(a); }
  return out;
}

// 只取文件名部分，剥掉目录、控制字符、Windows 非法字符、超长、并把空格折成下划线
export function safeName(filename, contentType, index) {
  const ct = String(contentType === undefined || contentType === null ? '' : contentType).toLowerCase();
  let base = typeof filename === 'string' ? filename : '';
  base = base.replace(/^.*[\\/]/, '');                       // 剥目录（正反斜杠都算）
  base = base.replace(/[\u0000-\u001f\u007f]/g, '');        // 控制字符
  base = base.replace(/[<>:"|?*]/g, '_');                      // Windows 非法字符
  base = base.replace(/\s+/g, '_').replace(/^[._-]+/, '').trim();
  let ext = path.extname(base).toLowerCase();
  const want = EXT_BY_TYPE[ct] || '';
  if (!/^\.[a-z0-9]{1,8}$/.test(ext)) {
    ext = want;
  } else if (want && ext !== want && (ext === '.tmp' || ext === '.bin')) {
    ext = want;
  }
  let stem = ext ? base.slice(0, base.length - path.extname(base).length) : base;
  if (!stem) stem = 'attachment';
  if (stem.length > 60) stem = stem.slice(0, 60);
  const seq = index === undefined || index === null ? '' : String(Number(index) + 1);
  const name = stem + (seq ? '_' + seq : '') + ext;
  return name;
}

function two(n) { return String(n).padStart(2, '0'); }
function three(n) { return String(n).padStart(3, '0'); }

export function createMediaStore(config = {}) {
  const cfg = config || {};
  const dir = cfg.dir || null;
  const fetchImpl = cfg.fetchImpl || globalThis.fetch;
  const maxBytes = cfg.maxBytes === undefined ? DEFAULT_MAX_BYTES : Number(cfg.maxBytes);
  const maxItems = cfg.maxItems === undefined ? DEFAULT_MAX_ITEMS : Number(cfg.maxItems);
  const timeoutMs = cfg.timeoutMs === undefined ? DEFAULT_TIMEOUT_MS : Number(cfg.timeoutMs);
  const now = typeof cfg.now === 'function' ? cfg.now : () => new Date();
  const logger = typeof cfg.logger === 'function' ? cfg.logger : () => {};
  const stats = { saved: 0, failed: 0, skipped: 0, bytes: 0 };
  let seq = 0;
  let lastSaved = null;

  function stamp() {
    const d = now();
    return '' + d.getFullYear() + two(d.getMonth() + 1) + two(d.getDate()) + '-' + two(d.getHours()) + two(d.getMinutes()) + two(d.getSeconds()) + '-' + three(d.getMilliseconds());
  }

  function uniquePath(name) {
    const target = path.join(dir, name);
    if (!fs.existsSync(target)) return target;
    const ext = path.extname(name);
    const stem = name.slice(0, name.length - ext.length);
    for (let i = 2; i < 500; i += 1) {
      const t = path.join(dir, stem + '-' + i + ext);
      if (!fs.existsSync(t)) return t;
    }
    return path.join(dir, stem + '-' + Date.now() + ext);
  }

  async function saveOne(a, index) {
    const kind = a && a.kind ? a.kind : 'unknown';
    if (!dir) { stats.skipped += 1; return { ok: false, kind: kind, reason: 'no-dir' }; }
    if (!a || !a.url) { stats.skipped += 1; return { ok: false, kind: kind, reason: 'no-url' }; }
    seq += 1;
    const init = { method: 'GET' };
    if (a.headers && typeof a.headers === 'object') init.headers = a.headers;
    if (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) init.signal = AbortSignal.timeout(timeoutMs);
    try {
      const res = await fetchImpl(a.url, init);
      if (!res || res.ok !== true) {
        stats.failed += 1;
        const status = res && res.status !== undefined ? res.status : 0;
        logger({ kind: 'media-http-error', status: status, contentType: a.contentType });
        return { ok: false, kind: kind, reason: 'http-' + status, contentType: a.contentType };
      }
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length > maxBytes) {
        stats.failed += 1;
        logger({ kind: 'media-too-large', bytes: buf.length });
        return { ok: false, kind: kind, reason: 'too-large', bytes: buf.length, contentType: a.contentType };
      }
      fs.mkdirSync(dir, { recursive: true });
      const name = safeName(a.filename, a.contentType, index === undefined ? seq - 1 : index);
      const target = uniquePath(stamp() + '-' + seq + '-' + name);
      fs.writeFileSync(target, buf);
      stats.saved += 1;
      stats.bytes += buf.length;
      lastSaved = target;
      logger({ kind: 'media-saved', path: target, bytes: buf.length, contentType: a.contentType });
      return {
        ok: true, path: target, name: path.basename(target), bytes: buf.length,
        contentType: a.contentType, kind: kind, width: a.width, height: a.height, reason: null,
      };
    } catch (e) {
      stats.failed += 1;
      const reason = 'fetch: ' + ((e && e.message) || String(e));
      logger({ kind: 'media-fetch-error', error: reason });
      return { ok: false, kind: kind, reason: reason, contentType: a.contentType };
    }
  }

  // 返回与 attachments 等长的结果数组（跳过项也在内，便于上层如实报告）
  async function saveAll(attachments, opts = {}) {
    const list = Array.isArray(attachments) ? attachments : [];
    const results = [];
    if (!list.length || !dir) return results;
    const max = opts.maxItems === undefined ? maxItems : Number(opts.maxItems);
    for (let i = 0; i < list.length; i += 1) {
      if (i >= max) { stats.skipped += 1; results.push({ ok: false, kind: list[i] && list[i].kind ? list[i].kind : 'unknown', reason: 'over-limit' }); continue; }
      results.push(await saveOne(list[i], i));
    }
    return results;
  }

  function state() {
    return { dir: dir, saved: stats.saved, failed: stats.failed, skipped: stats.skipped, bytes: stats.bytes, lastSaved: lastSaved };
  }

  return { dir: dir, saveOne: saveOne, saveAll: saveAll, stats: stats, state: state };
}

// 把落盘结果拼成给人（和给 DSH 里的我）看的行；图片/语音都带上本地路径
export function describeSaved(results) {
  const lines = [];
  const list = Array.isArray(results) ? results : [];
  for (const r of list) {
    if (!r) continue;
    if (r.ok) {
      const label = r.kind === 'image' ? '图片' : r.kind === 'voice' ? '语音' : r.kind === 'video' ? '视频' : '文件';
      const size = r.bytes >= 1048576 ? (r.bytes / 1048576).toFixed(1) + 'MB' : Math.max(1, Math.round(r.bytes / 1024)) + 'KB';
      const dim = r.width && r.height ? ' ' + r.width + 'x' + r.height : '';
      lines.push('[附件] ' + label + ' ' + (r.contentType || '?') + dim + ' ' + size + ' -> ' + r.path);
    } else {
      lines.push('[附件] 没能取回（' + (r.reason || 'unknown') + '）：' + (r.kind || 'unknown'));
    }
  }
  return lines;
}

export default createMediaStore;
