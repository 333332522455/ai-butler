// qq-approval.test.mjs — QQ 腿的「手机审批」拦截：有待批就把 1/2 转给插件，没有就一切照旧。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { createServe, APPROVAL_REPLY_RE, APPROVAL_LIKELY_RE, buildStaleNotice, DEFAULT_APPROVAL_PENDING_URL, DEFAULT_APPROVAL_DECIDE_URL } from '../src/serve.mjs';

function makeClient() {
  return { onMessage() {}, state() { return null; }, start() {}, stop() {}, send() { return {}; }, typing() {} };
}

/** 记录每次请求的桩 fetch。routes: (url, init) => ({status, body}) | 'throw' */
function makeFetch(routes, seen) {
  return async (url, init) => {
    seen.push({ url: String(url), method: (init && init.method) || 'GET', body: init && init.body ? String(init.body) : null });
    const hit = routes(String(url), init);
    if (hit === 'throw' || hit === undefined) throw new Error('connect ECONNREFUSED');
    return {
      ok: hit.status === undefined ? true : hit.status >= 200 && hit.status < 300,
      status: hit.status === undefined ? 200 : hit.status,
      async json() { return hit.body; },
      async text() { return JSON.stringify(hit.body === undefined ? null : hit.body); },
    };
  };
}

function boot(routes, cfg) {
  const seen = [];
  const serve = createServe(Object.assign({
    client: makeClient(),
    fetchImpl: makeFetch(routes, seen),
    logger: () => {},
  }, cfg || {}));
  return { serve, seen };
}

const PENDING = DEFAULT_APPROVAL_PENDING_URL;
const DECIDE = DEFAULT_APPROVAL_DECIDE_URL;

test('APPROVAL_REPLY_RE 只认「像决定」的短回复', () => {
  for (const s of ['1', '2', '同意', '拒绝', '允许', '不行', 'OK', 'yes', '1 2', '2-3', '同意:1']) {
    assert.equal(APPROVAL_REPLY_RE.test(s), true, s + ' 应该被认作决定');
  }
  for (const s of ['11', '在吗', '1 加个功能', '同意把那个也改了', '']) {
    assert.equal(APPROVAL_REPLY_RE.test(s), false, s + ' 不该被认作决定');
  }
});

test('有待批 -> 决定送进插件，且不碰会话 inbox', async () => {
  const { serve, seen } = boot((url) => {
    if (url === PENDING) return { body: { ok: true, count: 1, pending: [{ id: 'a', toolName: 'Bash' }] } };
    if (url === DECIDE) return { body: { ok: true, id: 'a', toolName: 'Bash', outcome: 'allowed-once' } };
    return { body: { ok: true, requestId: 'r1' } };
  });
  const out = await serve.forwardIncoming({ text: '1', from: 'u' });
  assert.equal(out.approval, true);
  assert.equal(out.outcome, 'allowed-once');
  assert.equal(out.toolName, 'Bash');
  assert.deepEqual(seen.map((s) => s.url), [PENDING, DECIDE]);
  assert.equal(serve.stats.approvalReplies, 1);
  assert.equal(serve.stats.forwards, 0);
});

test('没有待批 -> 单独一个「1」照旧投进会话', async () => {
  const { serve, seen } = boot((url) => {
    if (url === PENDING) return { body: { ok: true, count: 0, pending: [] } };
    return { body: { ok: true, requestId: 'r1' } };
  });
  const out = await serve.forwardIncoming({ text: '1', from: 'u' });
  assert.equal(out.ok, true);
  assert.equal(out.requestId, 'r1');
  assert.deepEqual(seen.map((s) => s.url), [PENDING, DEFAULT_APPROVAL_PENDING_URL.replace('/approval-remote/pending', '/wechat-bridge/inbox')]);
  assert.equal(serve.stats.forwards, 1);
  assert.equal(serve.stats.approvalReplies, 0);
});

test('插件没装（连接被拒）-> 完全退回老路', async () => {
  const { serve, seen } = boot((url) => {
    if (url === PENDING) return 'throw';
    return { body: { ok: true, requestId: 'r9' } };
  });
  const out = await serve.forwardIncoming({ text: '同意', from: 'u' });
  assert.equal(out.requestId, 'r9');
  assert.equal(seen.length, 2);
});

test('普通聊天不会去问插件（一次多余请求都不发）', async () => {
  const { serve, seen } = boot(() => ({ body: { ok: true, requestId: 'r1' } }));
  const out = await serve.forwardIncoming({ text: '在吗', from: 'u' });
  assert.equal(out.requestId, 'r1');
  assert.deepEqual(seen.map((s) => s.url), ['http://127.0.0.1:43120/wechat-bridge/inbox']);
});

test('带附件时不当决定（图配「1」也该是聊天）', async () => {
  const { serve, seen } = boot(() => ({ body: { ok: true, requestId: 'r1' } }));
  const out = await serve.forwardIncoming({ text: '1', attachments: [{ url: 'http://x/y.png' }] });
  assert.equal(out.requestId, 'r1');
  assert.equal(seen.length, 1);
});

test('插件说序号不对 -> 退回聊天，不吞消息', async () => {
  const { serve, seen } = boot((url) => {
    if (url === PENDING) return { body: { ok: true, count: 2 } };
    if (url === DECIDE) return { status: 409, body: { ok: false, note: 'bad-index' } };
    return { body: { ok: true, requestId: 'r5' } };
  });
  const out = await serve.forwardIncoming({ text: '1 9', from: 'u' });
  assert.equal(out.requestId, 'r5');
  assert.deepEqual(seen.map((s) => s.url), [PENDING, DECIDE, 'http://127.0.0.1:43120/wechat-bridge/inbox']);
});

test('显式关掉（null）时一个探测请求都不发', async () => {
  const { serve, seen } = boot(() => ({ body: { ok: true, requestId: 'r1' } }), { approvalPendingUrl: null, approvalDecideUrl: null });
  const out = await serve.forwardIncoming({ text: '1', from: 'u' });
  assert.equal(out.requestId, 'r1');
  assert.deepEqual(seen.map((s) => s.url), ['http://127.0.0.1:43120/wechat-bridge/inbox']);
});

test('tryRemoteApproval 直接调用：空文本/超长文本都被拒', async () => {
  const { serve } = boot(() => ({ body: { ok: true, count: 1 } }));
  assert.equal(await serve.tryRemoteApproval('', false), null);
  assert.equal(await serve.tryRemoteApproval('1'.repeat(40), false), null);
  assert.equal(await serve.tryRemoteApproval('在吗', false), null);
});

test('state() 里能看到两条审批路由（排障用）', () => {
  const { serve } = boot(() => ({ body: { ok: true } }));
  const st = serve.state();
  assert.equal(st.approvalPendingUrl, PENDING);
  assert.equal(st.approvalDecideUrl, DECIDE);
});

// ---------- 卡已经没了要说话（别让回复看起来石沉大海） ----------
/** 和 boot 一样，但把 client.send 记下来（解释语走的是 QQ 腿，不走 fetchImpl）。 */
function bootRecording(routes, cfg) {
  const seen = [];
  const sent = [];
  const client = makeClient();
  client.send = (b) => { sent.push(b && b.text); return {}; };
  const serve = createServe(Object.assign({ client: client, fetchImpl: makeFetch(routes, seen), logger: () => {} }, cfg || {}));
  return { serve: serve, seen: seen, sent: sent };
}

test('APPROVAL_LIKELY_RE 只挑「一看就是回审批卡」的', () => {
  for (const s of ['1', '2', '1 2', '2-3', '同意', '拒绝', '允许', '批准', '不同意', '同意:1']) {
    assert.equal(APPROVAL_LIKELY_RE.test(s), true, s + ' 应该算「像在回卡」');
  }
  for (const s of ['好', '行', '可以', 'ok', 'yes', '在吗', '11', '']) {
    assert.equal(APPROVAL_LIKELY_RE.test(s), false, s + ' 平时也是聊天，不该报警');
  }
});

test('buildStaleNotice 说清「去哪了」', () => {
  const n = buildStaleNotice('1');
  assert.ok(n.includes('「1」'));
  assert.ok(n.includes('没有任何待审批的卡'));
  assert.ok(n.includes('不是被吞了'));
});

test('没有待批 + 回「1」-> 照旧投进会话，另外回一句解释', async () => {
  const { serve, seen, sent } = bootRecording((url) => {
    if (url === PENDING) return { body: { ok: true, count: 0, pending: [] } };
    return { body: { ok: true, requestId: 'r1' } };
  });
  const out = await serve.forwardIncoming({ text: '1', from: 'u' });
  assert.equal(out.requestId, 'r1');
  assert.equal(serve.stats.forwards, 1);
  assert.equal(serve.stats.approvalStale, 1);
  assert.equal(serve.stats.approvalReplies, 0);
  assert.deepEqual(seen.map((s) => s.url), [PENDING, 'http://127.0.0.1:43120/wechat-bridge/inbox']);
  await new Promise((r) => setTimeout(r, 10));
  assert.equal(sent.length, 1);
  assert.ok(sent[0].includes('没有任何待审批的卡'));
});

test('没有待批 + 回「好」-> 照旧投进会话，但一句解释都不发', async () => {
  const { serve, sent } = bootRecording((url) => {
    if (url === PENDING) return { body: { ok: true, count: 0, pending: [] } };
    return { body: { ok: true, requestId: 'r1' } };
  });
  const out = await serve.forwardIncoming({ text: '好', from: 'u' });
  assert.equal(out.requestId, 'r1');
  assert.equal(serve.stats.forwards, 1);
  assert.equal(serve.stats.approvalStale, 1);
  await new Promise((r) => setTimeout(r, 10));
  assert.equal(sent.length, 0);
});

test('有待批时不发「没有待批」的解释', async () => {
  const { serve, sent } = bootRecording((url) => {
    if (url === PENDING) return { body: { ok: true, count: 1, pending: [{ id: 'a', toolName: 'Bash' }] } };
    if (url === DECIDE) return { body: { ok: true, id: 'a', toolName: 'Bash', outcome: 'allowed-once' } };
    return { body: { ok: true, requestId: 'r1' } };
  });
  const out = await serve.forwardIncoming({ text: '1', from: 'u' });
  assert.equal(out.approval, true);
  await new Promise((r) => setTimeout(r, 10));
  assert.equal(sent.length, 0);
});

test('approvalStaleNotice:false 时保持沉默', async () => {
  const { serve, sent } = bootRecording((url) => {
    if (url === PENDING) return { body: { ok: true, count: 0, pending: [] } };
    return { body: { ok: true, requestId: 'r1' } };
  }, { approvalStaleNotice: false });
  const out = await serve.forwardIncoming({ text: '1', from: 'u' });
  assert.equal(out.requestId, 'r1');
  await new Promise((r) => setTimeout(r, 10));
  assert.equal(sent.length, 0);
});
