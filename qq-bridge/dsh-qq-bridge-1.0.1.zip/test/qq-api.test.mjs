// qq/qq-api.test.mjs — REST 调用离线自检：鉴权头、err_code 判定、路径拼接
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApi, ERR_MSG_ID_EXPIRED } from '../src/qq-api.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-api-test.log');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

async function main() {
  const seen = [];
  const fetchImpl = async (url, init) => {
    seen.push({ url, init });
    return { ok: true, status: 200, json: async () => ({ id: 'MSG1' }) };
  };
  let tokenCalls = 0;
  const api = createApi({ fetchImpl, getToken: async () => { tokenCalls += 1; return 'ACCESS'; } });

  const out = await api.sendC2C('OPENID_1', { content: 'hi', msg_type: 0, msg_id: 'M9', msg_seq: 1 });
  eq('发消息返回体', out.id, 'MSG1');
  eq('URL 正确', seen[0].url, 'https://api.bot.qq.com/v2/users/OPENID_1/messages');
  eq('方法 POST', seen[0].init.method, 'POST');
  eq('鉴权头是 QQBot 前缀', seen[0].init.headers.authorization, 'QQBot ACCESS');
  eq('content-type json', seen[0].init.headers['content-type'], 'application/json; charset=utf-8');
  eq('body 原样传递', JSON.parse(seen[0].init.body).msg_id, 'M9');
  eq('token 只取一次', tokenCalls, 1);

  // openid 需要 URL 编码
  await api.sendC2C('a b/c', { content: 'x', msg_type: 0 });
  eq('openid 做了编码', seen[1].url, 'https://api.bot.qq.com/v2/users/a%20b%2Fc/messages');

  // GET /gateway
  const gwFetch = async (url, init) => {
    seen.push({ url, init });
    return { ok: true, status: 200, json: async () => ({ url: 'wss://api.bot.qq.com/websocket/' }) };
  };
  const api2 = createApi({ fetchImpl: gwFetch, getToken: async () => 'T' });
  const gw = await api2.getGateway();
  eq('gateway 地址', gw.url, 'wss://api.bot.qq.com/websocket/');
  eq('gateway 方法 GET', seen[2].init.method, 'GET');
  ok('GET 不带 body', seen[2].init.body === undefined, String(seen[2].init.body));

  // HTTP 401
  const api401 = createApi({ fetchImpl: async () => ({ ok: false, status: 401, json: async () => ({ err_code: 11244, message: 'token 无效' }) }), getToken: async () => 'T' });
  let err = null;
  try { await api401.sendC2C('X', { content: 'y' }); } catch (e) { err = e; }
  ok('HTTP 401 抛错', err !== null && /http=401/.test(err.message), err && err.message);
  eq('errCode 透出', err && err.errCode, 11244);

  // HTTP 200 但 body 里 err_code 非 0 —— 必须也算失败（官方要求看 err_code）
  const apiErrBody = createApi({ fetchImpl: async () => ({ ok: true, status: 200, json: async () => ({ err_code: 40034005, message: '回复消息msg_id已过期', trace_id: 't' }) }), getToken: async () => 'T' });
  err = null;
  try { await apiErrBody.sendC2C('X', { content: 'y' }); } catch (e) { err = e; }
  ok('200 但 err_code 非 0 也抛错', err !== null, err && err.message);
  eq('40034005 常量对得上', err && err.errCode, ERR_MSG_ID_EXPIRED);
  ok('错误信息里带 err_code', err !== null && /err_code=40034005/.test(err.message), err && err.message);

  // err_code: 0 视为成功
  const apiZero = createApi({ fetchImpl: async () => ({ ok: true, status: 200, json: async () => ({ err_code: 0, id: 'OK1' }) }), getToken: async () => 'T' });
  const okOut = await apiZero.sendC2C('X', { content: 'y' });
  eq('err_code 0 = 成功', okOut.id, 'OK1');

  // 429 频率限制
  const api429 = createApi({ fetchImpl: async () => ({ ok: false, status: 429, json: async () => ({ err_code: 11234, message: '频率限制' }) }), getToken: async () => 'T' });
  err = null;
  try { await api429.sendC2C('X', { content: 'y' }); } catch (e) { err = e; }
  eq('429 状态码透出', err && err.status, 429);

  // getToken 失败 -> 不发起请求
  let called = false;
  const apiNoTok = createApi({ fetchImpl: async () => { called = true; return { ok: true, status: 200, json: async () => ({}) }; }, getToken: async () => { throw new Error('boom'); } });
  err = null;
  try { await apiNoTok.sendC2C('X', { content: 'y' }); } catch (e) { err = e; }
  ok('取 token 失败直接抛', err !== null && /get-token: boom/.test(err.message), err && err.message);
  eq('取 token 失败不发请求', called, false);

  // 群聊：POST /v2/groups/{group_openid}/messages（group_openid 同样要 URL 编码）
  const gSeen = [];
  const apiG = createApi({ fetchImpl: async (url, init) => { gSeen.push({ url, init }); return { ok: true, status: 200, json: async () => ({ id: 'GMSG1' }) }; }, getToken: async () => 'GT' });
  const gOut = await apiG.sendGroup('GRP/a b', { content: 'hi group', msg_type: 0, msg_id: 'G9', msg_seq: 1 });
  eq('群聊返回体', gOut.id, 'GMSG1');
  eq('群聊 URL 正确', gSeen[0].url, 'https://api.bot.qq.com/v2/groups/GRP%2Fa%20b/messages');
  eq('群聊方法 POST', gSeen[0].init.method, 'POST');
  eq('群聊鉴权头是 QQBot 前缀', gSeen[0].init.headers.authorization, 'QQBot GT');
  eq('群聊 body 原样传递', JSON.parse(gSeen[0].init.body).msg_id, 'G9');
  const apiGerr = createApi({ fetchImpl: async () => ({ ok: true, status: 200, json: async () => ({ err_code: 40034005, message: 'x' }) }), getToken: async () => 'T' });
  err = null;
  try { await apiGerr.sendGroup('G', { content: 'y' }); } catch (e) { err = e; }
  ok('群聊 err_code 判定同样生效', err !== null && err.errCode === ERR_MSG_ID_EXPIRED, err && err.message);

  const lines = [];
  lines.push('# qq-api 测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
