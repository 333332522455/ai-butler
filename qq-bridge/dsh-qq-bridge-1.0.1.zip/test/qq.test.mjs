// qq/qq.test.mjs — QQ 腿外壳（token+REST+WS 拼装层）离线自检
// 假 api / 假 gateway，不联网：去重、被动回复计数与 msg_seq、过期回退主动、typing、截断、state 透传。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createQq, C2C_MESSAGE_CREATE, GROUP_AT_MESSAGE_CREATE, C2C_MSG_RECEIVE, C2C_MSG_REJECT, DEFAULT_INTENTS } from '../src/qq.mjs';
import { ERR_MSG_ID_EXPIRED } from '../src/qq-api.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-test.log');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

function makeApi() {
  const calls = [];
  const groupCalls = [];
  const api = {
    calls: calls,
    groupCalls: groupCalls,
    fail: null,       // {errCode, times}
    sendGroup: async (groupOpenid, payload) => {
      groupCalls.push({ groupOpenid: groupOpenid, payload: JSON.parse(JSON.stringify(payload)) });
      if (api.fail && api.fail.times > 0) {
        api.fail.times -= 1;
        const err = new Error('msg_id expired');
        err.errCode = api.fail.errCode;
        err.status = 200;
        throw err;
      }
      return { id: 'G' + groupCalls.length, timestamp: 1700000000 };
    },
    sendC2C: async (openid, payload) => {
      calls.push({ openid: openid, payload: JSON.parse(JSON.stringify(payload)) });
      if (api.fail && api.fail.times > 0) {
        api.fail.times -= 1;
        const err = new Error('msg_id expired');
        err.errCode = api.fail.errCode;
        err.status = 200;
        throw err;
      }
      return { id: 'R' + calls.length, timestamp: 1700000000 };
    },
  };
  return api;
}

function makeGateway() {
  const g = { starts: 0, stops: 0 };
  const gw = {
    start: async () => { g.starts += 1; return { connected: true, identified: false }; },
    stop: () => { g.stops += 1; return { connected: false }; },
    state: () => ({ connected: true, identified: false, sessionId: null, seq: null, intents: DEFAULT_INTENTS, lastError: null }),
  };
  return { gw: gw, counters: g };
}

function msgEvent(id, text, openid) {
  return { id: id, content: text, author: { user_openid: openid === undefined ? 'OPENID-A' : openid }, timestamp: 1700000000000, message_type: 0 };
}

function groupEvent(id, text, groupOpenid, memberOpenid) {
  return { id: id, content: text, group_openid: groupOpenid, author: { member_openid: memberOpenid }, timestamp: 1700000000000, message_type: 0 };
}

async function main() {
  // ---------- 入站解析与去重 ----------
  {
    const api = makeApi();
    const { gw } = makeGateway();
    const qq = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    const seenMsgs = [];
    qq.onMessage((m) => { seenMsgs.push(m); });

    eq('无关事件返回 null', await qq.handleEvent('FRIEND_ADD', { id: 'F1' }), null);
    eq('无关事件不计数', qq.stats.received, 0);

    const m1 = await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M1', '你好'));
    eq('入站消息体 text', m1.text, '你好');
    eq('入站消息体 from', m1.from, 'OPENID-A');
    eq('入站消息体 messageId', m1.messageId, 'M1');
    eq('received 计数', qq.stats.received, 1);
    eq('handler 收到一条', seenMsgs.length, 1);
    eq('lastMessage 字数', qq.state().lastMessage.chars, 2);
    eq('recent 头一条 id', qq.state().recent[0].id, 'M1');
    eq('lastOpenid 记住', qq.state().lastOpenid, 'OPENID-A');
    eq('lastMsgId 记住', qq.state().lastMsgId, 'M1');

    // 同一 msg_id 重复推送必须去重（官方明说可能重复）
    const dup = await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M1', '你好'));
    eq('重复消息返回 null', dup, null);
    eq('duplicates 计数', qq.stats.duplicates, 1);
    eq('handler 仍只有一条', seenMsgs.length, 1);
    eq('seenSize 只记 1', qq.seenSize(), 1);

    // 没有 id 的事件不去重（id 为空的边界）
    const noId = msgEvent(null, 'x');
    delete noId.id;
    await qq.handleEvent(C2C_MESSAGE_CREATE, noId);
    await qq.handleEvent(C2C_MESSAGE_CREATE, noId);
    eq('无 id 不去重', qq.stats.received, 3);

    // handler 抛错不影响主流程
    const qq2 = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    qq2.onMessage(() => { throw new Error('boom'); });
    const raced = await qq2.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M9', 'x'));
    ok('handler 抛错仍返回消息', raced !== null);
    eq('handlerErrors 计数', qq2.stats.handlerErrors, 1);

    // 退订
    const qq3 = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    let n = 0;
    const off = qq3.onMessage(() => { n += 1; });
    await qq3.handleEvent(C2C_MESSAGE_CREATE, msgEvent('A1', 'x'));
    off();
    await qq3.handleEvent(C2C_MESSAGE_CREATE, msgEvent('A2', 'x'));
    eq('退订后不再回调', n, 1);

    // 内容缺失 / author 缺失
    const bare = await qq3.handleEvent(C2C_MESSAGE_CREATE, { id: 'B1' });
    eq('缺 content 得空串', bare.text, '');
    eq('缺 author 得 null', bare.from, null);
  }

  // ---------- 发送：主动 / 被动 / 回退 / 截断 ----------
  {
    const api = makeApi();
    const { gw, counters } = makeGateway();
    const qq = createQq({ api: api, gateway: gw, openid: 'OPENID-CFG', tokenManager: { peek: () => null, getToken: async () => 'T' } });

    // 没有 openid 也没有人说过话 -> 明确报错
    const bare = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    let e1 = null;
    try { await bare.send({ text: 'hi' }); } catch (e) { e1 = e; }
    ok('没有 openid 时报 no-openid', e1 !== null && /no-openid/.test(e1.message), e1 && e1.message);

    let e2 = null;
    try { await qq.send({ text: '' }); } catch (e) { e2 = e; }
    ok('空文本报错', e2 !== null && /text 为空/.test(e2.message), e2 && e2.message);

    // 有人发过消息之前：走主动消息（不带 msg_id）
    await qq.send({ text: '主动问候' });
    eq('主动消息 endpoint openid', api.calls[0].openid, 'OPENID-CFG');
    eq('主动消息 content', api.calls[0].payload.content, '主动问候');
    eq('主动消息 msg_type', api.calls[0].payload.msg_type, 0);
    eq('主动消息不带 msg_id', 'msg_id' in api.calls[0].payload, false);
    eq('activeReplies 计数', qq.stats.activeReplies, 1);

    // 收到消息后：被动回复带 msg_id + 递增 msg_seq
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M100', '在吗', 'OPENID-USER'));
    await qq.send({ text: '第一条' });
    const p1 = api.calls[api.calls.length - 1].payload;
    eq('被动回复用发消息人的 openid', api.calls[api.calls.length - 1].openid, 'OPENID-USER');
    eq('被动回复带 msg_id', p1.msg_id, 'M100');
    eq('被动回复 msg_seq=1', p1.msg_seq, 1);
    await qq.send({ text: '第二条' });
    eq('第二条 msg_seq=2', api.calls[api.calls.length - 1].payload.msg_seq, 2);
    eq('passiveReplies 计数', qq.stats.passiveReplies, 2);

    // 再来一条新消息 -> 计数清零，msg_id 换成新的
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M101', '还在吗', 'OPENID-USER'));
    await qq.send({ text: '第三条' });
    const p2 = api.calls[api.calls.length - 1].payload;
    eq('新消息换 msg_id', p2.msg_id, 'M101');
    eq('新消息 msg_seq 归 1', p2.msg_seq, 1);

    // 用满 4 次被动后自动转主动
    await qq.send({ text: '第四条' });
    await qq.send({ text: '第五条' });
    await qq.send({ text: '第六条' });
    eq('第 4 条被动仍带 msg_id', api.calls[api.calls.length - 1].payload.msg_id, 'M101');
    eq('第 4 条 msg_seq=4', api.calls[api.calls.length - 1].payload.msg_seq, 4);
    await qq.send({ text: '第七条' });
    const pActive = api.calls[api.calls.length - 1].payload;
    eq('第 5 条起不带 msg_id（转主动）', 'msg_id' in pActive, false);
    eq('activeReplies 变成 2', qq.stats.activeReplies, 2);

    // 过期错误码 -> 退回主动消息一次
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M102', 'x', 'OPENID-USER'));
    const okBefore = qq.stats.sendOk;
    api.fail = { errCode: ERR_MSG_ID_EXPIRED, times: 1 };
    const out = await qq.send({ text: '过期回退' });
    ok('过期后仍拿到返回值', out && typeof out.id === 'string', JSON.stringify(out));
    eq('expiredRetries 计数', qq.stats.expiredRetries, 1);
    eq('回退那次的载荷没有 msg_id', 'msg_id' in api.calls[api.calls.length - 1].payload, false);
    eq('回退后 sendFailed 计 1 次', qq.stats.sendFailed, 1);
    eq('回退成功只多 1 次 sendOk', qq.stats.sendOk - okBefore, 1);
    api.fail = null;

    // 非过期错误码不吞
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M103', 'x', 'OPENID-USER'));
    api.fail = { errCode: 500, times: 1 };
    let e3 = null;
    try { await qq.send({ text: '别的错' }); } catch (e) { e3 = e; }
    ok('非过期 errCode 会抛', e3 !== null && e3.errCode === 500, e3 && String(e3.errCode));
    api.fail = null;

    // 截断
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M104', 'x', 'OPENID-USER'));
    const cut = createQq({ api: api, gateway: gw, openid: 'OID', maxContentChars: 5, splitLongText: false, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    await cut.send({ text: 'abcdefghij' });
    eq('超长截断补尾巴', api.calls[api.calls.length - 1].payload.content, 'abcde…（已截断）');

    // typing
    let et = null;
    try { await bare.typing(); } catch (e) { et = e; }
    ok('typing 什么都没来时先报 no-msg-id', et !== null && /no-msg-id/.test(et.message), et && et.message);
    // 有 msg_id 但没有发消息人（缺 author）-> no-openid
    await bare.handleEvent(C2C_MESSAGE_CREATE, { id: 'NOAUTH' });
    let et1 = null;
    try { await bare.typing(); } catch (e) { et1 = e; }
    ok('typing 有 msg_id 无人时报 no-openid', et1 !== null && /no-openid/.test(et1.message), et1 && et1.message);
    let es1 = null;
    try { await bare.send({ text: 'x' }); } catch (e) { es1 = e; }
    ok('send 同样报 no-openid', es1 !== null && /no-openid/.test(es1.message), es1 && es1.message);
    const noMsg = createQq({ api: api, gateway: gw, openid: 'OID', tokenManager: { peek: () => null, getToken: async () => 'T' } });
    let et2 = null;
    try { await noMsg.typing(); } catch (e) { et2 = e; }
    ok('typing 无 msg_id 报错', et2 !== null && /no-msg-id/.test(et2.message), et2 && et2.message);
    await qq.typing();
    const pt = api.calls[api.calls.length - 1].payload;
    eq('typing msg_type=6', pt.msg_type, 6);
    eq('typing input_notify.input_type=1', pt.input_notify.input_type, 1);
    eq('typing 带 msg_id', pt.msg_id, 'M104');
    ok('typing msg_seq 避开被动回复号段', pt.msg_seq >= 14, String(pt.msg_seq));
    eq('typingOk 计数', qq.stats.typingOk, 1);

    // start / stop / state 透传
    await qq.start();
    qq.stop();
    eq('start 透传', counters.starts, 1);
    eq('stop 透传', counters.stops, 1);
    eq('state 带 token', qq.state().token, null);
    eq('state 里 intents 来自网关', qq.state().intents, DEFAULT_INTENTS);
  }

  // ---------- 发送重试（网络抖动 / 服务端 5xx 自动重发）----------
  {
    // 裸 Error（无 status / errCode）= 网络层失败 -> 应该重试
    const calls = [];
    const flaky = {
      sendC2C: async (openid, payload) => {
        calls.push(JSON.parse(JSON.stringify(payload)));
        if (calls.length <= 2) throw new Error('fetch failed');
        return { id: 'R-retry', timestamp: 1700000001 };
      },
      sendGroup: async () => { throw new Error('unused'); },
    };
    const { gw } = makeGateway();
    const logs = [];
    const qq = createQq({ api: flaky, gateway: gw, logger: (e) => logs.push(e), retryDelayMs: 1, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('MR1', 'hi', 'OPENID-USER'));
    const out = await qq.send({ text: '重试一下' });
    ok('网络抖动重试后成功', calls.length === 3 && out !== null && out.id === 'R-retry', 'calls=' + calls.length);
    eq('retryAttempts 计数', qq.stats.retryAttempts, 2);
    eq('retryOk 计数', qq.stats.retryOk, 1);
    ok('发了 send-retry 日志', logs.some((l) => l.kind === 'send-retry'), JSON.stringify(logs.map((l) => l.kind)));
    ok('被动回复重试换了新 msg_seq', calls[2].msg_seq > calls[0].msg_seq, calls[0].msg_seq + '->' + calls[2].msg_seq);
    eq('重试仍带同一个 msg_id', calls[2].msg_id, 'MR1');

    // 4xx 参数错：重发也没用，只发一次
    const calls2 = [];
    const hard = {
      sendC2C: async (openid, payload) => { calls2.push(payload); const e = new Error('bad-param'); e.status = 400; e.errCode = 40034001; throw e; },
      sendGroup: async () => { throw new Error('unused'); },
    };
    const qq2 = createQq({ api: hard, gateway: gw, retryDelayMs: 1, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    await qq2.handleEvent(C2C_MESSAGE_CREATE, msgEvent('MR2', 'hi', 'OPENID-USER'));
    let e2 = null;
    try { await qq2.send({ text: '参数错' }); } catch (e) { e2 = e; }
    ok('4xx 不重试只发一次', e2 !== null && calls2.length === 1, 'calls=' + calls2.length);
    eq('4xx 不计 retryAttempts', qq2.stats.retryAttempts, 0);

    // 被动回复过期：不在这里重试，照旧回退主动消息（老行为不能变）
    const calls3 = [];
    const exp = {
      sendC2C: async (openid, payload) => {
        calls3.push(JSON.parse(JSON.stringify(payload)));
        if (calls3.length === 1) { const e = new Error('msg_id expired'); e.status = 200; e.errCode = ERR_MSG_ID_EXPIRED; throw e; }
        return { id: 'R-active', timestamp: 1700000002 };
      },
      sendGroup: async () => { throw new Error('unused'); },
    };
    const qq3 = createQq({ api: exp, gateway: gw, retryDelayMs: 1, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    await qq3.handleEvent(C2C_MESSAGE_CREATE, msgEvent('MR3', 'hi', 'OPENID-USER'));
    const out3 = await qq3.send({ text: '过期' });
    ok('过期照旧回退主动消息', out3 !== null && out3.id === 'R-active' && calls3.length === 2 && calls3[1].msg_id === undefined, JSON.stringify(calls3.map((c) => c.msg_id)));
    eq('过期不计 retryAttempts', qq3.stats.retryAttempts, 0);
  }

  // ---------- 群聊（GROUP_AT_MESSAGE_CREATE）----------
  {
    const api = makeApi();
    const { gw } = makeGateway();
    const qq = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    const got = [];
    qq.onMessage((m) => { got.push(m); });

    const g1 = await qq.handleEvent(GROUP_AT_MESSAGE_CREATE, groupEvent('GM1', '大家好', 'GRP-1', 'MEMBER-1'));
    eq('群聊 text', g1.text, '大家好');
    eq('群聊 from 是发言人 member_openid', g1.from, 'MEMBER-1');
    eq('群聊 channel', g1.channel, 'group');
    eq('群聊 groupOpenid', g1.groupOpenid, 'GRP-1');
    eq('群聊 memberOpenid', g1.memberOpenid, 'MEMBER-1');
    eq('群聊计数 groupReceived', qq.stats.groupReceived, 1);
    eq('群聊 handler 收到一条', got.length, 1);
    eq('lastChannel 记 group', qq.state().lastChannel, 'group');
    eq('lastGroupOpenid 记住', qq.state().lastGroupOpenid, 'GRP-1');
    eq('lastMessage 带 channel', qq.state().lastMessage.channel, 'group');

    // 同 id 重复推送去重（与单聊共用一张表）
    eq('群聊重复返回 null', await qq.handleEvent(GROUP_AT_MESSAGE_CREATE, groupEvent('GM1', '大家好', 'GRP-1', 'MEMBER-1')), null);
    eq('群聊 duplicates 计数', qq.stats.duplicates, 1);

    // 回复默认回到最近那条消息所在的会话（这里是群）
    await qq.send({ text: '收到' });
    const gp = api.groupCalls[api.groupCalls.length - 1];
    eq('群聊回复走 sendGroup', api.groupCalls.length, 1);
    eq('群聊回复目标 group_openid', gp.groupOpenid, 'GRP-1');
    eq('群聊回复 content', gp.payload.content, '收到');
    eq('群聊被动回复带 msg_id', gp.payload.msg_id, 'GM1');
    eq('群聊被动回复 msg_seq=1', gp.payload.msg_seq, 1);
    eq('群聊回复没走单聊接口', api.calls.length, 0);
    eq('groupReplies 计数', qq.stats.groupReplies, 1);

    // 再一条群消息 -> msg_id 换新、msg_seq 归零
    await qq.handleEvent(GROUP_AT_MESSAGE_CREATE, groupEvent('GM2', '在吗', 'GRP-1', 'MEMBER-2'));
    await qq.send({ text: '在' });
    const gp2 = api.groupCalls[api.groupCalls.length - 1];
    eq('新群消息换 msg_id', gp2.payload.msg_id, 'GM2');
    eq('新群消息 msg_seq 归 1', gp2.payload.msg_seq, 1);

    // 显式指定 openid -> 回到单聊，且不带群消息的 msg_id（跨会话不能借 msg_id）
    await qq.send({ text: '私聊他', openid: 'OPENID-X' });
    const c2 = api.calls[api.calls.length - 1];
    eq('显式 openid 走单聊', c2.openid, 'OPENID-X');
    eq('跨会话回复不带 msg_id', 'msg_id' in c2.payload, false);

    // 群聊 typing 也走群接口
    await qq.typing();
    const gtp = api.groupCalls[api.groupCalls.length - 1].payload;
    eq('群聊 typing msg_type=6', gtp.msg_type, 6);
    eq('群聊 typing 带 msg_id', gtp.msg_id, 'GM2');

    // 群聊过期回退主动
    await qq.handleEvent(GROUP_AT_MESSAGE_CREATE, groupEvent('GM3', 'x', 'GRP-1', 'MEMBER-1'));
    const okBefore = qq.stats.sendOk;
    api.fail = { errCode: ERR_MSG_ID_EXPIRED, times: 1 };
    const outG = await qq.send({ text: '过期回退' });
    ok('群聊过期回退仍拿到返回值', outG !== null && String(outG.id).charAt(0) === 'G', JSON.stringify(outG));
    eq('群聊回退那次的载荷没有 msg_id', 'msg_id' in api.groupCalls[api.groupCalls.length - 1].payload, false);
    eq('群聊回退只多 1 次 sendOk', qq.stats.sendOk - okBefore, 1);
    api.fail = null;

    // 群事件但缺 group_openid -> 明确报 no-group-openid
    const solo = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    await solo.handleEvent(GROUP_AT_MESSAGE_CREATE, { id: 'GM9', content: 'x', author: { member_openid: 'M' } });
    let eg = null;
    try { await solo.send({ text: 'x' }); } catch (e) { eg = e; }
    ok('群聊缺 group_openid 报 no-group-openid', eg !== null && /no-group-openid/.test(eg.message), eg && eg.message);
  }

  // ---------- 附件（图片 / 语音 / 文件）解析 ----------
  {
    const api = makeApi();
    const { gw } = makeGateway();
    const qq = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    const got = [];
    qq.onMessage((m) => { got.push(m); });
    const ev = msgEvent('MA1', '[图片]');
    ev.attachments = [
      JSON.stringify({ content_type: 'image/png', filename: 'a.png', url: 'https://cdn/a.png', size: 10, width: 4, height: 5 }),
      'not json',
      JSON.stringify({ content_type: 'audio/silk', voice_wav_url: 'https://cdn/v.silk' }),
    ];
    const a1 = await qq.handleEvent(C2C_MESSAGE_CREATE, ev);
    eq('附件解析出 2 条（坏项丢掉）', a1.attachments.length, 2);
    eq('第一张 kind', a1.attachments[0].kind, 'image');
    eq('第一张 url', a1.attachments[0].url, 'https://cdn/a.png');
    eq('第一张带宽高', a1.attachments[0].width + 'x' + a1.attachments[0].height, '4x5');
    eq('语音走 voice_wav_url', a1.attachments[1].url, 'https://cdn/v.silk');
    eq('入站 text 仍是文字部分', a1.text, '[图片]');
    eq('handler 也拿到附件', got[0].attachments.length, 2);
    eq('mediaMessages 计数', qq.stats.mediaMessages, 1);
    eq('mediaFiles 计数', qq.stats.mediaFiles, 2);
    eq('lastMessage 带 media 数', qq.state().lastMessage.media, 2);
    eq('recent 带 media 数', qq.state().recent[0].media, 2);

    const a2 = await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('MA2', '纯文字'));
    eq('没附件时是空数组', a2.attachments.length, 0);
    eq('纯文字不计 mediaMessages', qq.stats.mediaMessages, 1);
    eq('lastMessage media 归零', qq.state().lastMessage.media, 0);

    // 群聊里的附件同样解析（QQ 群图片也在 attachments 里）
    const gev = groupEvent('MG1', '[图]', 'GROUP-1', 'MEMBER-1');
    gev.attachments = [JSON.stringify({ content_type: 'image/jpeg', url: 'https://cdn/g.jpg', width: 100, height: 50 })];
    const g1 = await qq.handleEvent(GROUP_AT_MESSAGE_CREATE, gev);
    eq('群聊附件解析', g1.attachments.length, 1);
    eq('群聊附件 kind', g1.attachments[0].kind, 'image');
    eq('群聊 mediaFiles 累计', qq.stats.mediaFiles, 3);
  }

  // ---------- 主动消息开关（QQ 里机器人资料卡上的那个开关）----------
  {
    const api = makeApi();
    const { gw } = makeGateway();
    const logs = [];
    const qq = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' }, logger: (e) => logs.push(e) });
    eq('默认开关状态未知', qq.state().activePush, 'unknown');
    ok('默认标签提示未知', String(qq.state().activePushLabel).indexOf('未知') === 0, qq.state().activePushLabel);
    eq('默认没收到过开关事件', qq.state().activePushEvents, 0);

    const on = await qq.handleEvent(C2C_MSG_RECEIVE, { openid: 'U1', timestamp: 1700000000 });
    eq('开启事件回执 activePush', on.activePush, 'on');
    eq('开启事件 openid', on.openid, 'U1');
    eq('状态变 on', qq.state().activePush, 'on');
    eq('标签可用', qq.state().activePushLabel, '可用');
    eq('事件计数 1', qq.state().activePushEvents, 1);
    ok('开关时间戳是 ISO', typeof qq.state().activePushAt === 'string' && qq.state().activePushAt.indexOf('T') > 0, qq.state().activePushAt);
    eq('开启日志 kind', logs[0].kind, 'active-push-on');
    eq('开启事件不算消息', qq.stats.received, 0);

    eq('别的无关事件仍是 null', await qq.handleEvent('FRIEND_ADD', { id: 'F2' }), null);
    eq('别的无关事件不改开关', qq.state().activePush, 'on');

    const off = await qq.handleEvent(C2C_MSG_REJECT, { openid: 'U1', timestamp: 1700000001 });
    eq('关闭事件回执', off.activePush, 'off');
    eq('状态变 off', qq.state().activePush, 'off');
    eq('标签已关闭', qq.state().activePushLabel, '已关闭');
    eq('事件计数 2', qq.state().activePushEvents, 2);
    eq('关闭日志 kind', logs[logs.length - 1].kind, 'active-push-off');

    const again = await qq.handleEvent(C2C_MSG_RECEIVE, {});
    eq('再开回来', qq.state().activePush, 'on');
    eq('事件体没有 openid 也不炸', again.openid, null);
  }

  // ---------- 主动发送成功 => 反推开关是开的 ----------
  {
    const api = makeApi();
    const { gw } = makeGateway();
    const logs = [];
    const qq = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' }, logger: (e) => logs.push(e) });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('P1', '在吗'));
    eq('先记下 msg_id', qq.state().lastMsgId, 'P1');
    await qq.send({ text: '主动一条', passive: false });
    eq('payload 不带 msg_id', api.calls[0].payload.msg_id, undefined);
    eq('主动回复计数', qq.stats.activeReplies, 1);
    eq('主动成功反推开关 on', qq.state().activePush, 'on');
    eq('反推后标签可用', qq.state().activePushLabel, '可用');
    ok('反推有日志', logs.some((e) => e.kind === 'active-push-inferred-on'), JSON.stringify(logs));
    eq('反推不计开关事件数', qq.state().activePushEvents, 0);
  }

  // ---------- 群聊的主动发送不代表单聊开关 ----------
  {
    const api = makeApi();
    const { gw } = makeGateway();
    const qq = createQq({ api: api, gateway: gw, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    await qq.handleEvent(GROUP_AT_MESSAGE_CREATE, groupEvent('G1', '@bot 在吗', 'GROUP-1', 'MEM-1'));
    await qq.send({ text: '群回一条', passive: false });
    eq('群里走了主动消息', api.groupCalls.length, 1);
    eq('单聊开关仍未知', qq.state().activePush, 'unknown');
  }
  // ---------- seenLimit 淘汰 ----------
  {
    const api = makeApi();
    const { gw } = makeGateway();
    const qq = createQq({ api: api, gateway: gw, seenLimit: 2, tokenManager: { peek: () => null, getToken: async () => 'T' } });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('S1', 'x'));
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('S2', 'x'));
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('S3', 'x'));
    eq('seenLimit 生效', qq.seenSize(), 2);
    // 被挤掉的老 id 再进来算新消息（记忆有上限的代价）
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('S1', 'x'));
    eq('被淘汰的 id 重新计新', qq.stats.received, 4);
  }

  const lines = [];
  lines.push('# qq 门面测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
