// test/run-all.mjs — 依次跑所有离线自检，任何一个非 0 退出就整体失败
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const FILES = [
  'qq.test.mjs',
  'qq-token.test.mjs',
  'qq-ws.test.mjs',
  'qq-media.test.mjs',
  'qq-api.test.mjs',
  'qq-split.test.mjs',
  'serve.test.mjs',
  'qq-media-send.test.mjs',
  'qq-approval.test.mjs',
  'live-qq.test.mjs',
];

function runOne(file) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [path.join(here, file)], { cwd: here, stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    child.stdout.on('data', (b) => { out += b; });
    child.stderr.on('data', (b) => { out += b; });
    child.on('close', (code) => resolve({ file, code, out }));
    child.on('error', (e) => resolve({ file, code: 1, out: String((e && e.message) || e) }));
  });
}

let failed = 0;
for (const file of FILES) {
  const r = await runOne(file);
  const tail = r.out.trim().split('\n').slice(-3).join(' | ');
  if (r.code !== 0) {
    failed += 1;
    console.log('FAIL ' + file + ' (exit ' + r.code + ')');
    console.log(r.out.trim().split('\n').slice(-20).join('\n'));
  } else {
    console.log('PASS ' + file + ' · ' + tail);
  }
}
console.log('');
console.log(failed === 0
  ? 'ALL PASS · ' + FILES.length + '/' + FILES.length
  : failed + '/' + FILES.length + ' FAILED');
if (failed > 0) process.exitCode = 1;
