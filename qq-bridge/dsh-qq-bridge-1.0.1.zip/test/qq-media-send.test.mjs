// qq/qq-media-send.test.mjs — 出站富媒体（发图）离线自检：假 api + 假 fetch，不联网、不真的发 QQ。
// 覆盖：file_type 归一 / normalizeMedia / buildUploadRequest / send({media}) 的「先上传拿 file_info 再 msg_type=7」
//       两跳、群聊、只发图不带字、上传失败、响应缺 file_info、被动过期退回主动、serve /send 的 media 透传与向后兼容。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import {
  createQq, C2C_MESSAGE_CREATE, GROUP_AT_MESSAGE_CREATE,
  normalizeMedia, buildUploadRequest, fileTypeOf,
} from '../src/qq.mjs';
import { createApi, FILE_TYPE_IMAGE, FILE_TYPE_VIDEO, FILE_TYPE_FILE, MSG_TYPE_RICH_MEDIA, ERR_MSG_ID_EXPIRED } from '../src/qq-api.mjs';
import { createServe, DEFAULT_INBOX_URL } from '../src/serve.mjs';
import { tempBase } from './_tmp.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-media-send-test.log');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

const tmpPng = path.join(tempBase(), 'qq-media-send-test.png');
const pngBytes = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
fs.writeFileSync(tmpPng, pngBytes);
const tmpPngB64 = pngBytes.toString('base64');

function makeGateway() {
  return {
    start: async () => ({ connected: true, identified: false }),
    stop: () => ({ connected: false }),
    state: () => ({ connected: true, identified: false }),
  };
}

function makeApi(o) {
  const opts = o || {};
  const sends = [];
  const groupSends = [];
  const uploads = [];
  const groupUploads = [];
  const api = {
    sends: sends, groupSends: groupSends, uploads: uploads, groupUploads: groupUploads,
    uploadFails: opts.uploadFails === true,
    uploadNoInfo: opts.uploadNoInfo === true,
    sendExpiredOnce: opts.sendExpiredOnce === true,
    sendC2C: async (openid, payload) => {
      sends.push({ openid: openid, payload: JSON.parse(JSON.stringify(payload)) });
      if (api.sendExpiredOnce && sends.length === 1) {
        const err = new Error('msg_id expired');
        err.errCode = ERR_MSG_ID_EXPIRED;
        err.status = 200;
        throw err;
      }
      return { id: 'R' + sends.length, timestamp: 1700000000 };
    },
    sendGroup: async (groupOpenid, payload) => {
      groupSends.push({ groupOpenid: groupOpenid, payload: JSON.parse(JSON.stringify(payload)) });
      return { id: 'G' + groupSends.length, timestamp: 1700000000 };
    },
    uploadC2C: async (openid, req) => {
      uploads.push({ openid: openid, req: JSON.parse(JSON.stringify(req)) });
      if (api.uploadFails) throw new Error('upload boom');
      if (api.uploadNoInfo) return { file_uuid: 'U1' };
      return { file_uuid: 'U1', file_info: 'FILE-INFO-1', ttl: 3600 };
    },
    uploadGroup: async (groupOpenid, req) => {
      groupUploads.push({ groupOpenid: groupOpenid, req: JSON.parse(JSON.stringify(req)) });
      if (api.uploadFails) throw new Error('upload boom');
      return { file_uuid: 'U2', file_info: 'FILE-INFO-G', ttl: 3600 };
    },
  };
  return api;
}

function makeQq(api, over) {
  const o = over || {};
  const logs = [];
  const qq = createQq({
    api: api,
    gateway: makeGateway(),
    openid: o.openid,
    logger: o.noLog === true ? null : (e) => { logs.push(e); },
    tokenManager: { peek: () => null, getToken: async () => 'T' },
  });
  qq.__logs = logs;
  return qq;
}

function msgEvent(id, text, openid) {
  return { id: id, content: text, author: { user_openid: openid === undefined ? 'OPENID-A' : openid }, timestamp: 1700000000000, message_type: 0 };
}
function groupEvent(id, text, groupOpenid, memberOpenid) {
  return { id: id, content: text, group_openid: groupOpenid, author: { member_openid: memberOpenid }, timestamp: 1700000000000, message_type: 0 };
}

function makeServeClient() {
  const sent = [];
  const typings = [];
  const st = {
    ready: true, connected: true, lastOpenid: 'OPENID-U', lastMessage: null, recent: [], lastError: null,
    activePush: 'on', activePushLabel: '可用', activePushAt: '2026-10-03T00:28:07.000Z',
    stats: {}, gateway: { stats: {} }, token: 'TK',
  };
  return {
    sent: sent, typings: typings,
    start: async () => ({ connected: true }),
    stop: () => {},
    send: async (m) => { sent.push(JSON.parse(JSON.stringify(m))); return { id: 'R' + sent.length }; },
    typing: async () => { typings.push(1); return { ok: true }; },
    onMessage: () => () => {},
    state: () => st,
  };
}

function req(port, method, pathname, body) {
  return new Promise((resolve, reject) => {
    const r = http.request({ host: '127.0.0.1', port: port, method: method, path: pathname, headers: { 'content-type': 'application/json' } }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString('utf8') }));
    });
    r.on('error', reject);
    if (body !== undefined) r.write(typeof body === 'string' ? body : JSON.stringify(body));
    r.end();
  });
}

async function bootServe(client) {
  const fetchCalls = [];
  const fakeFetch = async (url, init) => { fetchCalls.push({ url: url, init: init }); return { ok: true, status: 202, json: async () => ({ ok: true }) }; };
  const serve = createServe({
    client: client, port: 0, host: '127.0.0.1', fetchImpl: fakeFetch,
    inboxUrl: DEFAULT_INBOX_URL, prefix: '[QQ] ', journalFile: null, logger: null,
  });
  const addr = await serve.start({ connect: false });
  return { serve: serve, port: addr.port, client: client, fetchCalls: fetchCalls };
}

async function main() {
  // ---------- 1) file_type 归一 ----------
  {
    eq('png -> 图片', fileTypeOf('.png'), FILE_TYPE_IMAGE);
    eq('大写 JPG -> 图片', fileTypeOf('A.JPG'), FILE_TYPE_IMAGE);
    eq('mime image/png -> 图片', fileTypeOf('image/png'), FILE_TYPE_IMAGE);
    eq('mp4 -> 视频', fileTypeOf('clip.mp4'), FILE_TYPE_VIDEO);
    eq('数字 3 -> 3', fileTypeOf(3), 3);
    eq('字符串 2 -> 2', fileTypeOf('2'), 2);
    eq('中文 图片 -> 图片', fileTypeOf('图片'), FILE_TYPE_IMAGE);
    eq('认不出用 fallback', fileTypeOf('照片.zzz', null), null);
    eq('空串用 fallback', fileTypeOf('', null), null);
    eq('默认 fallback 是文件', fileTypeOf('onlyname'), FILE_TYPE_FILE);
    eq('路径带扩展名', fileTypeOf('D:/a/b.png'), FILE_TYPE_IMAGE);
  }

  // ---------- 2) normalizeMedia ----------
  {
    eq('undefined -> null', normalizeMedia(undefined), null);
    eq('空串 -> null', normalizeMedia('   '), null);
    eq('数字 -> null', normalizeMedia(123), null);
    eq('空对象 -> null', normalizeMedia({}), null);
    const u = normalizeMedia('https://example.com/a.png');
    eq('http 串当 url', u.url, 'https://example.com/a.png');
    eq('http 串不留 path', u.path, null);
    const p = normalizeMedia('D:/a/b.png');
    eq('本地串当 path', p.path, 'D:/a/b.png');
    eq('本地串留文件名', p.fileName, 'D:/a/b.png');
    const d = normalizeMedia({ data: 'data:image/png;base64,QUJD' });
    eq('data URL 剥前缀', d.data, 'QUJD');
    eq('data URL 取 MIME', d.contentType, 'image/png');
    eq('data URL 推出 fileType', d.fileType, FILE_TYPE_IMAGE);
    const n = normalizeMedia({ path: 'D:/a/b.mp4', fileType: 'video' });
    eq('显式 fileType 生效', n.fileType, FILE_TYPE_VIDEO);
  }

  // ---------- 3) buildUploadRequest ----------
  {
    const r1 = buildUploadRequest(tmpPng);
    eq('路径上传 file_type 图片', r1.file_type, FILE_TYPE_IMAGE);
    eq('路径上传 srv_send_msg=false', r1.srv_send_msg, false);
    eq('路径上传读成 base64', r1.file_data, tmpPngB64);
    const r2 = buildUploadRequest('https://example.com/a.mp4');
    eq('url 上传走 url 字段', r2.url, 'https://example.com/a.mp4');
    eq('url 上传不让 base64', 'file_data' in r2, false);
    eq('url 上传 file_type 视频', r2.file_type, FILE_TYPE_VIDEO);
    const r3 = buildUploadRequest({ data: 'QUJD', fileType: 'image' });
    eq('data 上传直传', r3.file_data, 'QUJD');
    const r4 = buildUploadRequest(tmpPng, { srvSendMsg: true });
    eq('srvSendMsg 可覆盖', r4.srv_send_msg, true);
    let e = null;
    try { buildUploadRequest(null); } catch (err) { e = err; }
    ok('空 media 抛错', e !== null && /media 为空/.test(e.message), e && e.message);
  }

  // ---------- 4) send({media}) 单聊被动回复：先上传，再 msg_type=7 ----------
  {
    const api = makeApi();
    const qq = makeQq(api);
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M200', '看图', 'OPENID-U'));
    await qq.send({ text: '给你一张', media: tmpPng });
    eq('上传了一次', api.uploads.length, 1);
    eq('上传走的是发消息人的 openid', api.uploads[0].openid, 'OPENID-U');
    eq('上传 srv_send_msg=false', api.uploads[0].req.srv_send_msg, false);
    eq('上传 file_type 图片', api.uploads[0].req.file_type, FILE_TYPE_IMAGE);
    eq('上传带 base64', api.uploads[0].req.file_data, tmpPngB64);
    eq('然后只发了一条消息', api.sends.length, 1);
    const pl = api.sends[0].payload;
    eq('msg_type=7 富媒体', pl.msg_type, MSG_TYPE_RICH_MEDIA);
    eq('带上传回来的 file_info', pl.media.file_info, 'FILE-INFO-1');
    eq('文字照旧带上', pl.content, '给你一张');
    eq('被动回复仍带 msg_id', pl.msg_id, 'M200');
    eq('被动回复 msg_seq=1', pl.msg_seq, 1);
    eq('stats.mediaUploads', qq.stats.mediaUploads, 1);
    eq('stats.mediaSent', qq.stats.mediaSent, 1);
    eq('stats.mediaUploadFailed', qq.stats.mediaUploadFailed, 0);
    eq('stats.sendOk', qq.stats.sendOk, 1);
    eq('日志记了 media:true', qq.__logs[qq.__logs.length - 1].media, true);

    // 只发图，一个字都不带
    await qq.send({ media: tmpPng });
    const pl2 = api.sends[api.sends.length - 1].payload;
    eq('只发图 msg_type=7', pl2.msg_type, MSG_TYPE_RICH_MEDIA);
    eq('只发图不带 content', 'content' in pl2, false);
    eq('只发图仍带 file_info', pl2.media.file_info, 'FILE-INFO-1');
    eq('mediaSent 累加', qq.stats.mediaSent, 2);

    // 空文字 + 有图：允许（走发图）
    await qq.send({ text: '', media: tmpPng });
    eq('空文字有图也发', api.sends[api.sends.length - 1].payload.msg_type, MSG_TYPE_RICH_MEDIA);

    // 既没字也没图 -> 报错
    let e1 = null;
    try { await qq.send({}); } catch (err) { e1 = err; }
    ok('空消息报 text 为空', e1 !== null && /text 为空/.test(e1.message), e1 && e1.message);
    let e2 = null;
    try { await qq.send({ text: '   ' }); } catch (err) { e2 = err; }
    ok('纯空白文字报 text 为空', e2 !== null && /text 为空/.test(e2.message), e2 && e2.message);
  }

  // ---------- 5) send({media}) 群聊 ----------
  {
    const api = makeApi();
    const qq = makeQq(api);
    await qq.handleEvent(GROUP_AT_MESSAGE_CREATE, groupEvent('G1', '看图', 'GROUP-1', 'MEMBER-1'));
    await qq.send({ text: '群图', media: tmpPng });
    eq('群上传走 groups 接口', api.groupUploads.length, 1);
    eq('群上传目标', api.groupUploads[0].groupOpenid, 'GROUP-1');
    eq('群上传 srv_send_msg=false', api.groupUploads[0].req.srv_send_msg, false);
    eq('群消息走 groups 接口', api.groupSends.length, 1);
    eq('群消息 msg_type=7', api.groupSends[0].payload.msg_type, MSG_TYPE_RICH_MEDIA);
    eq('群消息用群上传的 file_info', api.groupSends[0].payload.media.file_info, 'FILE-INFO-G');
    eq('群消息带 msg_id', api.groupSends[0].payload.msg_id, 'G1');
    eq('单聊接口没被误用', api.sends.length, 0);
    eq('stats.groupReplies', qq.stats.groupReplies, 1);
    eq('stats.mediaSent', qq.stats.mediaSent, 1);
  }

  // ---------- 6) 上传失败 / 响应缺 file_info ----------
  {
    const api = makeApi({ uploadFails: true });
    const qq = makeQq(api);
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M300', 'x', 'OPENID-U'));
    let e = null;
    try { await qq.send({ text: '发不出去', media: tmpPng }); } catch (err) { e = err; }
    ok('上传失败要抛错', e !== null && /upload boom/.test(e.message), e && e.message);
    eq('上传失败就别发消息', api.sends.length, 0);
    eq('stats.mediaUploadFailed', qq.stats.mediaUploadFailed, 1);
    eq('stats.mediaSent 不动', qq.stats.mediaSent, 0);
    const kinds = qq.__logs.map((x) => x.kind);
    ok('日志记了 media-upload-failed', kinds.indexOf('media-upload-failed') >= 0, kinds.join(','));
  }
  {
    const api = makeApi({ uploadNoInfo: true });
    const qq = makeQq(api);
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M301', 'x', 'OPENID-U'));
    let e = null;
    try { await qq.send({ media: tmpPng }); } catch (err) { e = err; }
    ok('缺 file_info 要抛错', e !== null && /file_info/.test(e.message), e && e.message);
    eq('缺 file_info 不发消息', api.sends.length, 0);
  }

  // ---------- 7) 被动过期退回主动：媒体载荷要原样保留 ----------
  {
    const api = makeApi({ sendExpiredOnce: true });
    const qq = makeQq(api);
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M400', 'x', 'OPENID-U'));
    await qq.send({ text: '带图', media: tmpPng });
    eq('重试一共发了两次', api.sends.length, 2);
    eq('第一次是被动', api.sends[0].payload.msg_id, 'M400');
    eq('第二次摘掉 msg_id', 'msg_id' in api.sends[1].payload, false);
    eq('第二次摘掉 msg_seq', 'msg_seq' in api.sends[1].payload, false);
    eq('第二次仍是富媒体', api.sends[1].payload.msg_type, MSG_TYPE_RICH_MEDIA);
    eq('第二次保留 file_info', api.sends[1].payload.media.file_info, 'FILE-INFO-1');
    eq('第二次保留文字', api.sends[1].payload.content, '带图');
    eq('只上传一次', api.uploads.length, 1);
    eq('stats.expiredRetries', qq.stats.expiredRetries, 1);
    eq('stats.activeReplies', qq.stats.activeReplies, 1);
    eq('stats.mediaSent', qq.stats.mediaSent, 1);
  }

  // ---------- 8) qq-api：上传打的是 /files 且鉴权头正确 ----------
  {
    const calls = [];
    const fakeFetch = async (url, init) => {
      calls.push({ url: url, init: init, body: JSON.parse(init.body) });
      return { ok: true, status: 200, json: async () => ({ file_uuid: 'U9', file_info: 'FI9', ttl: 3600 }) };
    };
    const api = createApi({ baseUrl: 'https://api.bot.qq.com', fetchImpl: fakeFetch, getToken: async () => 'TOKEN-X' });
    const out = await api.uploadC2C('OPENID A/B', { file_type: FILE_TYPE_IMAGE, srv_send_msg: false, file_data: 'QUJD' });
    eq('上传 URL 是 /files', calls[0].url, 'https://api.bot.qq.com/v2/users/OPENID%20A%2FB/files');
    eq('上传方法是 POST', calls[0].init.method, 'POST');
    eq('鉴权头 QQBot', calls[0].init.headers.authorization, 'QQBot TOKEN-X');
    eq('请求体带 file_data', calls[0].body.file_data, 'QUJD');
    eq('请求体带 srv_send_msg', calls[0].body.srv_send_msg, false);
    eq('返回原样透出', out.file_info, 'FI9');
    const ug = await api.uploadGroup('G-1', { file_type: FILE_TYPE_FILE, srv_send_msg: false, file_data: 'QQ==' });
    eq('群上传 URL', calls[1].url, 'https://api.bot.qq.com/v2/groups/G-1/files');
    eq('群上传返回', ug.file_info, 'FI9');
  }

  // ---------- 9) serve /send：media 透传 + 老请求一字不改 ----------
  {
    const c = makeServeClient();
    const b = await bootServe(c);

    const r1 = await req(b.port, 'POST', '/send', { text: '看这个', media: 'D:/a/pic.png' });
    eq('带图 /send 200', r1.status, 200);
    const j1 = JSON.parse(r1.text);
    eq('返回 media=true', j1.media, true);
    eq('media 透传给 client', c.sent[0].media, 'D:/a/pic.png');
    eq('文字也透传', c.sent[0].text, '看这个');

    const r2 = await req(b.port, 'POST', '/send', { media: { url: 'https://example.com/a.png' } });
    eq('只发图 /send 200', r2.status, 200);
    eq('只发图 text 空串', c.sent[1].text, '');
    eq('只发图 media 是对象', c.sent[1].media.url, 'https://example.com/a.png');
    eq('只发图也记 media', JSON.parse(r2.text).media, true);

    const r3 = await req(b.port, 'POST', '/send', { media: {} });
    eq('空 media 对象当没给 -> 400', r3.status, 400);
    eq('空 media 对象原因', JSON.parse(r3.text).reason, 'text 为空');

    const r4 = await req(b.port, 'POST', '/send', { text: '只文字' });
    eq('纯文字 /send 200', r4.status, 200);
    const last = c.sent[c.sent.length - 1];
    eq('纯文字不带 media 键', 'media' in last, false);
    eq('纯文字 text 不变', last.text, '只文字');
    eq('纯文字返回 media=false', JSON.parse(r4.text).media, false);

    eq('stats.mediaSent 只数带图的', b.serve.stats.mediaSent, 2);
    const s = JSON.parse((await req(b.port, 'GET', '/status')).text);
    eq('/status 暴露 mediaSent', s.stats.mediaSent, 2);
    await b.serve.stop();
  }

  const lines = [];
  lines.push('# qq 出站图片（富媒体）测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
