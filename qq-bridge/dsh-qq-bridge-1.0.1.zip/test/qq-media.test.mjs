// qq/qq-media.test.mjs — 附件解析与落盘 离线自检（假 fetch，不联网，使用临时目录）
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseAttachment, parseAttachments, kindOf, safeName, createMediaStore, describeSaved } from '../src/qq-media.mjs';
import { tempBase } from './_tmp.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-media-test.log');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

const tmpRoot = fs.mkdtempSync(path.join(tempBase(), 'qq-media-test-'));

// 假 fetch：url -> 字节数组 / 'boom'（网络异常）/ 未列出则 404
function fakeFetch(plan) {
  const calls = [];
  const fn = async (url, init) => {
    calls.push({ url: url, init: init || null });
    const hit = plan[url];
    if (hit === 'boom') throw new Error('network down');
    if (!hit) return { ok: false, status: 404, arrayBuffer: async () => new ArrayBuffer(0) };
    return { ok: true, status: 200, arrayBuffer: async () => new Uint8Array(hit).buffer };
  };
  fn.calls = calls;
  return fn;
}

function rawAtt(fields) { return JSON.stringify(fields); }

async function main() {
  // ---------- 1) parseAttachment ----------
  {
    const a = parseAttachment(rawAtt({ content_type: 'image/png', filename: 'shot.PNG', size: 1234, width: 800, height: 600, url: 'https://cdn.example/a.png' }));
    eq('解析 JSON 字符串 content_type', a.contentType, 'image/png');
    eq('解析 filename', a.filename, 'shot.PNG');
    eq('解析 url', a.url, 'https://cdn.example/a.png');
    eq('解析 size 数字', a.size, 1234);
    eq('解析 width/height', a.width === 800 && a.height === 600, true);
    eq('kind 归 image', a.kind, 'image');

    const obj = parseAttachment({ content_type: 'audio/silk', url: 'https://cdn.example/v.silk' });
    eq('也接受已经是对象的', obj.kind, 'voice');

    const voice = parseAttachment(rawAtt({ content_type: 'audio/wav', voice_wav_url: 'https://cdn.example/v.wav' }));
    eq('voice_wav_url 兜底', voice.url, 'https://cdn.example/v.wav');

    const noUrl = parseAttachment(rawAtt({ content_type: 'image/jpeg', filename: 'x.jpg' }));
    eq('只有类型没有 url 也算一条', noUrl !== null && noUrl.url === null, true);

    eq('空字符串 -> null', parseAttachment('   '), null);
    eq('坏 JSON -> null', parseAttachment('{oops'), null);
    eq('纯数字 -> null', parseAttachment(12345), null);
    eq('null -> null', parseAttachment(null), null);
    eq('无类型无 url -> null', parseAttachment(rawAtt({ filename: 'x' })), null);
    eq('size 非法 -> null 字段', parseAttachment(rawAtt({ content_type: 'image/png', url: 'u', size: -5 })).size, null);
  }

  // ---------- 2) parseAttachments / kindOf ----------
  {
    const list = parseAttachments([
      rawAtt({ content_type: 'image/png', url: 'u1' }),
      'not json',
      rawAtt({ content_type: 'application/pdf', url: 'u2', filename: 'a.pdf' }),
      null,
      rawAtt({ content_type: 'video/mp4', url: 'u3' }),
    ]);
    eq('列表长度过滤掉坏项', list.length, 3);
    eq('顺序保持', list[0].kind + ',' + list[1].kind + ',' + list[2].kind, 'image,file,video');
    eq('非数组 -> 空', parseAttachments('x').length, 0);
    eq('undefined -> 空', parseAttachments(undefined).length, 0);
    eq('kindOf image', kindOf('IMAGE/JPEG'), 'image');
    eq('kindOf voice', kindOf('audio/amr'), 'voice');
    eq('kindOf video', kindOf('video/mp4'), 'video');
    eq('kindOf file', kindOf('application/zip'), 'file');
    eq('kindOf 空', kindOf(''), 'unknown');
    eq('kindOf null', kindOf(null), 'unknown');
  }

  // ---------- 3) safeName ----------
  {
    eq('剥掉正斜杠目录', safeName('/tmp/a/b.png', 'image/png', 0), 'b_1.png');
    eq('剥掉反斜杠目录', safeName('C:\\Users\\x\\shot.jpg', 'image/jpeg', 0), 'shot_1.jpg');
    eq('非法字符换下划线', safeName('a<b>c:d"e|f?g*h.png', 'image/png', 0), 'a_b_c_d_e_f_g_h_1.png');
    eq('空格折成下划线', safeName('my shot.png', 'image/png', 0), 'my_shot_1.png');
    eq('控制字符删掉', safeName('a\u0001b\u007fc.png', 'image/png', 0), 'abc_1.png');
    eq('没扩展名时按类型补', safeName('blob', 'image/jpeg', 0), 'blob_1.jpg');
    eq('无名时兜底 attachment', safeName('', 'application/pdf', 0), 'attachment_1.pdf');
    eq('路径全是目录时兜底', safeName('a/b/c/', 'image/png', 0), 'attachment_1.png');
    eq('长名字截到 60', safeName('z'.repeat(90) + '.png', 'image/png', 0), 'z'.repeat(60) + '_1.png');
    eq('序号从 1 起', safeName('a.png', 'image/png', 4), 'a_5.png');
    eq('不传序号就不加', safeName('a.png', 'image/png'), 'a.png');
    const cn = safeName('图片.png', 'image/png', 0);
    eq('中文名保留', cn, '图片_1.png');
  }

  // ---------- 4) createMediaStore.saveAll ----------
  {
    const dir = path.join(tmpRoot, 'save1');
    const fetchImpl = fakeFetch({
      'https://cdn.example/a.png': [1, 2, 3, 4],
      'https://cdn.example/b.pdf': [9, 9],
      'https://cdn.example/boom.png': 'boom',
    });
    const store = createMediaStore({ dir: dir, fetchImpl: fetchImpl, now: () => new Date(2026, 9, 3, 1, 2, 3, 4) });
    const atts = [
      { contentType: 'image/png', filename: 'a.png', url: 'https://cdn.example/a.png', kind: 'image', width: 10, height: 20 },
      { contentType: 'application/pdf', filename: 'b.pdf', url: 'https://cdn.example/b.pdf', kind: 'file' },
      { contentType: 'image/png', filename: 'missing.png', url: 'https://cdn.example/nope.png', kind: 'image' },
      { contentType: 'image/png', filename: 'boom.png', url: 'https://cdn.example/boom.png', kind: 'image' },
      { contentType: 'image/png', filename: 'no-url.png', kind: 'image' },
    ];
    const res = await store.saveAll(atts);
    eq('结果条数与附件数一致', res.length, 5);
    eq('第一张成功', res[0].ok, true);
    eq('落盘字节数', res[0].bytes, 4);
    eq('文件真的存在', fs.existsSync(res[0].path), true);
    eq('文件内容一致', Buffer.from(fs.readFileSync(res[0].path)).toString('hex'), '01020304');
    ok('文件名带时间戳与前缀序号', /20261003-010203-004-/.test(path.basename(res[0].path)), path.basename(res[0].path));
    eq('返回的 contentType 透传', res[0].contentType, 'image/png');
    eq('返回宽高透传', res[0].width + 'x' + res[0].height, '10x20');
    eq('pdf 也存下来', res[1].ok, true);
    eq('404 判失败', res[2].ok, false);
    eq('404 reason', res[2].reason, 'http-404');
    eq('网络异常判失败', res[3].ok, false);
    ok('网络异常 reason 带前缀', /^fetch: /.test(res[3].reason), res[3].reason);
    eq('没有 url 的跳过', res[4].ok, false);
    eq('没有 url 的 reason', res[4].reason, 'no-url');
    eq('saved 计数', store.stats.saved, 2);
    eq('failed 计数', store.stats.failed, 2);
    eq('skipped 计数', store.stats.skipped, 1);
    eq('bytes 累计', store.stats.bytes, 6);
    ok('state 里带目录', store.state().dir === dir, store.state().dir);
    eq('只会对真下载的发起请求', fetchImpl.calls.length, 4);
    eq('下载用 GET', fetchImpl.calls[0].init.method, 'GET');
  }

  // ---------- 5) 上限：单文件过大 / 单条消息数量 ----------
  {
    const dir = path.join(tmpRoot, 'limits');
    const fetchImpl = fakeFetch({ 'https://cdn.example/big.bin': [1, 2, 3, 4, 5], 'https://cdn.example/s.png': [7] });
    const store = createMediaStore({ dir: dir, fetchImpl: fetchImpl, maxBytes: 4, maxItems: 2 });
    const big = await store.saveOne({ contentType: 'application/octet-stream', filename: 'big.bin', url: 'https://cdn.example/big.bin', kind: 'file' });
    eq('超限判失败', big.ok, false);
    eq('超限 reason', big.reason, 'too-large');
    eq('超限报告原始大小', big.bytes, 5);
    eq('超限不落盘', fs.existsSync(dir + path.sep + String(big.path)), false);

    const many = await store.saveAll([
      { contentType: 'image/png', filename: '1.png', url: 'https://cdn.example/s.png', kind: 'image' },
      { contentType: 'image/png', filename: '2.png', url: 'https://cdn.example/s.png', kind: 'image' },
      { contentType: 'image/png', filename: '3.png', url: 'https://cdn.example/s.png', kind: 'image' },
    ], { maxItems: 2 });
    eq('超出上限仍返回等长数组', many.length, 3);
    eq('第三条 over-limit', many[2].reason, 'over-limit');
    eq('只下了两条（加上面 big.bin 那次尝试共 3 个请求）', fetchImpl.calls.length, 3);
  }

  // ---------- 6) 同名冲突 / 没有目录 ----------
  {
    const dir = path.join(tmpRoot, 'dup');
    const fetchImpl = fakeFetch({ 'https://cdn.example/same.png': [1] });
    const store = createMediaStore({ dir: dir, fetchImpl: fetchImpl, now: () => new Date(2026, 9, 3, 1, 2, 3, 5) });
    const r1 = await store.saveOne({ contentType: 'image/png', filename: 'same.png', url: 'https://cdn.example/same.png', kind: 'image' });
    const r2 = await store.saveOne({ contentType: 'image/png', filename: 'same.png', url: 'https://cdn.example/same.png', kind: 'image' });
    ok('同名两次落到不同文件', r1.path !== r2.path, r1.path + ' vs ' + r2.path);

    const noDir = createMediaStore({ fetchImpl: fetchImpl });
    const r3 = await noDir.saveAll([{ contentType: 'image/png', filename: 'x.png', url: 'https://cdn.example/same.png', kind: 'image' }]);
    eq('没配目录时不下载', r3.length, 0);
    eq('没配目录时不发请求', fetchImpl.calls.length, 2);
  }

  // ---------- 7) describeSaved ----------
  {
    const lines = describeSaved([
      { ok: true, kind: 'image', path: 'D:\\x\\a.png', bytes: 2048, contentType: 'image/png', width: 10, height: 20 },
      { ok: true, kind: 'voice', path: 'D:\\x\\v.silk', bytes: 1048576, contentType: 'audio/silk' },
      { ok: true, kind: 'file', path: 'D:\\x\\f.pdf', bytes: 300, contentType: 'application/pdf' },
      { ok: false, kind: 'image', reason: 'http-404' },
    ]);
    eq('四行', lines.length, 4);
    ok('图片行带标签与路径', lines[0].indexOf('[附件] 图片 image/png 10x20 2KB -> D:\\x\\a.png') === 0, lines[0]);
    ok('语音行', lines[1].indexOf('[附件] 语音 audio/silk 1.0MB') === 0, lines[1]);
    ok('文件行', lines[2].indexOf('[附件] 文件 application/pdf 1KB') === 0, lines[2]);
    ok('失败行说明原因', lines[3].indexOf('没能取回（http-404）') >= 0, lines[3]);
    eq('空输入 -> 空', describeSaved(null).length, 0);
  }

  const out = [];
  out.push('# qq 附件（解析/落盘）测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  out.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) out.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, out.join('\n') + '\n', 'utf8');
  console.log(out.join('\n'));
  try { fs.rmSync(tmpRoot, { recursive: true, force: true }); } catch (e) { /* 清理失败不影响结论 */ }
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
