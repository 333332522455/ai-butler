// qq/live-qq.test.mjs — 真机入口的离线自检（不连网）
// 覆盖：状态文件读取与报错、命令行/环境变量/状态文件的优先级、--check 干跑、缺凭据提示、脱敏。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import main, { loadState, resolveConfig, parseArgs, describe as describeCfg, maskSecret, DEFAULT_STATE_FILE } from '../src/live-qq.mjs';
import { DEFAULT_PORT, DEFAULT_INBOX_URL, DEFAULT_PREFIX } from '../src/serve.mjs';
import { DEFAULT_INTENTS } from '../src/qq.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-live-test.log');
const tmpState = path.join(here, '.tmp-qq-state.json');
const tmpMissing = path.join(here, '.tmp-qq-state-missing.json');
const tmpBad = path.join(here, '.tmp-qq-state-bad.json');
const tmpBom = path.join(here, '.tmp-qq-state-bom.json');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

function cleanup() {
  for (const f of [tmpState, tmpMissing, tmpBad, tmpBom]) { try { fs.unlinkSync(f); } catch (e) { /* 不在就算了 */ } }
}

async function mainTest() {
  cleanup();

  // ---------- 1) loadState ----------
  let e1 = null;
  try { loadState(tmpMissing); } catch (e) { e1 = e; }
  ok('缺文件报 state-missing', e1 !== null && e1.code === 'state-missing', e1 && String(e1.code));
  eq('报错里带路径', e1.stateFile, tmpMissing);

  fs.writeFileSync(tmpBad, '{ 这不是 JSON', 'utf8');
  let e2 = null;
  try { loadState(tmpBad); } catch (e) { e2 = e; }
  ok('坏 JSON 报 state-bad-json', e2 !== null && e2.code === 'state-bad-json', e2 && String(e2.code));

  // 带 UTF-8 BOM 的状态文件必须照样能读（PowerShell 5.1 -Encoding UTF8 / 记事本都会加 BOM）
  fs.writeFileSync(tmpBom, '\uFEFF' + JSON.stringify({ appId: 'BOM-APP', clientSecret: 'BOM-SEC' }), 'utf8');
  const stBom = loadState(tmpBom);
  eq('带 BOM 也能读到 appId', stBom.appId, 'BOM-APP');
  eq('带 BOM 也能读到 secret', stBom.clientSecret, 'BOM-SEC');

  fs.writeFileSync(tmpState, JSON.stringify({ appId: '102ABC', clientSecret: 'S3CR3T-VALUE' }), 'utf8');
  const st = loadState(tmpState);
  eq('读到 appId', st.appId, '102ABC');
  eq('读到 clientSecret', st.clientSecret, 'S3CR3T-VALUE');
  eq('带上 __file', st.__file, tmpState);

  // ---------- 2) resolveConfig 优先级 ----------
  const fromState = resolveConfig({ args: {}, state: st });
  eq('state 给 appId', fromState.appId, '102ABC');
  eq('缺省端口', fromState.port, DEFAULT_PORT);
  eq('缺省 intents', fromState.intents, DEFAULT_INTENTS);
  eq('缺省前缀', fromState.prefix, DEFAULT_PREFIX);
  eq('缺省 inbox', fromState.inboxUrl, DEFAULT_INBOX_URL);
  eq('凭据齐全 missing 为空', fromState.missing.length, 0);
  eq('缺省 stateFile 取自 __file', fromState.stateFile, tmpState);
  eq('openid 缺省为 null', fromState.openid, null);

  const fromFlag = resolveConfig({ args: { 'app-id': 'FLAG-APP', secret: 'FLAG-SEC', port: '43999', intents: '1', prefix: '[Q3] ', openid: 'OID-1' }, state: st });
  eq('命令行的 appId 赢', fromFlag.appId, 'FLAG-APP');
  eq('命令行的 secret 赢', fromFlag.clientSecret, 'FLAG-SEC');
  eq('命令行的端口赢', fromFlag.port, 43999);
  eq('命令行的 intents 赢', fromFlag.intents, 1);
  eq('命令行的前缀赢', fromFlag.prefix, '[Q3] ');
  eq('命令行的 openid 赢', fromFlag.openid, 'OID-1');

  process.env.QQ_APP_ID = 'ENV-APP';
  process.env.QQ_CLIENT_SECRET = 'ENV-SEC';
  const fromEnv = resolveConfig({ args: {}, state: st });
  eq('环境变量压过状态文件', fromEnv.appId, 'ENV-APP');
  eq('环境变量 secret', fromEnv.clientSecret, 'ENV-SEC');
  const flagOverEnv = resolveConfig({ args: { 'app-id': 'FLAG2' }, state: st });
  eq('命令行压过环境变量', flagOverEnv.appId, 'FLAG2');
  delete process.env.QQ_APP_ID;
  delete process.env.QQ_CLIENT_SECRET;

  const empty = resolveConfig({ args: {}, state: null });
  eq('什么都没有时 missing 两条', empty.missing.join(','), 'appId,clientSecret');
  eq('没有 state 时用默认状态文件路径', path.basename(empty.stateFile), 'qq.json');

  const withPort = resolveConfig({ args: {}, state: { appId: 'A', clientSecret: 'B', port: 44000, intents: 99, prefix: '[X] ', inboxUrl: 'http://127.0.0.1:1/in' } });
  eq('状态文件里的端口被采用', withPort.port, 44000);
  eq('状态文件里的 intents 被采用', withPort.intents, 99);
  eq('状态文件里的前缀被采用', withPort.prefix, '[X] ');
  eq('状态文件里的 inbox 被采用', withPort.inboxUrl, 'http://127.0.0.1:1/in');

  // ---------- 3) parseArgs / maskSecret / describe ----------
  const pa = parseArgs(['--port=1234', '--check', '--state=C:\\x\\qq.json']);
  eq('parseArgs 带等号', pa.port, '1234');
  eq('parseArgs 裸开关是 true', pa.check, true);
  eq('parseArgs 带等号状态文件', pa.state, 'C:\\x\\qq.json');
  eq('空 argv 安全', Object.keys(parseArgs([])).length, 0);

  // 空格形式（HELP 里写的就是这种）：--state <文件> / --port <n>
  const pb = parseArgs(['start', '--state', 'C:\\y\\qq.json', '--port', '43125', '--force']);
  eq('parseArgs 空格形式取到值', pb.state, 'C:\\y\\qq.json');
  eq('parseArgs 空格形式端口', pb.port, '43125');
  eq('parseArgs 末尾裸开关仍是 true', pb.force, true);
  const pc = parseArgs(['--state', '--port=1']);
  eq('parseArgs 后面跟 -- 时不吞', pc.state, true);

  eq('maskSecret 空值', maskSecret(''), '(空)');
  eq('maskSecret 短值', maskSecret('abcd'), 'a***');
  eq('maskSecret 长值', maskSecret('abcdefghij'), 'abc***ij（10 位）');
  ok('maskSecret 不泄露完整密钥', maskSecret('S3CR3T-VALUE').indexOf('S3CR3T') === -1, maskSecret('S3CR3T-VALUE'));

  const desc = describeCfg(fromState);
  ok('describe 带 appId', desc.indexOf('102ABC') >= 0);
  ok('describe 不带明文 secret', desc.indexOf('S3CR3T-VALUE') === -1, desc);
  ok('describe 提到端口', desc.indexOf(String(DEFAULT_PORT)) >= 0);
  ok('describe 提到 intents 含义', desc.indexOf('GROUP_AND_C2C_EVENT') >= 0, desc);

  // ---------- 4) 默认状态文件位置 ----------
  eq('默认状态文件名', path.basename(DEFAULT_STATE_FILE), 'qq.json');
  eq('默认状态文件在 .state 下', path.basename(path.dirname(DEFAULT_STATE_FILE)), '.state');

  // ---------- 5) main() 干跑：--check 齐全 ----------
  {
    const argvSaved = process.argv;
    const logSaved = console.log;
    const errSaved = console.error;
    const out = [];
    const errs = [];
    console.log = (...a) => { out.push(a.join(' ')); };
    console.error = (...a) => { errs.push(a.join(' ')); };
    process.argv = ['exe', path.join(here, 'live-qq.mjs'), '--state=' + tmpState, '--check'];
    process.exitCode = 0;
    try { await main(); } catch (e) { errs.push('THREW: ' + e.message); }
    finally { process.argv = argvSaved; console.log = logSaved; console.error = errSaved; }
    eq('--check 退出码 0', process.exitCode, 0);
    ok('--check 打印配置', out.join('\n').indexOf('appId') >= 0, out.join(' | '));
    ok('--check 明确说了没连网', out.join('\n').indexOf('没连网') >= 0, out.join(' | '));
    eq('--check 没有报错输出', errs.length, 0);
  }

  // ---------- 6) main() 干跑：凭据缺失 ----------
  {
    const argvSaved = process.argv;
    const logSaved = console.log;
    const errSaved = console.error;
    const errs = [];
    console.log = () => {};
    console.error = (...a) => { errs.push(a.join(' ')); };
    process.argv = ['exe', path.join(here, 'live-qq.mjs'), '--state=' + tmpMissing, '--check'];
    process.exitCode = 0;
    try { await main(); } catch (e) { errs.push('THREW: ' + e.message); }
    finally { process.argv = argvSaved; console.log = logSaved; console.error = errSaved; }
    eq('缺凭据退出码 2', process.exitCode, 2);
    ok('缺凭据解释了缺什么', /appId/.test(errs.join('\n')) && /clientSecret/.test(errs.join('\n')), errs.join(' | '));
    ok('缺凭据给了状态文件路径', errs.join('\n').indexOf(tmpMissing) >= 0, errs.join(' | '));
    ok('缺凭据给了去哪注册', errs.join('\n').indexOf('q.qq.com') >= 0, errs.join(' | '));
    process.exitCode = 0;
  }

  // ---------- 7) main() 干跑：状态文件缺失但命令行给了凭据 ----------
  {
    const argvSaved = process.argv;
    const logSaved = console.log;
    const errSaved = console.error;
    const errs = [];
    console.log = () => {};
    console.error = (...a) => { errs.push(a.join(' ')); };
    process.argv = ['exe', path.join(here, 'live-qq.mjs'), '--state=' + tmpMissing, '--app-id=FLAG-APP', '--secret=FLAG-SEC', '--check'];
    process.exitCode = 0;
    try { await main(); } catch (e) { errs.push('THREW: ' + e.message); }
    finally { process.argv = argvSaved; console.log = logSaved; console.error = errSaved; }
    eq('命令行补齐后退出码 0', process.exitCode, 0);
    eq('这条路径不该报错', errs.length, 0, errs.join(' | '));
  }

  // ---------- 8) main() 干跑：坏状态文件必须硬失败 ----------
  {
    const argvSaved = process.argv;
    const logSaved = console.log;
    const errSaved = console.error;
    const errs = [];
    console.log = () => {};
    console.error = (...a) => { errs.push(a.join(' ')); };
    process.argv = ['exe', path.join(here, 'live-qq.mjs'), '--state=' + tmpBad, '--app-id=A', '--secret=B', '--check'];
    process.exitCode = 0;
    try { await main(); } catch (e) { errs.push('THREW: ' + (e.code || e.message)); }
    finally { process.argv = argvSaved; console.log = logSaved; console.error = errSaved; }
    ok('坏 JSON 硬失败而不是静默继续', errs.join(' ').indexOf('THREW: state-bad-json') >= 0, errs.join(' | '));
    process.exitCode = 0;
  }

  cleanup();
  const lines = [];
  lines.push('# qq live 测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  if (failed.length > 0) process.exitCode = 1;
}

mainTest().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
