// qq/qq-split.test.mjs — 长文分段（splitText + send 多发）离线自检，不联网
// 覆盖：断点优先级、每段上限、段数上限与截断尾巴、不产生空段、
//       真发两条（msg_seq 递增）、stats.partsSent、split 日志、带图时图只挂第一段。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createQq, splitText, C2C_MESSAGE_CREATE, DEFAULT_INTENTS } from '../src/qq.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-split-test.log');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

function makeApi() {
  const calls = [];
  const uploads = [];
  const api = {
    calls: calls,
    uploads: uploads,
    sendC2C: async (openid, payload) => {
      calls.push({ openid: openid, payload: JSON.parse(JSON.stringify(payload)) });
      return { id: 'R' + calls.length, timestamp: 1700000000 };
    },
    sendGroup: async (groupOpenid, payload) => {
      calls.push({ groupOpenid: groupOpenid, payload: JSON.parse(JSON.stringify(payload)) });
      return { id: 'G' + calls.length, timestamp: 1700000000 };
    },
    uploadC2C: async (openid, req) => { uploads.push({ openid: openid, req: req }); return { file_info: 'FI' + uploads.length }; },
    uploadGroup: async (groupOpenid, req) => { uploads.push({ groupOpenid: groupOpenid, req: req }); return { file_info: 'FI' + uploads.length }; },
  };
  return api;
}

function makeGateway() {
  const gw = {
    start: async () => ({ connected: true, identified: false }),
    stop: () => ({ connected: false }),
    state: () => ({ connected: true, identified: false, sessionId: null, seq: null, intents: DEFAULT_INTENTS, lastError: null }),
  };
  return gw;
}

function msgEvent(id, text, openid) {
  return { id: id, content: text, author: { user_openid: openid === undefined ? 'OPENID-A' : openid }, timestamp: 1700000000000, message_type: 0 };
}

function makeQq(api, cfg) {
  const opts = Object.assign({ api: api, gateway: makeGateway(), openid: 'OID', tokenManager: { peek: () => null, getToken: async () => 'T' } }, cfg || {});
  return createQq(opts);
}

async function main() {
  // ---------- splitText 纯函数 ----------
  {
    eq('短文只一段', splitText('你好', 10, 4).parts.length, 1);
    eq('短文不算截断', splitText('你好', 10, 4).truncated, false);
    eq('正好等于上限也只一段', splitText('x'.repeat(10), 10, 4).parts.length, 1);
    eq('上限缺省是 1500', splitText('x'.repeat(2000), undefined, 4).parts[0].length, 1500);
    eq('空串给一段空', splitText('', 10, 4).parts.length, 1);
    eq('null 不炸', splitText(null, 10, 4).parts[0], '');
  }
  {
    const p = splitText('A'.repeat(50) + '\n\n' + 'B'.repeat(50), 80, 4);
    eq('空行处断开成两段', p.parts.length, 2);
    eq('第一段不含空行', p.parts[0], 'A'.repeat(50));
    eq('第二段是后半', p.parts[1], 'B'.repeat(50));
    eq('两段拼回原文', p.parts.join(''), 'A'.repeat(50) + 'B'.repeat(50));
  }
  {
    const p = splitText('甲'.repeat(30) + '。' + '乙'.repeat(30), 40, 4);
    eq('句号处断开', p.parts[0], '甲'.repeat(30) + '。');
    eq('句号断完剩一段', p.parts.length, 2);
  }
  {
    const p = splitText('x'.repeat(100), 30, 4);
    eq('没有断点就按上限硬切', p.parts.map((s) => s.length).join(','), '30,30,30,10');
    eq('硬切不算截断', p.truncated, false);
    eq('硬切不丢字', p.parts.join('').length, 100);
  }
  {
    const p = splitText('x'.repeat(100), 30, 2);
    eq('超过段数上限只发两段', p.parts.length, 2);
    eq('超出的算 dropped', p.dropped, 40);
    eq('被截断标记为 true', p.truncated, true);
    ok('最后一段补提示', /…（还有 40 字没发完）$/.test(p.parts[1]), p.parts[1]);
  }
  {
    const p = splitText('\n\n'.repeat(30) + 'z'.repeat(10), 20, 4);
    ok('不产生空段', p.parts.every((s) => s.length > 0), JSON.stringify(p.parts));
  }
  {
    const s = '第一句。\n第二段开头' + '很长的内容'.repeat(20) + '\n\n结尾';
    const p = splitText(s, 50, 4);
    ok('每段都不超上限', p.parts.every((x) => x.length <= 50), p.parts.map((x) => x.length).join(','));
    eq('非空白字符一个不丢', p.parts.join('').replace(/\s/g, ''), s.replace(/\s/g, ''));
  }

  // ---------- send 真的分多条发 ----------
  {
    const api = makeApi();
    const logs = [];
    const qq = makeQq(api, { partChars: 30, logger: (e) => logs.push(e) });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M1', 'x', 'OPENID-USER'));
    await qq.send({ text: 'y'.repeat(50) });
    eq('长文发了两条', api.calls.length, 2);
    ok('每段都不超 partChars', api.calls.every((c) => c.payload.content.length <= 30), JSON.stringify(api.calls.map((c) => c.payload.content.length)));
    eq('第一段 msg_seq=1', api.calls[0].payload.msg_seq, 1);
    eq('第二段 msg_seq=2', api.calls[1].payload.msg_seq, 2);
    eq('第一段带 msg_id', api.calls[0].payload.msg_id, 'M1');
    eq('第二段也带 msg_id', api.calls[1].payload.msg_id, 'M1');
    eq('两段都是被动回复统计', qq.stats.passiveReplies, 2);
    eq('partsSent 计数', qq.stats.partsSent, 2);
    eq('sendOk 计数', qq.stats.sendOk, 2);
    ok('有 split 日志', logs.some((e) => e.kind === 'split' && e.parts === 2), JSON.stringify(logs.map((e) => e.kind)));
    ok('每条 send 日志带分段号', logs.filter((e) => e.kind === 'send').map((e) => e.part + '/' + e.parts).join(',') === '1/2,2/2', JSON.stringify(logs.filter((e) => e.kind === 'send')));
  }
  {
    const api = makeApi();
    const qq = makeQq(api, { partChars: 20 });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M2', 'x', 'OPENID-USER'));
    await qq.send({ text: '短句' });
    eq('短文还是一条', api.calls.length, 1);
    eq('短文不动 partsSent', qq.stats.partsSent, 0);
    eq('短文内容原样', api.calls[0].payload.content, '短句');
  }
  {
    const api = makeApi();
    const qq = makeQq(api, { maxContentChars: 5, splitLongText: false });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M3', 'x', 'OPENID-USER'));
    await qq.send({ text: 'abcdefghij' });
    eq('关掉分段就是老行为', api.calls.length, 1);
    eq('老行为补截断尾巴', api.calls[0].payload.content, 'abcde…（已截断）');
  }
  {
    const api = makeApi();
    const logs = [];
    const qq = makeQq(api, { partChars: 20, maxParts: 2, logger: (e) => logs.push(e) });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M4', 'x', 'OPENID-USER'));
    await qq.send({ text: 'z'.repeat(100) });
    eq('段数封顶两条', api.calls.length, 2);
    ok('末段带没发完提示', /…（还有 60 字没发完）$/.test(api.calls[1].payload.content), api.calls[1].payload.content);
    eq('splitTruncated 计数', qq.stats.splitTruncated, 1);
    ok('有 split-truncated 日志', logs.some((e) => e.kind === 'split-truncated' && e.dropped === 60), JSON.stringify(logs.map((e) => e.kind)));
  }
  {
    const api = makeApi();
    const qq = makeQq(api, { partChars: 30 });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M5', 'x', 'OPENID-USER'));
    await qq.send({ text: 'w'.repeat(50), media: { data: 'QUJD', fileName: 'a.png' } });
    eq('带图只上传一次', api.uploads.length, 1);
    eq('带图仍发两条', api.calls.length, 2);
    eq('图挂在第一段', api.calls[0].payload.media.file_info, 'FI1');
    ok('第二段不带图', api.calls[1].payload.media === undefined);
    ok('第二段是纯文字', api.calls[1].payload.content.length > 0);
  }
  {
    const api = makeApi();
    const qq = makeQq(api, { partChars: 20 });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M6', 'x', 'OPENID-USER'));
    await qq.send({ media: { data: 'QUJD', fileName: 'a.png' } });
    eq('只发图还是两条里的第一条逻辑', api.calls.length, 1);
    eq('只发图上传一次', api.uploads.length, 1);
    ok('只发图没有 content', api.calls[0].payload.content === undefined);
  }
  {
    const api = makeApi();
    const qq = makeQq(api, { partChars: 20 });
    await qq.handleEvent(C2C_MESSAGE_CREATE, msgEvent('M7', 'x', 'OPENID-USER'));
    let e1 = null;
    try { await qq.send({ text: '   ' }); } catch (e) { e1 = e; }
    ok('全空白仍然报 text 为空', e1 !== null && /text 为空/.test(e1.message), e1 && e1.message);
    eq('报错时不发消息', api.calls.length, 0);
  }

  const lines = [];
  lines.push('# qq 分段测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
