// qq/qq-ws.test.mjs — WebSocket 网关协议离线自检（假 WebSocket + 假定时器，不联网）
// 覆盖：op10 Hello -> op2 Identify、心跳 op1/op11、READY 记录 session_id、op6 Resume 重连、
//       op9 Invalid Session 重新 Identify、op7 Reconnect、stop() 不再自动重连。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createGatewaySocket, OP } from '../src/qq-ws.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-ws-test.log');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }
const flush = async () => { for (let i = 0; i < 5; i += 1) await Promise.resolve(); };

class FakeSocket {
  constructor(url) {
    this.url = url;
    this.sent = [];
    this.closed = null;
    this.onopen = null;
    this.onmessage = null;
    this.onclose = null;
    this.onerror = null;
    FakeSocket.instances.push(this);
  }
  send(s) { this.sent.push(JSON.parse(String(s))); }
  close(code, reason) { this.closed = { code, reason }; if (this.onclose) this.onclose({ code, reason }); }
  fireOpen() { if (this.onopen) this.onopen(); }
  fireMessage(obj) { if (this.onmessage) this.onmessage({ data: typeof obj === 'string' ? obj : JSON.stringify(obj) }); }
  fireClose(code, reason) { if (this.onclose) this.onclose({ code, reason }); }
  last() { return this.sent[this.sent.length - 1]; }
  ops() { return this.sent.map((p) => p.op); }
}
FakeSocket.instances = [];

function makeClock() {
  const timers = [];
  const intervals = [];
  return {
    timers, intervals,
    setTimeoutImpl: (fn, ms) => { const h = { fn, ms, id: timers.length + 1, cleared: false }; timers.push(h); return h.id; },
    clearTimeoutImpl: (id) => { const t = timers.find((x) => x.id === id); if (t) t.cleared = true; },
    setIntervalImpl: (fn, ms) => { const h = { fn, ms, id: intervals.length + 1, cleared: false }; intervals.push(h); return h.id; },
    clearIntervalImpl: (id) => { const t = intervals.find((x) => x.id === id); if (t) t.cleared = true; },
    pendingTimer: () => timers.filter((t) => !t.cleared).slice(-1)[0] || null,
  };
}

async function main() {
  // ---------- 1) 基本握手 ----------
  FakeSocket.instances = [];
  const clock = makeClock();
  const events = [];
  const states = [];
  let tokenValue = 'TOK1';
  const gw = createGatewaySocket({
    WebSocketImpl: FakeSocket,
    url: 'wss://api.bot.qq.com/websocket/',
    getToken: async () => tokenValue,
    intents: 33554432,
    onEvent: (t, d) => events.push({ t, d }),
    onState: (kind, detail) => states.push({ kind, detail }),
    setTimeoutImpl: clock.setTimeoutImpl,
    clearTimeoutImpl: clock.clearTimeoutImpl,
    setIntervalImpl: clock.setIntervalImpl,
    clearIntervalImpl: clock.clearIntervalImpl,
  });

  await gw.start();
  eq('建了 1 个连接', FakeSocket.instances.length, 1);
  const s0 = FakeSocket.instances[0];
  eq('连接地址', s0.url, 'wss://api.bot.qq.com/websocket/');
  s0.fireOpen();
  eq('open 后 connected', gw.state().connected, true);

  s0.fireMessage({ op: OP.HELLO, d: { heartbeat_interval: 45000 } });
  await flush();
  eq('Hello 后发 Identify', s0.ops()[0], OP.IDENTIFY);
  eq('Identify token 头是 QQBot ', s0.sent[0].d.token, 'QQBot TOK1');
  eq('Identify intents 透传', s0.sent[0].d.intents, 33554432);
  eq('Identify shard 默认 [0,1]', JSON.stringify(s0.sent[0].d.shard), '[0,1]');
  ok('Identify 带 properties', s0.sent[0].d.properties !== undefined, JSON.stringify(s0.sent[0].d));
  eq('心跳间隔按 0.9 打点', clock.intervals[0].ms, 40500);
  eq('统计 identifies', gw.stats.identifies, 1);

  // 心跳：seq 为 null 时也允许（官方文档：首次传 null）
  const s0hb = s0.last();
  clock.intervals[0].fn();
  eq('心跳 op1', s0.last().op, OP.HEARTBEAT);
  eq('首次心跳 d 为 null', s0.last().d, null);
  eq('心跳计数', gw.stats.heartbeats, 1);

  s0.fireMessage({ op: OP.HEARTBEAT_ACK });
  eq('ACK 计数', gw.stats.acks, 1);

  // READY：记录 session_id，并把事件往外抛
  s0.fireMessage({ op: OP.DISPATCH, s: 7, t: 'READY', d: { session_id: 'SESS-1', user: { id: '615', username: 'bot', bot: true } } });
  eq('READY 后 identified', gw.state().identified, true);
  eq('READY 记录 session_id', gw.state().sessionId, 'SESS-1');
  eq('READY 记录 seq', gw.state().seq, 7);
  eq('READY 事件外抛', events[0].t, 'READY');
  ok('readyAt 有值', typeof gw.state().readyAt === 'string', String(gw.state().readyAt));

  // 业务事件（C2C_MESSAGE_CREATE）外抛，且 seq 更新
  s0.fireMessage({ op: OP.DISPATCH, s: 9, t: 'C2C_MESSAGE_CREATE', d: { id: 'M1', content: 'hi' } });
  eq('业务事件外抛', events[1].t, 'C2C_MESSAGE_CREATE');
  eq('seq 更新到 9', gw.state().seq, 9);
  clock.intervals[0].fn();
  eq('心跳带最新 seq', s0.last().d, 9);

  // ---------- 2) 断线重连走 Resume ----------
  s0.fireClose(1006, 'net-down');
  eq('close 后 connected=false', gw.state().connected, false);
  eq('close 计数', gw.stats.closes, 1);
  const t1 = clock.pendingTimer();
  ok('安排了重连定时器', t1 !== null, JSON.stringify(clock.timers));
  eq('首次重连退避 1000ms', t1.ms, 1000);
  t1.fn();
  await flush();
  eq('重连建新连接', FakeSocket.instances.length, 2);
  const s1 = FakeSocket.instances[1];
  s1.fireOpen();
  s1.fireMessage({ op: OP.HELLO, d: { heartbeat_interval: 45000 } });
  await flush();
  eq('重连发 op6 Resume', s1.ops()[0], OP.RESUME);
  eq('Resume 带 session_id', s1.sent[0].d.session_id, 'SESS-1');
  eq('Resume 带 seq', s1.sent[0].d.seq, 9);
  eq('Resume token 头', s1.sent[0].d.token, 'QQBot TOK1');
  eq('统计 resumes', gw.stats.resumes, 1);

  // RESUMED 事件
  s1.fireMessage({ op: OP.DISPATCH, s: 10, t: 'RESUMED', d: {} });
  eq('RESUMED 后 identified', gw.state().identified, true);
  eq('RESUMED 外抛', events[2].t, 'RESUMED');

  // ---------- 3) op9 Invalid Session：丢 session，下次 Identify ----------
  s1.fireMessage({ op: OP.INVALID_SESSION, d: {} });
  eq('session 清空', gw.state().sessionId, null);
  eq('seq 清空', gw.state().seq, null);
  const t2 = clock.pendingTimer();
  t2.fn();
  await flush();
  const s2 = FakeSocket.instances[2];
  s2.fireOpen();
  s2.fireMessage({ op: OP.HELLO, d: { heartbeat_interval: 30000 } });
  await flush();
  eq('失效后重新 Identify', s2.ops()[0], OP.IDENTIFY);
  eq('identifies 计数到 2', gw.stats.identifies, 2);
  eq('心跳间隔跟着新 Hello', clock.intervals.filter((x) => !x.cleared).slice(-1)[0].ms, 27000);

  // ---------- 4) op7 要求重连 ----------
  s2.fireMessage({ op: OP.RECONNECT, d: {} });
  ok('op7 触发 close', s2.closed !== null, JSON.stringify(s2.closed));
  eq('op7 close 码', s2.closed.code, 4000);

  // ---------- 5) token 变化会带到下一次鉴权 ----------
  tokenValue = 'TOK2';
  const t3 = clock.pendingTimer();
  t3.fn();
  await flush();
  const s3 = FakeSocket.instances[3];
  s3.fireOpen();
  s3.fireMessage({ op: OP.HELLO, d: { heartbeat_interval: 45000 } });
  await flush();
  ok('新 token 生效', s3.sent[0].d.token === 'QQBot TOK2', s3.sent[0].d.token);

  // 坏 JSON 不炸
  s3.fireMessage('这不是 JSON');
  ok('坏 JSON 记 lastError', /bad-json/.test(String(gw.state().lastError)), String(gw.state().lastError));

  // ---------- 6) stop() 之后不再重连 ----------
  gw.stop();
  ok('stop 关掉连接', s3.closed !== null, JSON.stringify(s3.closed));
  const before = FakeSocket.instances.length;
  s3.fireClose(1000, 'stop');
  eq('stop 后不再新建连接', FakeSocket.instances.length, before);

  // ---------- 7) getGatewayUrl 路径（不传 url） ----------
  FakeSocket.instances = [];
  const clock2 = makeClock();
  let gwCalls = 0;
  const gw2 = createGatewaySocket({
    WebSocketImpl: FakeSocket,
    getGatewayUrl: async () => { gwCalls += 1; return { url: 'wss://api.bot.qq.com/websocket/' }; },
    getToken: async () => 'T',
    setTimeoutImpl: clock2.setTimeoutImpl,
    clearTimeoutImpl: clock2.clearTimeoutImpl,
    setIntervalImpl: clock2.setIntervalImpl,
    clearIntervalImpl: clock2.clearIntervalImpl,
  });
  await gw2.start();
  eq('没给 url 就调 /gateway', gwCalls, 1);
  eq('用了返回的地址', FakeSocket.instances[0].url, 'wss://api.bot.qq.com/websocket/');
  gw2.stop();

  // 不传实现时用全局 WebSocket（本运行时 Node 24 自带，Electron-as-Node 也有）
  ok('本运行时存在全局 WebSocket', typeof globalThis.WebSocket === 'function', typeof globalThis.WebSocket);
  const gwDefault = createGatewaySocket({ getToken: async () => 'T', autoReconnect: false });
  ok('缺省用全局 WebSocket 不抛错', typeof gwDefault.start === 'function');
  let err = null;
  const stash = globalThis.WebSocket;
  try {
    globalThis.WebSocket = undefined;
    try { createGatewaySocket({ getToken: async () => 'T' }); } catch (e) { err = e; }
  } finally { globalThis.WebSocket = stash; }
  ok('既没给实现也没有全局时抛错', err !== null && /no-WebSocket-implementation/.test(err.message), err && err.message);

  // ---------- 8) 拿不到 token 也必须自愈（2026-10-20 QQ 桥假活的根因） ----------
  FakeSocket.instances = [];
  const clock3 = makeClock();
  let tokenBroken = true;
  const states3 = [];
  const gw3 = createGatewaySocket({
    WebSocketImpl: FakeSocket,
    url: 'wss://api.bot.qq.com/websocket/',
    getToken: async () => {
      if (tokenBroken) throw new Error('token-fetch: fetch failed');
      return 'TOK-NET-BACK';
    },
    onState: (kind) => states3.push(kind),
    setTimeoutImpl: clock3.setTimeoutImpl,
    clearTimeoutImpl: clock3.clearTimeoutImpl,
    setIntervalImpl: clock3.setIntervalImpl,
    clearIntervalImpl: clock3.clearIntervalImpl,
  });
  await gw3.start();
  const f0 = FakeSocket.instances[0];
  f0.fireOpen();
  f0.fireMessage({ op: OP.HELLO, d: { heartbeat_interval: 45000 } });
  await flush();
  ok('token 失败记 auth-failed', states3.indexOf('auth-failed') !== -1, states3.join(','));
  ok('token 失败主动关连接', f0.closed !== null && f0.closed.code === 4002, JSON.stringify(f0.closed));
  ok('token 失败后有重连定时器', clock3.pendingTimer() !== null, JSON.stringify(clock3.timers));
  tokenBroken = false;
  clock3.pendingTimer().fn();
  await flush();
  eq('token 恢复后建了新连接', FakeSocket.instances.length, 2);
  const f1 = FakeSocket.instances[1];
  f1.fireOpen();
  f1.fireMessage({ op: OP.HELLO, d: { heartbeat_interval: 45000 } });
  await flush();
  ok('网络恢复后重新 Identify', f1.sent[0] !== undefined && f1.sent[0].op === OP.IDENTIFY, JSON.stringify(f1.sent[0] || null));
  ok('用的是新拿到的 token', f1.sent[0] !== undefined && f1.sent[0].d.token === 'QQBot TOK-NET-BACK', f1.sent[0] && f1.sent[0].d.token);
  gw3.stop();

  // ---------- 9) 心跳连发没人 ACK -> 判假活并重连 ----------
  FakeSocket.instances = [];
  const clock4 = makeClock();
  const states4 = [];
  const gw4 = createGatewaySocket({
    WebSocketImpl: FakeSocket,
    url: 'wss://api.bot.qq.com/websocket/',
    getToken: async () => 'T',
    onState: (kind) => states4.push(kind),
    setTimeoutImpl: clock4.setTimeoutImpl,
    clearTimeoutImpl: clock4.clearTimeoutImpl,
    setIntervalImpl: clock4.setIntervalImpl,
    clearIntervalImpl: clock4.clearIntervalImpl,
  });
  await gw4.start();
  const g0 = FakeSocket.instances[0];
  g0.fireOpen();
  g0.fireMessage({ op: OP.HELLO, d: { heartbeat_interval: 45000 } });
  await flush();
  g0.fireMessage({ op: OP.DISPATCH, s: 1, t: 'READY', d: { session_id: 'S-X' } });
  const iv4 = clock4.intervals.slice(-1)[0];
  for (let i = 0; i < 4; i += 1) iv4.fn();
  ok('连续 3 次心跳没 ACK 后判 stall', states4.indexOf('heartbeat-stall') !== -1, states4.join(','));
  ok('stall 后主动关连接', g0.closed !== null && g0.closed.code === 4003, JSON.stringify(g0.closed));
  ok('stall 后安排了重连', clock4.pendingTimer() !== null, JSON.stringify(clock4.timers));
  gw4.stop();

  const lines = [];
  lines.push('# qq-ws 测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
