// qq/serve.test.mjs — QQ 腿 HTTP 服务离线自检（假 client + 假 fetch，不联网）
// 覆盖：/status、/、/send（text|typing|原始文本|错码）、/inject 入站转发与失败路径、journal、413/405/404、configFromArgs、stop。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import { createServe, configFromArgs, DEFAULT_PORT, DEFAULT_PREFIX, DEFAULT_INBOX_URL } from '../src/serve.mjs';
import { createMediaStore } from '../src/qq-media.mjs';
import { tempBase } from './_tmp.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-serve-test.log');
const journalFile = path.join(here, '.tmp-serve-journal.jsonl');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

function makeClient(opts) {
  const o = opts || {};
  const sent = [];
  const typings = [];
  const handlers = [];
  const seenIds = new Set();
  let started = 0;
  let stopped = 0;
  const st = {
    ready: o.ready === true, connected: o.ready === true, lastOpenid: o.lastOpenid || null,
    lastMessage: o.lastMessage || null, recent: o.recent || [], lastError: null,
    activePush: o.activePush === undefined ? 'on' : o.activePush,
    activePushLabel: o.activePush === undefined || o.activePush === 'on' ? '可用' : (o.activePush === 'off' ? '已关闭' : '未知（还没收到过开关事件）'),
    activePushAt: '2026-10-03T00:28:07.000Z',
    stats: { received: 0 }, gateway: { stats: { connects: 1 } }, token: o.token === undefined ? 'TK' : o.token,
  };
  return {
    sent: sent, typings: typings, handlers: handlers,
    start: async () => { started += 1; return { connected: true }; },
    stop: () => { stopped += 1; },
    starts: () => started, stops: () => stopped,
    send: async (m) => { if (o.sendFails) throw new Error('send boom'); sent.push(m.text); return { id: 'R' + sent.length }; },
    typing: async () => { if (o.typingFails) throw new Error('typing boom'); typings.push(1); return { ok: true }; },
    onMessage: (h) => { handlers.push(h); return () => { handlers.splice(handlers.indexOf(h), 1); }; },
    handleEvent: async (t, d) => {
      // 和真客户端一样：同一个 msg_id 重复推送要去重
      if (seenIds.has(d.id)) return null;
      seenIds.add(d.id);
      const m = { text: d.content, from: d.author && d.author.user_openid ? d.author.user_openid : null, messageId: d.id };
      for (const h of handlers) await h(m);
      return m;
    },
    state: () => st,
  };
}

function makeFetch(mode) {
  const calls = [];
  const f = async (url, init) => {
    calls.push({ url: url, init: init, body: JSON.parse(init.body) });
    if (mode === 'throw') throw new Error('econnrefused');
    if (mode === 'http500') return { ok: false, status: 500, json: async () => ({ ok: false }) };
    return { ok: true, status: 202, json: async () => ({ ok: true, requestId: 'REQ-' + calls.length }) };
  };
  f.calls = calls;
  return f;
}

function req(port, method, pathname, body) {
  return new Promise((resolve, reject) => {
    const r = http.request({ host: '127.0.0.1', port: port, method: method, path: pathname, headers: { 'content-type': 'application/json' } }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString('utf8') }));
    });
    r.on('error', reject);
    if (body !== undefined) r.write(typeof body === 'string' ? body : JSON.stringify(body));
    r.end();
  });
}

async function boot(over) {
  const o = over || {};
  const client = o.client || makeClient(o.clientOpts);
  const fake = o.fetch || makeFetch('ok');
  const serve = createServe({
    client: client,
    port: 0,
    host: '127.0.0.1',
    fetchImpl: fake,
    inboxUrl: o.inboxUrl || DEFAULT_INBOX_URL,
    prefix: o.prefix === undefined ? DEFAULT_PREFIX : o.prefix,
    journalFile: o.journalFile === undefined ? null : o.journalFile,
    maxBodyBytes: o.maxBodyBytes,
    allowInject: o.allowInject,
    mediaStore: o.mediaStore || null,
    logger: null,
  });
  const addr = await serve.start({ connect: false });
  return { serve: serve, client: client, fetch: fake, port: addr.port };
}

async function main() {
  try { fs.unlinkSync(journalFile); } catch (e) { /* 不存在就算了 */ }

  // ---------- 1) 基本路由 ----------
  {
    const b = await boot({ journalFile: journalFile });
    const s = await req(b.port, 'GET', '/status');
    eq('/status 200', s.status, 200);
    const j = JSON.parse(s.text);
    eq('/status ok', j.ok, true);
    eq('/status channel', j.channel, 'qq');
    eq('/status prefix', j.prefix, DEFAULT_PREFIX);
    eq('/status inboxUrl', j.inboxUrl, DEFAULT_INBOX_URL);
    eq('/status token 透传', j.token, 'TK');
    ok('/status 带 stats', j.stats && typeof j.stats.forwards === 'number', JSON.stringify(j.stats));
    ok('/status 端口是非 0 实际端口', j.port > 0 && j.port === b.port, String(j.port));
    eq('/status content-type', /application\/json/.test(s.headers['content-type']), true);

    const root = await req(b.port, 'GET', '/');
    eq('/ 200', root.status, 200);
    ok('/ 是 HTML', /text\/html/.test(root.headers['content-type']), root.headers['content-type']);
    ok('/ 提到接口', root.text.indexOf('GET /status') >= 0);
    ok('/ 提到未连接', root.text.indexOf('未连接') >= 0);
    eq('/status activePush', j.activePush, 'on');
    eq('/status activePushLabel', j.activePushLabel, '可用');
    eq('/status activePushAt', j.activePushAt, '2026-10-03T00:28:07.000Z');
    ok('/ 显示主动消息可用', root.text.indexOf('主动消息：<b>可用</b>') >= 0, root.text);

    const nf = await req(b.port, 'GET', '/nope');
    eq('/nope 404', nf.status, 404);
    const nfj = JSON.parse(nf.text);
    eq('404 routes 列表', nfj.routes.length, 4);

    // 幂等 start
    const addr2 = await b.serve.start({ connect: false });
    eq('重复 start 返回同一端口', addr2.port, b.port);

    await b.serve.stop();
  }

  // ---------- 2) /send ----------
  {
    const c = makeClient({});
    const b = await boot({ client: c, journalFile: journalFile });

    const r1 = await req(b.port, 'POST', '/send', { text: '你好呀' });
    eq('/send 200', r1.status, 200);
    const j1 = JSON.parse(r1.text);
    eq('/send ok', j1.ok, true);
    eq('/send chars 是字数', j1.chars, 3);
    eq('/send 传给 client', c.sent[0], '你好呀');
    ok('/send 带 raw 返回', j1.raw && j1.raw.id === 'R1', JSON.stringify(j1.raw));

    const r2 = await req(b.port, 'POST', '/send', { typing: true, requestId: 'RQ-9' });
    eq('typing 200', r2.status, 200);
    eq('typing ok', JSON.parse(r2.text).typing, true);
    eq('typing 传到 client', c.typings.length, 1);

    const r3 = await req(b.port, 'POST', '/send', {});
    eq('空 text 400', r3.status, 400);
    eq('空 text 原因', JSON.parse(r3.text).reason, 'text 为空');
    const r4 = await req(b.port, 'POST', '/send', { text: '   ' });
    eq('空白 text 400', r4.status, 400);

    // 非 JSON 原文当 text 用（和 ilink 腿一致的宽容）
    const r5 = await req(b.port, 'POST', '/send', 'raw-text');
    eq('裸文本 200', r5.status, 200);
    eq('裸文本当 text', c.sent[c.sent.length - 1], 'raw-text');

    const g = await req(b.port, 'GET', '/send');
    eq('GET /send 405', g.status, 405);
    const gi = await req(b.port, 'GET', '/inject');
    eq('GET /inject 405', gi.status, 405);

    await b.serve.stop();
  }

  // ---------- 3) /send 失败路径 ----------
  {
    const c = makeClient({ sendFails: true, typingFails: true });
    const b = await boot({ client: c });
    const r1 = await req(b.port, 'POST', '/send', { text: 'x' });
    eq('send 失败 502', r1.status, 502);
    eq('send 失败带原因', JSON.parse(r1.text).reason, 'send boom');
    const r2 = await req(b.port, 'POST', '/send', { typing: true });
    eq('typing 失败 502', r2.status, 502);
    eq('typing 失败原因', JSON.parse(r2.text).reason, 'typing boom');
    eq('stats.sendFailed', b.serve.stats.sendFailed, 1);
    eq('stats.typingFailed', b.serve.stats.typingFailed, 1);
    await b.serve.stop();
  }

  // ---------- 4) /inject 入站 -> 桥 inbox ----------
  {
    const b = await boot({ journalFile: journalFile });
    const r = await req(b.port, 'POST', '/inject', { id: 'INJ-1', text: 'ping', openid: 'OPENID-X' });
    eq('/inject 200', r.status, 200);
    const j = JSON.parse(r.text);
    eq('/inject injected', j.injected, true);
    eq('/inject 回 messageId', j.messageId, 'INJ-1');
    eq('转发了一次', b.fetch.calls.length, 1);
    eq('转发目标 inboxUrl', b.fetch.calls[0].url, DEFAULT_INBOX_URL);
    eq('转发带前缀', b.fetch.calls[0].body.text, '[QQ] ping');
    eq('转发带 from', b.fetch.calls[0].body.from, 'OPENID-X');
    eq('转发带 messageId', b.fetch.calls[0].body.messageId, 'INJ-1');
    eq('转发带 channel', b.fetch.calls[0].body.channel, 'qq');
    eq('转发是 POST', b.fetch.calls[0].init.method, 'POST');
    eq('stats.forwards', b.serve.stats.forwards, 1);
    eq('stats.received', b.serve.stats.received, 1);
    eq('stats.injects', b.serve.stats.injects, 1);
    eq('status 里 lastForward.requestId', JSON.parse((await req(b.port, 'GET', '/status')).text).lastForward.requestId, 'REQ-1');
    // 缺 id 也能注入（自动生成），缺 openid 用默认
    const r2 = await req(b.port, 'POST', '/inject', { text: 'no-id' });
    eq('缺 id 也 injected', JSON.parse(r2.text).injected, true);
    ok('自动生成 messageId', /^inject-/.test(JSON.parse(r2.text).messageId), JSON.parse(r2.text).messageId);
    eq('缺 openid 用默认', b.fetch.calls[1].body.from, 'INJECT_OPENID');
    // 重复 id 去重 -> injected false
    const r3 = await req(b.port, 'POST', '/inject', { id: 'INJ-1', text: 'again', openid: 'OPENID-X' });
    eq('重复 id 去重', JSON.parse(r3.text).injected, false);
    await b.serve.stop();
  }

  // ---------- 5) 转发失败路径 ----------
  {
    const b = await boot({ fetch: makeFetch('http500') });
    await req(b.port, 'POST', '/inject', { id: 'F1', text: 'x', openid: 'O' });
    eq('inbox 500 计 forwardFailed', b.serve.stats.forwardFailed, 1);
    eq('inbox 500 不计 forwards', b.serve.stats.forwards, 0);
    const st = JSON.parse((await req(b.port, 'GET', '/status')).text);
    eq('lastForward.ok false', st.lastForward.ok, false);
    eq('lastForward.status 500', st.lastForward.status, 500);
    await b.serve.stop();
  }
  {
    const b = await boot({ fetch: makeFetch('throw') });
    await req(b.port, 'POST', '/inject', { id: 'F2', text: 'x', openid: 'O' });
    eq('网络异常计 forwardFailed', b.serve.stats.forwardFailed, 1);
    const st = JSON.parse((await req(b.port, 'GET', '/status')).text);
    ok('lastForward 记 error', /econnrefused/.test(String(st.lastForward.error)), JSON.stringify(st.lastForward));
    await b.serve.stop();
  }

  // ---------- 6) 前缀可配 + allowInject=false + 413 ----------
  {
    const b = await boot({ prefix: '[Q2] ' });
    await req(b.port, 'POST', '/inject', { id: 'P1', text: 'hi', openid: 'O' });
    eq('自定义前缀生效', b.fetch.calls[0].body.text, '[Q2] hi');
    eq('state().prefix', b.serve.state().prefix, '[Q2] ');
    await b.serve.stop();
  }
  {
    const b = await boot({ allowInject: false });
    const r = await req(b.port, 'POST', '/inject', { id: 'P2', text: 'hi' });
    eq('inject 关闭 403', r.status, 403);
    await b.serve.stop();
  }
  {
    const b = await boot({ maxBodyBytes: 8 });
    const r = await req(b.port, 'POST', '/send', { text: '这个请求体超过八个字节' });
    eq('超大 body 413', r.status, 413);
    eq('413 原因', JSON.parse(r.text).reason, 'body too large');
    await b.serve.stop();
  }

  // ---------- 7) journal ----------
  {
    try { fs.unlinkSync(journalFile); } catch (e) { /* 清干净再测 */ }
    const b = await boot({ journalFile: journalFile });
    await req(b.port, 'POST', '/send', { text: 'j1', requestId: 'RJ-1' });
    await req(b.port, 'POST', '/send', { typing: true });
    await req(b.port, 'POST', '/inject', { id: 'JI-1', text: 'j2', openid: 'OJ' });
    await b.serve.stop();
    const lines = fs.readFileSync(journalFile, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
    const kinds = lines.map((l) => l.kind);
    ok('journal 记了 send', kinds.indexOf('send') >= 0, JSON.stringify(kinds));
    ok('journal 记了 typing', kinds.indexOf('typing') >= 0, JSON.stringify(kinds));
    ok('journal 记了 incoming', kinds.indexOf('incoming') >= 0, JSON.stringify(kinds));
    ok('journal 记了 forward', kinds.indexOf('forward') >= 0, JSON.stringify(kinds));
    const fw = lines.filter((l) => l.kind === 'forward')[0];
    eq('forward 带 preview', fw.preview, 'j2');
    ok('每条带 at 时间', lines.every((l) => typeof l.at === 'string' && l.at.length > 10), 'at 缺失');
    const sd = lines.filter((l) => l.kind === 'send')[0];
    eq('send 记 requestId', sd.requestId, 'RJ-1');
  }

  // ---------- 8) stop 之后连不上 ----------
  {
    const b = await boot({});
    await b.serve.stop();
    let err = null;
    try { await req(b.port, 'GET', '/status'); } catch (e) { err = e; }
    ok('stop 后请求失败', err !== null, err && err.message);
  }

  // ---------- 9) 附件：落盘 + 路径拼进转发文本 ----------
  {
    const mediaRoot = fs.mkdtempSync(path.join(tempBase(), 'qq-serve-media-'));
    const mediaFetch = async () => ({ ok: true, status: 200, arrayBuffer: async () => new Uint8Array([1, 2, 3, 4]).buffer });
    const store = createMediaStore({ dir: mediaRoot, fetchImpl: mediaFetch, now: () => new Date(2026, 9, 3, 2, 3, 4, 5) });
    const b = await boot({ mediaStore: store });
    const msg = {
      text: '看看这张图', from: 'OPENID-A', messageId: 'MM1', channel: 'c2c',
      attachments: [
        { contentType: 'image/png', filename: 'a.png', url: 'https://cdn/a.png', kind: 'image', width: 8, height: 6 },
        { contentType: 'application/pdf', filename: 'b.pdf', url: 'https://cdn/b.pdf', kind: 'file' },
      ],
    };
    await b.client.handlers[0](msg);
    const body = b.fetch.calls[0].body;
    eq('转发前缀在最前', body.text.indexOf(DEFAULT_PREFIX), 0);
    ok('正文保留', body.text.indexOf('看看这张图') >= 0, body.text);
    ok('附件行单独成段', body.text.indexOf('\n\n[附件] 图片 image/png 8x6') >= 0, body.text);
    ok('文件附件也有行', body.text.indexOf('[附件] 文件 application/pdf') >= 0, body.text);
    eq('body 带 attachments 数组', Array.isArray(body.attachments) ? body.attachments.length : -1, 2);
    eq('attachments[0].ok', body.attachments[0].ok, true);
    eq('attachments[0].kind', body.attachments[0].kind, 'image');
    eq('attachments[0].bytes', body.attachments[0].bytes, 4);
    ok('attachments[0].path 指向真文件', fs.existsSync(body.attachments[0].path), JSON.stringify(body.attachments[0]));
    ok('body.attachments[1].path 指向真文件', fs.existsSync(body.attachments[1].path), JSON.stringify(body.attachments[1]));
    eq('serve.stats.mediaSaved', b.serve.stats.mediaSaved, 2);
    eq('serve.stats.mediaFailed', b.serve.stats.mediaFailed, 0);

    // 只有附件、没有文字：转发文本就是附件行（不能是空消息）
    await b.client.handlers[0]({ text: '', from: 'OPENID-A', messageId: 'MM2', channel: 'group', attachments: [{ contentType: 'image/png', filename: 'c.png', url: 'https://cdn/c.png', kind: 'image' }] });
    const b2 = b.fetch.calls[1].body;
    eq('没有文字时以附件行开头', b2.text.indexOf(DEFAULT_PREFIX + '[附件] 图片'), 0);
    eq('scene 仍透传', b2.scene, 'group');

    // 上游直接塞 QQ 原始形状（字符串数组）也要能落盘：serve 自己会再解析一次
    await b.client.handlers[0]({
      text: 'raw', from: 'OPENID-A', messageId: 'MM5', channel: 'c2c',
      attachments: [JSON.stringify({ content_type: 'image/png', filename: 'raw.png', url: 'https://cdn/raw.png', width: 2, height: 3 })],
    });
    const rawBody = b.fetch.calls[b.fetch.calls.length - 1].body;
    ok('原始字符串附件也能落盘', rawBody.attachments[0].ok === true, JSON.stringify(rawBody.attachments[0]));
    ok('原始字符串附件也带路径', /raw_1\.png$/.test(String(rawBody.attachments[0].path)), String(rawBody.attachments[0].path));
    ok('文本里有附件行', rawBody.text.indexOf('[附件] 图片 image/png 2x3') >= 0, rawBody.text);

    // 没配 mediaStore：不下载、不加附件行，但 body 里仍有空 attachments 数组
    const b3 = await boot({});
    await b3.client.handlers[0]({ text: 'hi', from: 'OID', messageId: 'MM3', channel: 'c2c', attachments: [{ contentType: 'image/png', url: 'https://cdn/d.png', kind: 'image' }] });
    const b3body = b3.fetch.calls[0].body;
    eq('没配 mediaStore 时文本不变', b3body.text, DEFAULT_PREFIX + 'hi');
    eq('没配 mediaStore 时 attachments 为空数组', b3body.attachments.length, 0);
    await b3.serve.stop();

    // 下载失败也不影响转发（会多一行「没能取回」）
    const failStore = createMediaStore({ dir: path.join(mediaRoot, 'fail'), fetchImpl: async () => ({ ok: false, status: 404, arrayBuffer: async () => new ArrayBuffer(0) }) });
    const b4 = await boot({ mediaStore: failStore });
    await b4.client.handlers[0]({ text: 'x', from: 'OID', messageId: 'MM4', channel: 'c2c', attachments: [{ contentType: 'image/png', url: 'https://cdn/none.png', kind: 'image' }] });
    const b4body = b4.fetch.calls[0].body;
    ok('下载失败仍转发并注明', b4body.text.indexOf('没能取回（http-404）') >= 0, b4body.text);
    eq('失败计数落到 stats', b4.serve.stats.mediaFailed, 1);
    eq('attachments[0].ok=false', b4body.attachments[0].ok, false);
    await b4.serve.stop();
    await b.serve.stop();
    try { fs.rmSync(mediaRoot, { recursive: true, force: true }); } catch (e) { /* 清理失败不影响结论 */ }
  }

  // ---------- 9b) 主动消息开关在 /status 与 / 上的三种取值 ----------
  {
    const bOff = await boot({ clientOpts: { activePush: 'off' } });
    const sOff = JSON.parse((await req(bOff.port, 'GET', '/status')).text);
    eq('off -> activePush', sOff.activePush, 'off');
    eq('off -> 标签已关闭', sOff.activePushLabel, '已关闭');
    ok('off -> / 页显示已关闭', (await req(bOff.port, 'GET', '/')).text.indexOf('主动消息：<b>已关闭</b>') >= 0);
    await bOff.serve.stop();

    const bUnk = await boot({ clientOpts: { activePush: 'unknown' } });
    const sUnk = JSON.parse((await req(bUnk.port, 'GET', '/status')).text);
    eq('unknown -> activePush', sUnk.activePush, 'unknown');
    ok('unknown -> 标签带解释', String(sUnk.activePushLabel).indexOf('未知') === 0, sUnk.activePushLabel);
    ok('unknown -> / 页有解释', (await req(bUnk.port, 'GET', '/')).text.indexOf('还没收到过开关事件') >= 0);
    await bUnk.serve.stop();
  }
  // ---------- 10) configFromArgs ----------
  {
    const cfg = configFromArgs([
      '--port=43125', '--host=0.0.0.0', '--inbox=http://127.0.0.1:9/inbox', '--prefix=[QQ2] ',
      '--journal=C:\\tmp\\x.jsonl', '--app-id=102000', '--secret=SEC', '--gateway=wss://x/', '--intents=33554432', '--state=C:\\tmp\\qq.json', 'ignored',
    ]);
    eq('cfg.port', cfg.port, 43125);
    eq('cfg.host', cfg.host, '0.0.0.0');
    eq('cfg.inboxUrl', cfg.inboxUrl, 'http://127.0.0.1:9/inbox');
    eq('cfg.prefix', cfg.prefix, '[QQ2] ');
    eq('cfg.appId', cfg.appId, '102000');
    eq('cfg.clientSecret', cfg.clientSecret, 'SEC');
    eq('cfg.gatewayUrl', cfg.gatewayUrl, 'wss://x/');
    eq('cfg.intents 是数字', cfg.intents, 33554432);
    eq('cfg.stateFile', cfg.stateFile, 'C:\\tmp\\qq.json');
    eq('空参数安全', Object.keys(configFromArgs([])).length, 0);
    eq('默认端口常量', DEFAULT_PORT, 43124);
  }

  const lines = [];
  lines.push('# qq serve 测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  try { fs.unlinkSync(journalFile); } catch (e) { /* 清理 */ }
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
