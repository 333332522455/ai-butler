// qq/qq-token.test.mjs — AccessToken 管理离线自检（零依赖，不联网）
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createTokenManager } from '../src/qq-token.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const verdictFile = path.join(here, '.last-qq-token-test.log');

let pass = 0;
const failed = [];
function ok(name, cond, extra) { if (cond) { pass += 1; return; } failed.push(name + (extra === undefined ? '' : ' | ' + extra)); }
function eq(name, a, b) { ok(name, a === b, 'got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b)); }

function jsonResponse(body, status) {
  return { ok: (status === undefined ? 200 : status) < 400, status: status === undefined ? 200 : status, json: async () => body };
}

async function main() {
  const calls = [];
  let clock = 1000000;
  const fetchImpl = async (url, init) => {
    calls.push({ url, method: init.method, headers: init.headers, body: JSON.parse(init.body) });
    return jsonResponse({ access_token: 'TOK' + calls.length, expires_in: 7200 });
  };
  const tm = createTokenManager({ appId: '102', clientSecret: 'SEC', fetchImpl, now: () => clock });

  eq('第一次 getToken 拿 TOK1', await tm.getToken(), 'TOK1');
  eq('请求地址', calls[0].url, 'https://api.bot.qq.com/app/getAppAccessToken');
  eq('请求方法', calls[0].method, 'POST');
  eq('body 带 appId', calls[0].body.appId, '102');
  eq('body 带 clientSecret', calls[0].body.clientSecret, 'SEC');

  eq('缓存期内不重取', await tm.getToken(), 'TOK1');
  eq('只请求了一次', calls.length, 1);

  // 到期前 5 分钟就刷新：expires_in 7200s，走 7201s - 4min 应已进入刷新窗口
  clock += 7200 * 1000 - 60 * 1000;
  eq('临近过期会自动换新', await tm.getToken(), 'TOK2');
  eq('共请求两次', calls.length, 2);

  // 并发只发一次请求
  tm.invalidate();
  const many = await Promise.all([tm.getToken(), tm.getToken(), tm.getToken()]);
  eq('并发三连只打一次接口', calls.length, 3);
  ok('并发结果一致', many[0] === many[1] && many[1] === many[2], JSON.stringify(many));

  // force 强制刷新
  await tm.getToken({ force: true });
  eq('force 会再请求一次', calls.length, 4);

  // 缺凭据
  const bare = createTokenManager({ fetchImpl });
  let err = null;
  try { await bare.getToken(); } catch (e) { err = e; }
  ok('缺 appId/secret 抛错', err !== null && /missing-appId-or-clientSecret/.test(err.message), err && err.message);

  // 非 200
  const bad = createTokenManager({ appId: '1', clientSecret: '2', fetchImpl: async () => jsonResponse({ err_code: 100007, message: 'appid 无效' }, 401) });
  err = null;
  try { await bad.getToken(); } catch (e) { err = e; }
  ok('HTTP 401 抛错', err !== null && /token-http 401/.test(err.message), err && err.message);
  eq('失败计数', bad.stats.failures, 1);

  // 返回体缺 access_token
  const weird = createTokenManager({ appId: '1', clientSecret: '2', fetchImpl: async () => jsonResponse({ ok: true }) });
  err = null;
  try { await weird.getToken(); } catch (e) { err = e; }
  ok('无 access_token 抛错', err !== null && /token-bad-body/.test(err.message), err && err.message);

  // 网络异常
  const broken = createTokenManager({ appId: '1', clientSecret: '2', fetchImpl: async () => { throw new Error('ECONNREFUSED'); } });
  err = null;
  try { await broken.getToken(); } catch (e) { err = e; }
  ok('网络异常包成 token-fetch', err !== null && /token-fetch: ECONNREFUSED/.test(err.message), err && err.message);

  // expires_in 缺失时按 7200 秒兜底，且仍然新鲜
  const noTtl = createTokenManager({ appId: '1', clientSecret: '2', fetchImpl: async () => jsonResponse({ access_token: 'X' }), now: () => clock });
  eq('无 expires_in 也能拿到 token', await noTtl.getToken(), 'X');
  ok('peek 显示新鲜', noTtl.peek().fresh === true, JSON.stringify(noTtl.peek()));

  const lines = [];
  lines.push('# qq-token 测试 ' + (failed.length === 0 ? 'ALL PASS' : 'FAILED'));
  lines.push('pass=' + pass + ' failed=' + failed.length);
  for (const f of failed) lines.push('FAIL: ' + f);
  fs.writeFileSync(verdictFile, lines.join('\n') + '\n', 'utf8');
  console.log(lines.join('\n'));
  if (failed.length > 0) process.exitCode = 1;
}

main().catch((e) => { console.log('TEST CRASH: ' + (e && e.stack ? e.stack : e)); process.exitCode = 1; });
