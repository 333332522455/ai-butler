// test/_tmp.mjs — 可写临时目录：优先 os.tmpdir()，真写一次探不到就退回包内 .tmp/
// 有些机器（或受限沙箱）把 TEMP 指到一个「看着有权限、实际 mkdtemp 就 EPERM」的目录，
// access() 探不出来，必须真落一个文件才算数。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const local = path.join(path.dirname(fileURLToPath(import.meta.url)), '.tmp');

function writable(dir) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    const probe = path.join(dir, '.write-probe-' + process.pid);
    fs.writeFileSync(probe, 'ok');
    fs.unlinkSync(probe);
    return true;
  } catch (e) {
    return false;
  }
}

export function tempBase() {
  const candidates = [os.tmpdir(), local];
  for (const dir of candidates) {
    if (writable(dir)) return dir;
  }
  return local;
}
