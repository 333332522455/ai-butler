# dsh-qq-bridge

**QQ 官方机器人 ↔ 本机 HTTP 的桥。** QQ 里发一句话，它投进你本机的 DSH 会话（或任何 HTTP 端点）；回答、图片再发回 QQ。零依赖，一个 Node 进程。

```
  手机 QQ ──► QQ 开放平台 ──► 官方 WebSocket 网关
                                      │
                                      ▼
                            ┌───────────────────┐
                            │   dsh-qq-bridge    │  127.0.0.1:43124
                            │  /send  /status    │  ◄── 你的程序 / DSH
                            └─────────┬─────────┘
                                      │ POST inboxUrl
                                      ▼
                       DSH 会话（wechat-bridge）或你自己的 HTTP 端点
```

- 入站：QQ 单聊 / 群聊 @ 消息 → POST 到 `inboxUrl`，带上说话人 openid、正文、附件信息
- 出站：本机任意程序 POST `http://127.0.0.1:43124/send`，桥替你把消息发进 QQ
- 附件：收图片 / 语音 / 文件落到本地 `mediaDir`；发图发文件走富媒体接口
- 长文本自动分段；`access_token` 过期自动续；网关断线自动重连（指数退避）
- 聊天记录按行写 `qq-journal.jsonl`，出事能对着时间线查

## 前置条件

1. **Node.js 18+**（用到内置 `fetch`）
2. 一个 **QQ 官方机器人**：去 <https://q.qq.com/> 建应用 → 拿到 **AppID** 与 **AppSecret** → 打开「单聊」事件订阅（`GROUP_AND_C2C_EVENT`）
3. 你的邮箱 / DSH 会话要能收到 HTTP POST（本机即可，默认地址是 DSH 的 wechat-bridge inbox）

## 安装

```bash
# 方式一：拿到压缩包解压后，在包目录里
npm install -g .        # 之后到处都能用 qq-bridge

# 方式二：不装，直接跑
node bin/qq-bridge.mjs start --state ./qq.json
```

## 三步跑起来

```bash
qq-bridge init                 # 生成 ./.state/qq.json 配置模板
# 把 AppID / AppSecret 填进去（记事本存 UTF-8 别带 BOM 也行，代码会自己剥）
qq-bridge check                # 只看配置，不连网
qq-bridge start                # 起桥
```

起来之后：

1. 用手机 QQ 给机器人发一条消息 —— 桥会转发到 `inboxUrl`，并记住你的 openid
2. 在 DSH 里回一句 —— DSH 的 wechat-bridge 回程会把回答 POST 到 `/send`，你就收到 QQ 消息了
3. 打开 <http://127.0.0.1:43124/> 能看到状态页；`GET /status` 是同一份 JSON

## 配置

配置文件默认 `./.state/qq.json`（用 `--state` 或 `QQ_STATE` 换）。优先级：**命令行 > 环境变量 > 配置文件**。

| 字段 | 含义 | 默认 |
| --- | --- | --- |
| `appId` | QQ 开放平台 AppID | 必填 |
| `clientSecret` | AppSecret | 必填 |
| `intents` | 事件订阅位 | `33554432`（GROUP_AND_C2C_EVENT） |
| `openid` | 固定推送目标；留空 = 收到消息后自动记住 | 空 |
| `port` | 本地 HTTP 端口 | `43124` |
| `host` | 监听地址 | `127.0.0.1` |
| `inboxUrl` | 入站投递地址 | `http://127.0.0.1:43120/wechat-bridge/inbox` |
| `prefix` | 投递时给正文加的前缀 | `"[QQ] "` |
| `mediaDir` | 收附件落盘目录 | `<state 目录>/media` |
| `journalFile` | 事件流水 | `<state 目录>/qq-journal.jsonl` |
| `gatewayUrl` | 覆盖网关地址（调试用） | 官方地址 |

环境变量：`QQ_APP_ID`、`QQ_CLIENT_SECRET`、`QQ_STATE`、`QQ_OPENID`、`QQ_INBOX`、`QQ_JOURNAL`、`QQ_GATEWAY`、`QQ_MEDIA`。适合 Docker / 服务里注入，不必落盘密钥。

## 本地 HTTP 接口

监听 `127.0.0.1`，不对外。

**`GET /status`** — 网关状态、最近一条消息、收发计数、最近错误。

**`POST /send`** — 往 QQ 发消息，发给「最近给你发过消息的人」或配置里的 `openid`。

```bash
curl -s -X POST http://127.0.0.1:43124/send \
  -H 'content-type: application/json' \
  -d '{"text":"你好，我是本机程序"}'

# 发图 / 发文件（本地路径、http(s) 链接都行）
curl -s -X POST http://127.0.0.1:43124/send \
  -H 'content-type: application/json' \
  -d '{"text":"看这个","media":"D:/pic/a.png"}'
```

字段：`text`（必填其一）、`media`（路径 / 链接 / `{path|url|data, fileType, contentType}`）、`typing`（`true` 发「正在输入」）、`requestId`（只进流水，方便对账）。

**`POST /inject`** — 本地自测：假装收到一条 QQ 消息，走完整转发链路。

```bash
curl -s -X POST http://127.0.0.1:43124/inject \
  -H 'content-type: application/json' \
  -d '{"text":"测试","openid":"你的openid"}'
```

## 接到 DSH（可选）

DSH 的 `@local/dsh-wechat-bridge` 插件在 `43120` 上开了 `/wechat-bridge/inbox`：任何文本 POST 进去就变成一条用户消息。所以「用手机 QQ 远程给你的 DSH 发指令」只要两件事：

1. DSH 侧的 wechat-bridge 配置里打开 `reply`，`url` 指向 `http://127.0.0.1:43124/send`
2. 起这个桥：`qq-bridge start`

不用 DSH 也照样能用：`inboxUrl` 指向你自己写的 HTTP 服务即可，请求体是 JSON，带 `text` / `from` / `openid` / `media`。

## 常驻

**Windows（计划任务）**

```powershell
schtasks /Create /TN qq-bridge /SC ONLOGON /TR "node D:\path\to\dsh-qq-bridge\bin\qq-bridge.mjs start" /RL LIMITED
```

**Windows（pm2 / nssm）**

```bash
pm2 start bin/qq-bridge.mjs --name qq-bridge -- start
```

**Linux / systemd**

```ini
[Unit]
Description=dsh-qq-bridge
After=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/dsh-qq-bridge
Environment=QQ_APP_ID=102xxxxxx
Environment=QQ_CLIENT_SECRET=xxxx
ExecStart=/usr/bin/node bin/qq-bridge.mjs start
Restart=always

[Install]
WantedBy=multi-user.target
```

## 安全

- 只监听 `127.0.0.1`，**别把 43124 挂到公网**；要远程调就套隧道或加一层自己的鉴权
- 配置文件里有 AppSecret：`.state/` 已在 `.gitignore` 里，别提交、别贴群
- 机器人能往 QQ 发消息 = 拿到这台机器就能冒充机器人说话，`/inject` 默认开（仅本机可访问），不需要就设 `allowInject: false`
- 桥不读会话正文、不碰聊天记录数据库，只做投递

## 测试

全部离线，零依赖，不联网、不需要 AppID：

```bash
npm test          # 依次跑 10 个自检文件，最后一行 ALL PASS / N FAILED
```

## 常见问题

| 现象 | 原因 / 做法 |
| --- | --- |
| `缺少 appId / clientSecret` | 配置没填，或 `--state` 指的路径不对；`qq-bridge check` 会打印读的是哪个文件 |
| 配了但一直 `no-openid` | 还没人给机器人发过消息；先让手机 QQ 发一条，或在配置里填死 `openid` |
| `state-bad-json` | 配置文件被记事本存成了带 BOM 的 UTF-8（代码会剥 BOM），或末尾少了 `}` |
| 网关一直重连 | 检查 AppID/Secret 是否配对、机器人在开放平台是否已上线、`intents` 是否开了单聊事件 |
| 收不到附件 | `mediaDir` 目录没权限；桥会在流水里记 `media-failed` |
| 端口被占 | `--port 43125` 换一个，DSH 侧回程地址也跟着改 |

## 没包含的

- 微信个人号 hook（违反用户协议，会封号）
- 公网隧道、回调验签（那是你自己前置一层的事）
- 作者私有的「会话看门狗 / 回复看门狗」脚本 —— 它们依赖 DSH 内部文件，不在本包里

## 许可

MIT。
